

// import React, { useState, useEffect } from 'react';
// import { useAuth } from '../AuthContext';
// import { getDatabase, ref, onValue, remove, update } from 'firebase/database';
// import { useNavigate } from 'react-router-dom';
// import { 
//   FiHome, 
//   FiShoppingBag, 
//   FiPlusCircle, 
//   FiUser, 
//   FiLogOut,
//   FiEdit, 
//   FiTrash2,
//   FiEye,
//   FiEyeOff,
//   FiUsers,
//   FiMessageSquare
// } from 'react-icons/fi';
// import { confirmAlert } from 'react-confirm-alert';
// import 'react-confirm-alert/src/react-confirm-alert.css';

// const Dashboard = () => {
//   const { user, logout } = useAuth();
//   const navigate = useNavigate();
//   const [activeTab, setActiveTab] = useState('posts');
//   const [userPosts, setUserPosts] = useState([]);
//   const [purchases, setPurchases] = useState([]);
//   const [interestedClients, setInterestedClients] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

//   // Fetch user data
//   useEffect(() => {
//     if (!user?.mobile) return;

//     const db = getDatabase();
    
//     const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
//     const unsubscribePosts = onValue(postsRef, (snapshot) => {
//       const postsData = snapshot.val();
//       if (postsData) {
//         const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
//           Object.entries(properties).map(([id, post]) => ({
//             id,
//             category,
//             ...post,
//             status: post.status || 'active'
//           }))
//         );
//         setUserPosts(postsArray);
//       } else {
//         setUserPosts([]);
//       }
//       setLoading(false);
//     });

//     const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
//     const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
//       const purchasesData = snapshot.val();
//       setPurchases(purchasesData ? Object.values(purchasesData) : []);
//     });

//     // Fetch interested clients data if user is premium
//     if (user.accountType === 'premium') {
//       const interestedClientsRef = ref(db, `delar/customers/${user.mobile}/interestedClients`);
//       const unsubscribeInterestedClients = onValue(interestedClientsRef, (snapshot) => {
//         const clientsData = snapshot.val();
//         if (clientsData) {
//           const clientsArray = Object.entries(clientsData).map(([id, client]) => ({
//             id,
//             ...client
//           }));
//           setInterestedClients(clientsArray);
//         } else {
//           setInterestedClients([]);
//         }
//       });
      
//       return () => {
//         unsubscribePosts();
//         unsubscribePurchases();
//         unsubscribeInterestedClients();
//       };
//     }

//     return () => {
//       unsubscribePosts();
//       unsubscribePurchases();
//     };
//   }, [user?.mobile, user?.accountType]);

//   // Fixed edit property function
//   const handleEditProperty = (postId, category) => {
//     const propertyToEdit = userPosts.find(
//       post => post.id === postId && post.category === category
//     );
    
//     if (propertyToEdit) {
//       navigate('/sell', { 
//         state: { 
//           property: propertyToEdit,
//           category: category,
//           id: postId
//         } 
//       });
//     } else {
//       console.error('Property not found for editing');
//       alert('Property not found. It may have been deleted.');
//     }
//   };

//   // Delete property with confirmation
//   const handleDeleteProperty = (postId, category) => {
//     confirmAlert({
//       title: 'Confirm Delete',
//       message: 'Are you sure you want to delete this property?',
//       buttons: [
//         {
//           label: 'Delete',
//           className: 'confirm-delete-btn',
//           onClick: () => deleteProperty(postId, category)
//         },
//         {
//           label: 'Cancel',
//           onClick: () => {}
//         }
//       ],
//       closeOnEscape: true,
//       closeOnClickOutside: true,
//     });
//   };

//   // Actual delete function
//   const deleteProperty = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       await remove(propertyRef);
      
//       // Update local state
//       setUserPosts(prevPosts => 
//         prevPosts.filter(post => !(post.id === postId && post.category === category))
//       );
//     } catch (error) {
//       console.error('Error deleting property:', error);
//       alert('Failed to delete property. Please try again.');
//     }
//   };

//   // Toggle property status
//   const togglePropertyStatus = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       const currentPost = userPosts.find(post => post.id === postId && post.category === category);
//       const newStatus = currentPost?.status === 'active' ? 'inactive' : 'active';
      
//       await update(propertyRef, { status: newStatus });
      
//       setUserPosts(prevPosts => 
//         prevPosts.map(post => 
//           post.id === postId && post.category === category
//             ? { ...post, status: newStatus }
//             : post
//         )
//       );
//     } catch (error) {
//       console.error('Error updating property status:', error);
//       alert('Failed to update property status.');
//     }
//   };

//   return (
//     <div style={{
//       display: 'flex',
//       minHeight: '100vh',
//       backgroundColor: '#f5f7fa'
//     }}>
//       {/* Sidebar */}
//       <div style={{
//         width: '250px',
//         backgroundColor: '#002f34',
//         color: 'white',
//         padding: '20px 0',
//         position: 'fixed',
//         height: '100vh',
//         display: mobileMenuOpen ? 'block' : 'none',
//         '@media (min-width: 768px)': {
//           display: 'block',
//           position: 'relative'
//         }
//       }}>
//         <div style={{ padding: '0 20px', marginBottom: '40px' }}>
//           <h2 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '10px' }}>
//             <FiUser size={24} /> {user?.name || 'User'}
//           </h2>
//           <p style={{ color: '#a0aec0', fontSize: '14px' }}>{user?.mobile}</p>
//           {user?.accountType === 'premium' && (
//             <span style={{
//               backgroundColor: '#23e5db',
//               color: '#002f34',
//               padding: '4px 8px',
//               borderRadius: '4px',
//               fontSize: '12px',
//               fontWeight: 'bold',
//               marginTop: '5px',
//               display: 'inline-block'
//             }}>
//               PREMIUM USER
//             </span>
//           )}
//         </div>
        
//         <nav>
//           <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('posts')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'posts' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'posts' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiHome /> My Listings
//               </button>
//             </li>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('purchases')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'purchases' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'purchases' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiShoppingBag /> My Purchases
//               </button>
//             </li>
//             {user?.accountType === 'premium' && (
//               <li>
//                 <button 
//                   onClick={() => setActiveTab('clients')}
//                   style={{
//                     width: '100%',
//                     textAlign: 'left',
//                     padding: '12px 20px',
//                     backgroundColor: activeTab === 'clients' ? '#23e5db' : 'transparent',
//                     color: activeTab === 'clients' ? '#002f34' : 'white',
//                     border: 'none',
//                     display: 'flex',
//                     alignItems: 'center',
//                     gap: '10px',
//                     cursor: 'pointer',
//                     fontWeight: '600',
//                     fontSize: '16px',
//                     transition: 'all 0.2s'
//                   }}
//                 >
//                   <FiUsers /> Interested Clients
//                 </button>
//               </li>
//             )}
//             <li>
//               <button 
//                 onClick={() => navigate('/sell')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiPlusCircle /> Post New Property
//               </button>
//             </li>
//             <li style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
//               <button 
//                 onClick={logout}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiLogOut /> Logout
//               </button>
//             </li>
//           </ul>
//         </nav>
//       </div>

//       {/* Main Content */}
//       <div style={{
//         flex: 1,
//         marginLeft: '0',
//         '@media (min-width: 768px)': {
//           marginLeft: '250px'
//         }
//       }}>
//         {/* Mobile Header */}
//         <div style={{
//           backgroundColor: '#002f34',
//           color: 'white',
//           padding: '15px 20px',
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           '@media (min-width: 768px)': {
//             display: 'none'
//           }
//         }}>
//           <h2 style={{ margin: 0 }}>Dashboard</h2>
//           <button 
//             onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
//             style={{
//               backgroundColor: 'transparent',
//               border: 'none',
//               color: 'white',
//               fontSize: '24px',
//               cursor: 'pointer'
//             }}
//           >
//             ☰
//           </button>
//         </div>

//         {/* Content */}
//         <div style={{
//           padding: '30px',
//           maxWidth: '1200px',
//           margin: '0 auto'
//         }}>
//           <h1 style={{ 
//             color: '#002f34', 
//             marginBottom: '30px',
//             display: 'none',
//             '@media (min-width: 768px)': {
//               display: 'block'
//             }
//           }}>
//             {activeTab === 'posts' ? 'My Property Listings' : 
//              activeTab === 'purchases' ? 'My Purchases' : 
//              activeTab === 'clients' ? 'Interested Clients' : 'Dashboard'}
//           </h1>
          
//           {loading ? (
//             <div style={{ 
//               textAlign: 'center', 
//               padding: '40px',
//               backgroundColor: 'white',
//               borderRadius: '8px',
//               boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//             }}>
//               <p>Loading your data...</p>
//             </div>
//           ) : activeTab === 'posts' ? (
//             <div>
//               {userPosts.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Properties Listed</h3>
//                   <p style={{ color: '#666', marginBottom: '20px' }}>You haven't posted any properties yet.</p>
//                   <button
//                     onClick={() => navigate('/sell')}
//                     style={{
//                       backgroundColor: '#002f34',
//                       color: 'white',
//                       border: 'none',
//                       padding: '12px 25px',
//                       borderRadius: '4px',
//                       cursor: 'pointer',
//                       fontWeight: '600',
//                       fontSize: '16px',
//                       display: 'inline-flex',
//                       alignItems: 'center',
//                       gap: '8px',
//                       transition: 'all 0.2s',
//                       ':hover': {
//                         backgroundColor: '#004950'
//                       }
//                     }}
//                   >
//                     <FiPlusCircle /> Post a Property
//                   </button>
//                 </div>
//               ) : (
//                 <div>
//                   <div style={{
//                     display: 'flex',
//                     justifyContent: 'space-between',
//                     alignItems: 'center',
//                     marginBottom: '20px'
//                   }}>
//                     <h2 style={{ color: '#002f34', margin: 0 }}>
//                       My Properties ({userPosts.length})
//                     </h2>
//                     <button
//                       onClick={() => navigate('/sell')}
//                       style={{
//                         backgroundColor: '#002f34',
//                         color: 'white',
//                         border: 'none',
//                         padding: '10px 20px',
//                         borderRadius: '4px',
//                         cursor: 'pointer',
//                         fontWeight: '600',
//                         fontSize: '14px',
//                         display: 'flex',
//                         alignItems: 'center',
//                         gap: '8px',
//                         transition: 'all 0.2s',
//                         ':hover': {
//                           backgroundColor: '#004950'
//                         }
//                       }}
//                     >
//                       <FiPlusCircle size={16} /> Add New
//                     </button>
//                   </div>
                  
//                   <div style={{
//                     display: 'grid',
//                     gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//                     gap: '20px'
//                   }}>
//                     {userPosts.map((post) => (
//                       <div key={`${post.category}-${post.id}`} style={{
//                         backgroundColor: 'white',
//                         borderRadius: '8px',
//                         boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//                         overflow: 'hidden',
//                         transition: 'transform 0.2s',
//                         opacity: post.status === 'inactive' ? 0.7 : 1,
//                         ':hover': {
//                           transform: 'translateY(-5px)'
//                         }
//                       }}>
//                         {post.images?.[0] && (
//                           <div style={{ position: 'relative' }}>
//                             <img 
//                               src={post.images[0]} 
//                               alt={post.title}
//                               style={{
//                                 width: '100%',
//                                 height: '200px',
//                                 objectFit: 'cover',
//                                 borderBottom: '1px solid #eee'
//                               }}
//                             />
//                             {post.status === 'inactive' && (
//                               <div style={{
//                                 position: 'absolute',
//                                 top: '10px',
//                                 right: '10px',
//                                 backgroundColor: 'rgba(0,0,0,0.7)',
//                                 color: 'white',
//                                 padding: '5px 10px',
//                                 borderRadius: '4px',
//                                 fontSize: '12px',
//                                 fontWeight: 'bold'
//                               }}>
//                                 Inactive
//                               </div>
//                             )}
//                           </div>
//                         )}
//                         <div style={{ padding: '15px' }}>
//                           <h3 style={{ 
//                             margin: '0 0 10px', 
//                             color: '#002f34',
//                             fontSize: '18px',
//                             whiteSpace: 'nowrap',
//                             overflow: 'hidden',
//                             textOverflow: 'ellipsis'
//                           }}>
//                             {post.title}
//                           </h3>
//                           <div style={{
//                             display: 'flex',
//                             justifyContent: 'space-between',
//                             marginBottom: '10px'
//                           }}>
//                             <span style={{
//                               backgroundColor: '#e6f7f7',
//                               color: '#002f34',
//                               padding: '4px 8px',
//                               borderRadius: '4px',
//                               fontSize: '12px',
//                               fontWeight: '600'
//                             }}>
//                               {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
//                             </span>
//                             <p style={{ 
//                               margin: 0, 
//                               fontWeight: 'bold', 
//                               color: '#002f34',
//                               fontSize: '18px'
//                             }}>
//                               ₹{post.price?.toLocaleString('en-IN')}
//                             </p>
//                           </div>
//                           <div style={{ 
//                             display: 'flex', 
//                             justifyContent: 'space-between',
//                             gap: '10px',
//                             marginTop: '15px'
//                           }}>
//                             <button
//                               onClick={() => togglePropertyStatus(post.id, post.category)}
//                               style={{
//                                 padding: '8px 12px',
//                                 backgroundColor: post.status === 'inactive' ? '#4CAF50' : '#f44336',
//                                 color: 'white',
//                                 border: 'none',
//                                 borderRadius: '4px',
//                                 cursor: 'pointer',
//                                 fontWeight: '600',
//                                 fontSize: '14px',
//                                 display: 'flex',
//                                 alignItems: 'center',
//                                 gap: '5px'
//                               }}
//                             >
//                               {post.status === 'inactive' ? <FiEye size={14} /> : <FiEyeOff size={14} />}
//                               {post.status === 'inactive' ? 'Activate' : 'Deactivate'}
//                             </button>
                            
//                             <div style={{ display: 'flex', gap: '10px' }}>
//                             <button
//     onClick={() => handleEditProperty(post.id, post.category)}
//     style={{
//       padding: '8px 12px',
//       backgroundColor: '#2196F3',
//       color: 'white',
//       border: 'none',
//       borderRadius: '4px',
//       cursor: 'pointer',
//       fontWeight: '600',
//       fontSize: '14px',
//       display: 'flex',
//       alignItems: 'center',
//       gap: '5px'
//     }}
//   >
//     <FiEdit size={14} /> Edit
//   </button>
                              
//                               <button
//                                 onClick={() => handleDeleteProperty(post.id, post.category)}
//                                 style={{
//                                   padding: '8px 12px',
//                                   backgroundColor: '#ff5252',
//                                   color: 'white',
//                                   border: 'none',
//                                   borderRadius: '4px',
//                                   cursor: 'pointer',
//                                   fontWeight: '600',
//                                   fontSize: '14px',
//                                   display: 'flex',
//                                   alignItems: 'center',
//                                   gap: '5px'
//                                 }}
//                               >
//                                 <FiTrash2 size={14} /> Delete
//                               </button>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>
//           ) :activeTab === 'clients' ? (
//             <div>
//               <h2 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '20px' 
//               }}>
//                 Interested Clients ({interestedClients.length})
//               </h2>
              
//               {interestedClients.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Interested Clients Yet</h3>
//                   <p style={{ color: '#666' }}>You'll see interested clients here when they contact you about your properties.</p>
//                 </div>
//               ) : (
//                 <div style={{
//                   backgroundColor: 'white',
//                   borderRadius: '8px',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
//                   overflow: 'hidden'
//                 }}>
//                   <table style={{
//                     width: '100%',
//                     borderCollapse: 'collapse'
//                   }}>
//                     <thead>
//                       <tr style={{
//                         backgroundColor: '#f8f9fa',
//                         borderBottom: '1px solid #eee'
//                       }}>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Property</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Client</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Contact</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Message</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {interestedClients.map((client, index) => (
//                         <tr key={index} style={{
//                           borderBottom: '1px solid #eee',
//                           ':last-child': {
//                             borderBottom: 'none'
//                           }
//                         }}>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: '500'
//                           }}>
//                             {client.propertyTitle}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             {client.name}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             <div style={{ marginBottom: '5px' }}>{client.mobile}</div>
//                             <div style={{ color: '#666', fontSize: '14px' }}>{client.email}</div>
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {client.message || 'No message'}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {new Date(client.timestamp).toLocaleDateString()}
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//               )}
//             </div>
//           ) : null}

//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;





import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { getDatabase, ref, onValue, remove, update, push, get } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import { 
  FiHome, 
  FiShoppingBag, 
  FiPlusCircle, 
  FiUser, 
  FiLogOut,
  FiEdit, 
  FiTrash2,
  FiEye,
  FiEyeOff,
  FiUsers,
  FiMessageSquare,
  FiDollarSign,
  FiCheck,
  FiClock
} from 'react-icons/fi';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('posts');
  const [userPosts, setUserPosts] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [interestedClients, setInterestedClients] = useState([]);
  const [availablePlans, setAvailablePlans] = useState([]);
  const [userPlan, setUserPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Fetch user data
  // useEffect(() => {
  //   if (!user?.mobile) return;

  //   const db = getDatabase();
    
  //   // Fetch user's properties
  //   const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
  //   const unsubscribePosts = onValue(postsRef, (snapshot) => {
  //     const postsData = snapshot.val();
  //     if (postsData) {
  //       const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
  //         Object.entries(properties).map(([id, post]) => ({
  //           id,
  //           category,
  //           ...post,
  //           status: post.status || 'active'
  //         }))
  //       );
  //       setUserPosts(postsArray);
  //     } else {
  //       setUserPosts([]);
  //     }
  //     setLoading(false);
  //   });

  //   // Fetch user's purchases
  //   const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
  //   const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
  //     const purchasesData = snapshot.val();
  //     setPurchases(purchasesData ? Object.values(purchasesData) : []);
  //   });

  //   // Fetch user's plan
  //   const planRef = ref(db, `delar/customers/${user.mobile}/plan`);
  //   const unsubscribePlan = onValue(planRef, (snapshot) => {
  //     const planData = snapshot.val();
  //     setUserPlan(planData || null);
  //   });

  //   // Fetch available plans
  //   const plansRef = ref(db, 'delar/admin/plans');
  //   const unsubscribePlans = onValue(plansRef, (snapshot) => {
  //     const plansData = snapshot.val();
  //     if (plansData) {
  //       const plansArray = Object.entries(plansData).map(([id, plan]) => ({
  //         id,
  //         ...plan
  //       }));
  //       setAvailablePlans(plansArray);
  //     }
  //   });

  //   // Fetch interested clients data if user has an active plan
  //   const checkPlanAndFetchClients = async () => {
  //     if (userPlan?.status === 'active') {
  //       const interestedClientsRef = ref(db, `delar/customers/${user.mobile}/interestedClients`);
  //       const unsubscribeInterestedClients = onValue(interestedClientsRef, (snapshot) => {
  //         const clientsData = snapshot.val();
  //         if (clientsData) {
  //           const clientsArray = Object.entries(clientsData).map(([id, client]) => ({
  //             id,
  //             ...client
  //           }));
  //           setInterestedClients(clientsArray);
  //         } else {
  //           setInterestedClients([]);
  //         }
  //       });
  //       return unsubscribeInterestedClients;
  //     }
  //   };

  //   const unsubscribeInterestedClients = checkPlanAndFetchClients();
    
  //   return () => {
  //     unsubscribePosts();
  //     unsubscribePurchases();
  //     unsubscribePlan();
  //     unsubscribePlans();
  //     if (unsubscribeInterestedClients) unsubscribeInterestedClients();
  //   };
  // }, [user?.mobile, userPlan?.status]);


  useEffect(() => {
    if (!user?.mobile) return;
  
    const db = getDatabase();
    
    // Fetch user's properties
    const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
    const unsubscribePosts = onValue(postsRef, (snapshot) => {
      const postsData = snapshot.val();
      if (postsData) {
        const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
          Object.entries(properties).map(([id, post]) => ({
            id,
            category,
            ...post,
            status: post.status || 'active'
          }))
        );
        setUserPosts(postsArray);
      } else {
        setUserPosts([]);
      }
      setLoading(false);
    });
  
    // Fetch user's purchases
    const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
    const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
      const purchasesData = snapshot.val();
      setPurchases(purchasesData ? Object.values(purchasesData) : []);
    });
  
    // Fetch user's plan
    const planRef = ref(db, `delar/customers/${user.mobile}/plan`);
    const unsubscribePlan = onValue(planRef, (snapshot) => {
      const planData = snapshot.val();
      setUserPlan(planData || null);
    });
  
    // Fetch available plans
    const plansRef = ref(db, 'delar/admin/plans');
    const unsubscribePlans = onValue(plansRef, (snapshot) => {
      const plansData = snapshot.val();
      if (plansData) {
        const plansArray = Object.entries(plansData).map(([id, plan]) => ({
          id,
          ...plan
        }));
        setAvailablePlans(plansArray);
      }
    });
  
    // Initialize unsubscribe function for interested clients
    let unsubscribeNotifications = () => {};

    // Fetch notifications data if user has an active plan
    const checkPlanAndFetchNotifications = (planData) => {
      if (planData?.status === 'active') {
        const notificationsRef = ref(db, `delar/customers/${user.mobile}/notifications`);
        unsubscribeNotifications = onValue(notificationsRef, (snapshot) => {
          const notificationsData = snapshot.val();
          if (notificationsData) {
            const notificationsArray = Object.entries(notificationsData)
              .map(([id, notification]) => ({
                id,
                ...notification,
                // Convert timestamp to readable date
                date: new Date(notification.timestamp).toLocaleDateString(),
                time: new Date(notification.timestamp).toLocaleTimeString()
              }))
              // Sort by timestamp (newest first)
              .sort((a, b) => b.timestamp - a.timestamp);
            
            setInterestedClients(notificationsArray.filter(
              n => n.type === 'client_interest'
            ));
          } else {
            setInterestedClients([]);
          }
        });
      } else {
        setInterestedClients([]);
      }
    };
  
    // Initial check
    get(planRef).then((snapshot) => {
      checkPlanAndFetchNotifications(snapshot.val());
    });
  
    // Return cleanup function
    return () => {
      unsubscribePosts();
      unsubscribePurchases();
      unsubscribePlan();
      unsubscribePlans();
      unsubscribeNotifications();
    };
  }, [user?.mobile]);


  // Fixed edit property function
  const handleEditProperty = (postId, category) => {
    const propertyToEdit = userPosts.find(
      post => post.id === postId && post.category === category
    );
    
    if (propertyToEdit) {
      navigate('/sell', { 
        state: { 
          property: propertyToEdit,
          category: category,
          id: postId
        } 
      });
    } else {
      console.error('Property not found for editing');
      alert('Property not found. It may have been deleted.');
    }
  };

  // Delete property with confirmation
  const handleDeleteProperty = (postId, category) => {
    confirmAlert({
      title: 'Confirm Delete',
      message: 'Are you sure you want to delete this property?',
      buttons: [
        {
          label: 'Delete',
          className: 'confirm-delete-btn',
          onClick: () => deleteProperty(postId, category)
        },
        {
          label: 'Cancel',
          onClick: () => {}
        }
      ],
      closeOnEscape: true,
      closeOnClickOutside: true,
    });
  };

  // Actual delete function
  const deleteProperty = async (postId, category) => {
    try {
      const db = getDatabase();
      const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
      await remove(propertyRef);
      
      // Update local state
      setUserPosts(prevPosts => 
        prevPosts.filter(post => !(post.id === postId && post.category === category))
      );
    } catch (error) {
      console.error('Error deleting property:', error);
      alert('Failed to delete property. Please try again.');
    }
  };


  
  // Toggle property status
  const togglePropertyStatus = async (postId, category) => {
    try {
      const db = getDatabase();
      const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
      const currentPost = userPosts.find(post => post.id === postId && post.category === category);
      const newStatus = currentPost?.status === 'active' ? 'inactive' : 'active';
      
      await update(propertyRef, { status: newStatus });
      
      setUserPosts(prevPosts => 
        prevPosts.map(post => 
          post.id === postId && post.category === category
            ? { ...post, status: newStatus }
            : post
        )
      );
    } catch (error) {
      console.error('Error updating property status:', error);
      alert('Failed to update property status.');
    }
  };

  // Purchase a plan
  const purchasePlan = async (planId) => {
    try {
      const db = getDatabase();
      
      // Find the selected plan
      const selectedPlan = availablePlans.find(plan => plan.id === planId);
      if (!selectedPlan) {
        alert('Selected plan not found.');
        return;
      }
      
      // Calculate expiration date
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + selectedPlan.duration);
      
      // Update user's plan
      const planRef = ref(db, `delar/customers/${user.mobile}/plan`);
      await update(planRef, {
        id: planId,
        name: selectedPlan.name,
        status: 'active',
        purchasedAt: new Date().toISOString(),
        expiresAt: expiresAt.toISOString(),
        features: selectedPlan.features
      });
      
      // Record the purchase
      const purchaseRef = ref(db, `delar/customers/${user.mobile}/purchases`);
      await push(purchaseRef, {
        type: 'plan',
        planId,
        amount: selectedPlan.price,
        date: new Date().toISOString(),
        expiresAt: expiresAt.toISOString()
      });
      
      alert(`Successfully purchased ${selectedPlan.name} plan!`);
    } catch (error) {
      console.error('Error purchasing plan:', error);
      alert('Failed to purchase plan. Please try again.');
    }
  };

  // Render plan status badge
  const renderPlanStatus = () => {
    if (!userPlan) {
      return (
        <span style={{
          backgroundColor: '#f44336',
          color: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '12px',
          fontWeight: 'bold',
          marginTop: '5px',
          display: 'inline-block'
        }}>
          NO ACTIVE PLAN
        </span>
      );
    }

    const isExpired = userPlan.expiresAt && new Date(userPlan.expiresAt) < new Date();
    const status = isExpired ? 'expired' : userPlan.status;

    return (
      <div style={{ marginTop: '5px' }}>
        <span style={{
          backgroundColor: status === 'active' ? '#4CAF50' : '#f44336',
          color: 'white',
          padding: '4px 8px',
          borderRadius: '4px',
          fontSize: '12px',
          fontWeight: 'bold',
          display: 'inline-block',
          marginRight: '8px'
        }}>
          {status === 'active' ? 'ACTIVE PLAN' : status.toUpperCase()}
        </span>
        <span style={{ fontSize: '12px', color: '#666' }}>
          {userPlan.expiresAt && `Expires: ${new Date(userPlan.expiresAt).toLocaleDateString()}`}
        </span>
      </div>
    );
  };

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      backgroundColor: '#f5f7fa'
    }}>
      {/* Sidebar */}
      <div style={{
        width: '250px',
        backgroundColor: '#002f34',
        color: 'white',
        padding: '20px 0',
        position: 'fixed',
        height: '100vh',
        display: mobileMenuOpen ? 'block' : 'none',
        '@media (min-width: 768px)': {
          display: 'block',
          position: 'relative'
        }
      }}>
        <div style={{ padding: '0 20px', marginBottom: '40px' }}>
          <h2 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <FiUser size={24} /> {user?.name || 'User'}
          </h2>
          <p style={{ color: '#a0aec0', fontSize: '14px' }}>{user?.mobile}</p>
          {renderPlanStatus()}
        </div>
        
        <nav>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            <li>
              <button 
                onClick={() => setActiveTab('posts')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: activeTab === 'posts' ? '#23e5db' : 'transparent',
                  color: activeTab === 'posts' ? '#002f34' : 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s'
                }}
              >
                <FiHome /> My Listings
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('purchases')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: activeTab === 'purchases' ? '#23e5db' : 'transparent',
                  color: activeTab === 'purchases' ? '#002f34' : 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s'
                }}
              >
                <FiShoppingBag /> My Purchases
              </button>
            </li>
            {userPlan?.status === 'active' && (
              <li>
                <button 
                  onClick={() => setActiveTab('clients')}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    padding: '12px 20px',
                    backgroundColor: activeTab === 'clients' ? '#23e5db' : 'transparent',
                    color: activeTab === 'clients' ? '#002f34' : 'white',
                    border: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    cursor: 'pointer',
                    fontWeight: '600',
                    fontSize: '16px',
                    transition: 'all 0.2s'
                  }}
                >
                  <FiUsers /> Interested Clients
                </button>
              </li>
            )}
            <li>
              <button 
                onClick={() => navigate('/sell')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: 'transparent',
                  color: 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <FiPlusCircle /> Post New Property
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('plans')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: activeTab === 'plans' ? '#23e5db' : 'transparent',
                  color: activeTab === 'plans' ? '#002f34' : 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <FiDollarSign /> Subscription Plans
              </button>
            </li>
            <li style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <button 
                onClick={logout}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: 'transparent',
                  color: 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <FiLogOut /> Logout
              </button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div style={{
        flex: 1,
        marginLeft: '0',
        '@media (min-width: 768px)': {
          marginLeft: '250px'
        }
      }}>
        {/* Mobile Header */}
        <div style={{
          backgroundColor: '#002f34',
          color: 'white',
          padding: '15px 20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          '@media (min-width: 768px)': {
            display: 'none'
          }
        }}>
          <h2 style={{ margin: 0 }}>Dashboard</h2>
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              color: 'white',
              fontSize: '24px',
              cursor: 'pointer'
            }}
          >
            ☰
          </button>
        </div>

        {/* Content */}
        <div style={{
          padding: '30px',
          maxWidth: '1200px',
          margin: '0 auto'
        }}>
          <h1 style={{ 
            color: '#002f34', 
            marginBottom: '30px',
            display: 'none',
            '@media (min-width: 768px)': {
              display: 'block'
            }
          }}>
            {activeTab === 'posts' ? 'My Property Listings' : 
             activeTab === 'purchases' ? 'My Purchases' : 
             activeTab === 'clients' ? 'Interested Clients' : 
             activeTab === 'plans' ? 'Subscription Plans' : 'Dashboard'}
          </h1>
          
          {loading ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '40px',
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
            }}>
              <p>Loading your data...</p>
            </div>
          ) : activeTab === 'posts' ? (
            <div>
              {userPosts.length === 0 ? (
                <div style={{
                  backgroundColor: 'white',
                  padding: '30px',
                  borderRadius: '8px',
                  textAlign: 'center',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
                }}>
                  <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Properties Listed</h3>
                  <p style={{ color: '#666', marginBottom: '20px' }}>You haven't posted any properties yet.</p>
                  <button
                    onClick={() => navigate('/sell')}
                    style={{
                      backgroundColor: '#002f34',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: '600',
                      fontSize: '16px',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.2s',
                      ':hover': {
                        backgroundColor: '#004950'
                      }
                    }}
                  >
                    <FiPlusCircle /> Post a Property
                  </button>
                </div>
              ) : (
                <div>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '20px'
                  }}>
                    <h2 style={{ color: '#002f34', margin: 0 }}>
                      My Properties ({userPosts.length})
                    </h2>
                    <button
                      onClick={() => navigate('/sell')}
                      style={{
                        backgroundColor: '#002f34',
                        color: 'white',
                        border: 'none',
                        padding: '10px 20px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '14px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.2s',
                        ':hover': {
                          backgroundColor: '#004950'
                        }
                      }}
                    >
                      <FiPlusCircle size={16} /> Add New
                    </button>
                  </div>
                  
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                    gap: '20px'
                  }}>
                    {userPosts.map((post) => (
                      <div key={`${post.category}-${post.id}`} style={{
                        backgroundColor: 'white',
                        borderRadius: '8px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        overflow: 'hidden',
                        transition: 'transform 0.2s',
                        opacity: post.status === 'inactive' ? 0.7 : 1,
                        ':hover': {
                          transform: 'translateY(-5px)'
                        }
                      }}>
                        {post.images?.[0] && (
                          <div style={{ position: 'relative' }}>
                            <img 
                              src={post.images[0]} 
                              alt={post.title}
                              style={{
                                width: '100%',
                                height: '200px',
                                objectFit: 'cover',
                                borderBottom: '1px solid #eee'
                              }}
                            />
                            {post.status === 'inactive' && (
                              <div style={{
                                position: 'absolute',
                                top: '10px',
                                right: '10px',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                color: 'white',
                                padding: '5px 10px',
                                borderRadius: '4px',
                                fontSize: '12px',
                                fontWeight: 'bold'
                              }}>
                                Inactive
                              </div>
                            )}
                          </div>
                        )}
                        <div style={{ padding: '15px' }}>
                          <h3 style={{ 
                            margin: '0 0 10px', 
                            color: '#002f34',
                            fontSize: '18px',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            {post.title}
                          </h3>
                          <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '10px'
                          }}>
                            <span style={{
                              backgroundColor: '#e6f7f7',
                              color: '#002f34',
                              padding: '4px 8px',
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: '600'
                            }}>
                              {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
                            </span>
                            <p style={{ 
                              margin: 0, 
                              fontWeight: 'bold', 
                              color: '#002f34',
                              fontSize: '18px'
                            }}>
                              ₹{post.price?.toLocaleString('en-IN')}
                            </p>
                          </div>
                          <div style={{ 
                            display: 'flex', 
                            justifyContent: 'space-between',
                            gap: '10px',
                            marginTop: '15px'
                          }}>
                            <button
                              onClick={() => togglePropertyStatus(post.id, post.category)}
                              style={{
                                padding: '8px 12px',
                                backgroundColor: post.status === 'inactive' ? '#4CAF50' : '#f44336',
                                color: 'white',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontWeight: '600',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}
                            >
                              {post.status === 'inactive' ? <FiEye size={14} /> : <FiEyeOff size={14} />}
                              {post.status === 'inactive' ? 'Activate' : 'Deactivate'}
                            </button>
                            
                            <div style={{ display: 'flex', gap: '10px' }}>
                              <button
                                onClick={() => handleEditProperty(post.id, post.category)}
                                style={{
                                  padding: '8px 12px',
                                  backgroundColor: '#2196F3',
                                  color: 'white',
                                  border: 'none',
                                  borderRadius: '4px',
                                  cursor: 'pointer',
                                  fontWeight: '600',
                                  fontSize: '14px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px'
                                }}
                              >
                                <FiEdit size={14} /> Edit
                              </button>
                              
                              <button
                                onClick={() => handleDeleteProperty(post.id, post.category)}
                                style={{
                                  padding: '8px 12px',
                                  backgroundColor: '#ff5252',
                                  color: 'white',
                                  border: 'none',
                                  borderRadius: '4px',
                                  cursor: 'pointer',
                                  fontWeight: '600',
                                  fontSize: '14px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px'
                                }}
                              >
                                <FiTrash2 size={14} /> Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : activeTab === 'clients' ? (
            <div>
    <h2 style={{ 
      color: '#002f34', 
      marginBottom: '20px' 
    }}>
      Interested Clients ({interestedClients.length})
    </h2>
    
    {interestedClients.length === 0 ? (
      <div style={{
        backgroundColor: 'white',
        padding: '30px',
        borderRadius: '8px',
        textAlign: 'center',
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
      }}>
        <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Interested Clients Yet</h3>
        <p style={{ color: '#666' }}>You'll see notifications here when clients show interest in your properties.</p>
      </div>
    ) : (
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
        overflow: 'hidden'
      }}>
        <table style={{
          width: '100%',
          borderCollapse: 'collapse'
        }}>
          <thead>
            <tr style={{
              backgroundColor: '#f8f9fa',
              borderBottom: '1px solid #eee'
            }}>
              <th style={{ padding: '15px', textAlign: 'left', color: '#002f34' }}>Property</th>
              <th style={{ padding: '15px', textAlign: 'left', color: '#002f34' }}>Client</th>
              <th style={{ padding: '15px', textAlign: 'left', color: '#002f34' }}>Offer</th>
              <th style={{ padding: '15px', textAlign: 'left', color: '#002f34' }}>Contact</th>
              <th style={{ padding: '15px', textAlign: 'left', color: '#002f34' }}>Date</th>
            </tr>
          </thead>
          <tbody>
            {interestedClients.map((notification) => (
              <tr key={notification.id} style={{
                borderBottom: '1px solid #eee',
                ':last-child': { borderBottom: 'none' }
              }}>
                <td style={{ padding: '15px', color: '#002f34', fontWeight: '500' }}>
                  {notification.property?.title || 'Unknown Property'}
                  <div style={{ color: '#666', fontSize: '14px' }}>
                    ₹{notification.property?.price?.toLocaleString('en-IN') || 'N/A'}
                  </div>
                </td>
                <td style={{ padding: '15px', color: '#002f34' }}>
                  {notification.client?.name || 'Unknown'}
                </td>
                <td style={{ padding: '15px', color: '#002f34' }}>
                  ₹{notification.client?.offerAmount?.toLocaleString('en-IN') || 'N/A'}
                </td>
                <td style={{ padding: '15px', color: '#002f34' }}>
                  <div style={{ marginBottom: '5px' }}>{notification.client?.phone || 'Not provided'}</div>
                  <div style={{ color: '#666', fontSize: '14px' }}>
                    {notification.client?.email || 'Not provided'}
                  </div>
                </td>
                <td style={{ padding: '15px', color: '#666' }}>
                  <div>{notification.date}</div>
                  <div style={{ fontSize: '12px' }}>{notification.time}</div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )}
  </div>
          ) : activeTab === 'plans' ? (
            <div>
              <h2 style={{ 
                color: '#002f34', 
                marginBottom: '20px' 
              }}>
                Available Subscription Plans
              </h2>
              
              {userPlan?.status === 'active' ? (
                <div style={{
                  backgroundColor: 'white',
                  padding: '30px',
                  borderRadius: '8px',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                  marginBottom: '30px'
                }}>
                  <h3 style={{ 
                    color: '#002f34', 
                    marginBottom: '15px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px'
                  }}>
                    <FiCheck style={{ color: '#4CAF50' }} /> Your Current Plan
                  </h3>
                  <div style={{
                    backgroundColor: '#f8f9fa',
                    padding: '20px',
                    borderRadius: '8px',
                    marginBottom: '20px'
                  }}>
                    <h4 style={{ 
                      color: '#002f34', 
                      margin: '0 0 10px',
                      fontSize: '20px'
                    }}>
                      {userPlan.name}
                    </h4>
                    <p style={{ 
                      color: '#666', 
                      marginBottom: '15px',
                      fontSize: '16px'
                    }}>
                      ₹{availablePlans.find(p => p.id === userPlan.id)?.price || '0'} / {availablePlans.find(p => p.id === userPlan.id)?.duration || '0'} days
                    </p>
                    <div style={{ marginBottom: '15px' }}>
                      <p style={{ 
                        color: '#002f34', 
                        marginBottom: '10px',
                        fontWeight: '500'
                      }}>
                        Plan Features:
                      </p>
                      <ul style={{ 
                        paddingLeft: '20px',
                        margin: 0
                      }}>
                        {(userPlan.features || []).map((feature, index) => (
                          <li key={index} style={{ 
                            marginBottom: '8px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px'
                          }}>
                            <FiCheck style={{ color: '#4CAF50' }} />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <p style={{ 
                      color: '#666', 
                      margin: 0,
                      fontSize: '14px'
                    }}>
                      <strong>Expires:</strong> {new Date(userPlan.expiresAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ) : null}
              
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                gap: '20px'
              }}>
                {availablePlans.map((plan) => (
                  <div key={plan.id} style={{
                    backgroundColor: 'white',
                    borderRadius: '8px',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                    overflow: 'hidden',
                    border: userPlan?.id === plan.id ? '2px solid #23e5db' : '1px solid #eee'
                  }}>
                    <div style={{
                      backgroundColor: '#002f34',
                      color: 'white',
                      padding: '20px',
                      textAlign: 'center'
                    }}>
                      <h3 style={{ 
                        margin: '0 0 10px',
                        fontSize: '22px'
                      }}>
                        {plan.name}
                      </h3>
                      <p style={{ 
                        margin: 0,
                        fontSize: '18px',
                        fontWeight: 'bold'
                      }}>
                        ₹{plan.price} / {plan.duration} days
                      </p>
                    </div>
                    <div style={{ padding: '20px' }}>
                      <div style={{ marginBottom: '20px' }}>
                        <h4 style={{ 
                          color: '#002f34', 
                          margin: '0 0 10px',
                          fontSize: '16px',
                          fontWeight: '600'
                        }}>
                          Features:
                        </h4>
                        <ul style={{ 
                          paddingLeft: '20px',
                          margin: 0
                        }}>
                          {plan.features.map((feature, index) => (
                            <li key={index} style={{ 
                              marginBottom: '8px',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px'
                            }}>
                              <FiCheck style={{ color: '#4CAF50' }} />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div style={{ 
                        display: 'flex',
                        justifyContent: 'space-between',
                        marginBottom: '15px'
                      }}>
                        <div>
                          <p style={{ 
                            color: '#002f34', 
                            margin: '0 0 5px',
                            fontWeight: '500'
                          }}>
                            Max Properties:
                          </p>
                          <p style={{ margin: 0 }}>
                            {plan.maxProperties}
                          </p>
                        </div>
                        <div>
                          <p style={{ 
                            color: '#002f34', 
                            margin: '0 0 5px',
                            fontWeight: '500'
                          }}>
                            Leads:
                          </p>
                          <p style={{ margin: 0 }}>
                            {plan.canReceiveLeads ? 'Enabled' : 'Disabled'}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => purchasePlan(plan.id)}
                        disabled={userPlan?.id === plan.id && userPlan?.status === 'active'}
                        style={{
                          width: '100%',
                          padding: '12px',
                          backgroundColor: userPlan?.id === plan.id && userPlan?.status === 'active' ? '#4CAF50' : '#002f34',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: userPlan?.id === plan.id && userPlan?.status === 'active' ? 'default' : 'pointer',
                          fontWeight: '600',
                          fontSize: '16px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: '8px',
                          transition: 'all 0.2s',
                          ':hover': {
                            backgroundColor: userPlan?.id === plan.id && userPlan?.status === 'active' ? '#4CAF50' : '#004950'
                          }
                        }}
                      >
                        {userPlan?.id === plan.id && userPlan?.status === 'active' ? (
                          <>
                            <FiCheck /> Current Plan
                          </>
                        ) : (
                          <>
                            <FiDollarSign /> Purchase Now
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

// // import { useAuth } from '../AuthContext';
// // import { getDatabase, ref, onValue, remove, update } from 'firebase/database';
// // import { useNavigate } from 'react-router-dom';
// // import { 
// //   FiHome, 
// //   FiShoppingBag, 
// //   FiPlusCircle, 
// //   FiUser, 
// //   FiLogOut,
// //   FiEdit, 
// //   FiTrash2,
// //   FiEye,
// //   FiEyeOff,
// //   FiUsers,
// //   FiMessageSquare
// // } from 'react-icons/fi';
// // import { confirmAlert } from 'react-confirm-alert';
// // import 'react-confirm-alert/src/react-confirm-alert.css';

// // const Dashboard = () => {
//   const { user, logout } = useAuth();
//   const navigate = useNavigate();
//   const [activeTab, setActiveTab] = useState('posts');
//   const [userPosts, setUserPosts] = useState([]);
//   const [purchases, setPurchases] = useState([]);
//   const [interestedClients, setInterestedClients] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

//   // Fetch user data
//   useEffect(() => {
//     if (!user?.mobile) return;

//     const db = getDatabase();
    
//     const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
//     const unsubscribePosts = onValue(postsRef, (snapshot) => {
//       const postsData = snapshot.val();
//       if (postsData) {
//         const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
//           Object.entries(properties).map(([id, post]) => ({
//             id,
//             category,
//             ...post,
//             status: post.status || 'active'
//           }))
//         );
//         setUserPosts(postsArray);
//       } else {
//         setUserPosts([]);
//       }
//       setLoading(false);
//     });

//     const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
//     const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
//       const purchasesData = snapshot.val();
//       setPurchases(purchasesData ? Object.values(purchasesData) : []);
//     });

//     // Fetch interested clients data if user is premium
//     if (user.accountType === 'premium') {
//       const interestedClientsRef = ref(db, `delar/customers/${user.mobile}/interestedClients`);
//       const unsubscribeInterestedClients = onValue(interestedClientsRef, (snapshot) => {
//         const clientsData = snapshot.val();
//         if (clientsData) {
//           const clientsArray = Object.entries(clientsData).map(([id, client]) => ({
//             id,
//             ...client
//           }));
//           setInterestedClients(clientsArray);
//         } else {
//           setInterestedClients([]);
//         }
//       });
      
//       return () => {
//         unsubscribePosts();
//         unsubscribePurchases();
//         unsubscribeInterestedClients();
//       };
//     }

//     return () => {
//       unsubscribePosts();
//       unsubscribePurchases();
//     };
//   }, [user?.mobile, user?.accountType]);

//   const handleEditProperty = (postId, category) => {
//     const propertyToEdit = userPosts.find(
//       post => post.id === postId && post.category === category
//     );
    
//     if (propertyToEdit) {
//       navigate('/sell', { 
//         state: { 
//           property: propertyToEdit,
//           category: category,
//           id: postId
//         } 
//       });
//     } else {
//       console.error('Property not found for editing');
//       alert('Property not found. It may have been deleted.');
//     }
//   };

//   const handleDeleteProperty = (postId, category) => {
//     confirmAlert({
//       title: 'Confirm Delete',
//       message: 'Are you sure you want to delete this property?',
//       buttons: [
//         {
//           label: 'Delete',
//           className: 'confirm-delete-btn',
//           onClick: () => deleteProperty(postId, category)
//         },
//         {
//           label: 'Cancel',
//           onClick: () => {}
//         }
//       ],
//       closeOnEscape: true,
//       closeOnClickOutside: true,
//     });
//   };

//   const deleteProperty = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       await remove(propertyRef);
      
//       setUserPosts(prevPosts => 
//         prevPosts.filter(post => !(post.id === postId && post.category === category))
//       );
//     } catch (error) {
//       console.error('Error deleting property:', error);
//       alert('Failed to delete property. Please try again.');
//     }
//   };

//   const togglePropertyStatus = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       const currentPost = userPosts.find(post => post.id === postId && post.category === category);
//       const newStatus = currentPost?.status === 'active' ? 'inactive' : 'active';
      
//       await update(propertyRef, { status: newStatus });
      
//       setUserPosts(prevPosts => 
//         prevPosts.map(post => 
//           post.id === postId && post.category === category
//             ? { ...post, status: newStatus }
//             : post
//         )
//       );
//     } catch (error) {
//       console.error('Error updating property status:', error);
//       alert('Failed to update property status.');
//     }
//   };

//   return (
//     <div style={{
//       display: 'flex',
//       minHeight: '100vh',
//       backgroundColor: '#f5f7fa'
//     }}>
//       {/* Sidebar */}
//       <div style={{
//         width: '250px',
//         backgroundColor: '#002f34',
//         color: 'white',
//         padding: '20px 0',
//         position: 'fixed',
//         height: '100vh',
//         display: mobileMenuOpen ? 'block' : 'none',
//         '@media (min-width: 768px)': {
//           display: 'block',
//           position: 'relative'
//         }
//       }}>
//         <div style={{ padding: '0 20px', marginBottom: '40px' }}>
//           <h2 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '10px' }}>
//             <FiUser size={24} /> {user?.name || 'User'}
//           </h2>
//           <p style={{ color: '#a0aec0', fontSize: '14px' }}>{user?.mobile}</p>
//           {user?.accountType === 'premium' && (
//             <span style={{
//               backgroundColor: '#23e5db',
//               color: '#002f34',
//               padding: '4px 8px',
//               borderRadius: '4px',
//               fontSize: '12px',
//               fontWeight: 'bold',
//               marginTop: '5px',
//               display: 'inline-block'
//             }}>
//               PREMIUM USER
//             </span>
//           )}
//         </div>
        
//         <nav>
//           <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('posts')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'posts' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'posts' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiHome /> My Listings
//               </button>
//             </li>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('purchases')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'purchases' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'purchases' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiShoppingBag /> My Purchases
//               </button>
//             </li>
//             {user?.accountType === 'premium' && (
//               <li>
//                 <button 
//                   onClick={() => setActiveTab('clients')}
//                   style={{
//                     width: '100%',
//                     textAlign: 'left',
//                     padding: '12px 20px',
//                     backgroundColor: activeTab === 'clients' ? '#23e5db' : 'transparent',
//                     color: activeTab === 'clients' ? '#002f34' : 'white',
//                     border: 'none',
//                     display: 'flex',
//                     alignItems: 'center',
//                     gap: '10px',
//                     cursor: 'pointer',
//                     fontWeight: '600',
//                     fontSize: '16px',
//                     transition: 'all 0.2s'
//                   }}
//                 >
//                   <FiUsers /> Interested Clients
//                 </button>
//               </li>
//             )}
//             <li>
//               <button 
//                 onClick={() => navigate('/sell')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiPlusCircle /> Post New Property
//               </button>
//             </li>
//             <li style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
//               <button 
//                 onClick={logout}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiLogOut /> Logout
//               </button>
//             </li>
//           </ul>
//         </nav>
//       </div>

//       {/* Main Content */}
//       <div style={{
//         flex: 1,
//         marginLeft: '0',
//         '@media (min-width: 768px)': {
//           marginLeft: '250px'
//         }
//       }}>
//         {/* Mobile Header */}
//         <div style={{
//           backgroundColor: '#002f34',
//           color: 'white',
//           padding: '15px 20px',
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           '@media (min-width: 768px)': {
//             display: 'none'
//           }
//         }}>
//           <h2 style={{ margin: 0 }}>Dashboard</h2>
//           <button 
//             onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
//             style={{
//               backgroundColor: 'transparent',
//               border: 'none',
//               color: 'white',
//               fontSize: '24px',
//               cursor: 'pointer'
//             }}
//           >
//             ☰
//           </button>
//         </div>

//         {/* Content */}
//         <div style={{
//           padding: '30px',
//           maxWidth: '1200px',
//           margin: '0 auto'
//         }}>
//           <h1 style={{ 
//             color: '#002f34', 
//             marginBottom: '30px',
//             display: 'none',
//             '@media (min-width: 768px)': {
//               display: 'block'
//             }
//           }}>
//             {activeTab === 'posts' ? 'My Property Listings' : 
//              activeTab === 'purchases' ? 'My Purchases' : 
//              activeTab === 'clients' ? 'Interested Clients' : 'Dashboard'}
//           </h1>
          
//           {loading ? (
//             <div style={{ 
//               textAlign: 'center', 
//               padding: '40px',
//               backgroundColor: 'white',
//               borderRadius: '8px',
//               boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//             }}>
//               <p>Loading your data...</p>
//             </div>
//           ) : activeTab === 'posts' ? (
//             <div>
//               {userPosts.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Properties Listed</h3>
//                   <p style={{ color: '#666', marginBottom: '20px' }}>You haven't posted any properties yet.</p>
//                   <button
//                     onClick={() => navigate('/sell')}
//                     style={{
//                       backgroundColor: '#002f34',
//                       color: 'white',
//                       border: 'none',
//                       padding: '12px 25px',
//                       borderRadius: '4px',
//                       cursor: 'pointer',
//                       fontWeight: '600',
//                       fontSize: '16px',
//                       display: 'inline-flex',
//                       alignItems: 'center',
//                       gap: '8px',
//                       transition: 'all 0.2s',
//                       ':hover': {
//                         backgroundColor: '#004950'
//                       }
//                     }}
//                   >
//                     <FiPlusCircle /> Post a Property
//                   </button>
//                 </div>
//               ) : (
//                 <div>
//                   <div style={{
//                     display: 'flex',
//                     justifyContent: 'space-between',
//                     alignItems: 'center',
//                     marginBottom: '20px'
//                   }}>
//                     <h2 style={{ color: '#002f34', margin: 0 }}>
//                       My Properties ({userPosts.length})
//                     </h2>
//                     <button
//                       onClick={() => navigate('/sell')}
//                       style={{
//                         backgroundColor: '#002f34',
//                         color: 'white',
//                         border: 'none',
//                         padding: '10px 20px',
//                         borderRadius: '4px',
//                         cursor: 'pointer',
//                         fontWeight: '600',
//                         fontSize: '14px',
//                         display: 'flex',
//                         alignItems: 'center',
//                         gap: '8px',
//                         transition: 'all 0.2s',
//                         ':hover': {
//                           backgroundColor: '#004950'
//                         }
//                       }}
//                     >
//                       <FiPlusCircle size={16} /> Add New
//                     </button>
//                   </div>
                  
//                   <div style={{
//                     display: 'grid',
//                     gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//                     gap: '20px'
//                   }}>
//                     {userPosts.map((post) => (
//                       <div key={`${post.category}-${post.id}`} style={{
//                         backgroundColor: 'white',
//                         borderRadius: '8px',
//                         boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//                         overflow: 'hidden',
//                         transition: 'transform 0.2s',
//                         opacity: post.status === 'inactive' ? 0.7 : 1,
//                         ':hover': {
//                           transform: 'translateY(-5px)'
//                         }
//                       }}>
//                         {post.images?.[0] && (
//                           <div style={{ position: 'relative' }}>
//                             <img 
//                               src={post.images[0]} 
//                               alt={post.title}
//                               style={{
//                                 width: '100%',
//                                 height: '200px',
//                                 objectFit: 'cover',
//                                 borderBottom: '1px solid #eee'
//                               }}
//                             />
//                             {post.status === 'inactive' && (
//                               <div style={{
//                                 position: 'absolute',
//                                 top: '10px',
//                                 right: '10px',
//                                 backgroundColor: 'rgba(0,0,0,0.7)',
//                                 color: 'white',
//                                 padding: '5px 10px',
//                                 borderRadius: '4px',
//                                 fontSize: '12px',
//                                 fontWeight: 'bold'
//                               }}>
//                                 Inactive
//                               </div>
//                             )}
//                           </div>
//                         )}
//                         <div style={{ padding: '15px' }}>
//                           <h3 style={{ 
//                             margin: '0 0 10px', 
//                             color: '#002f34',
//                             fontSize: '18px',
//                             whiteSpace: 'nowrap',
//                             overflow: 'hidden',
//                             textOverflow: 'ellipsis'
//                           }}>
//                             {post.title}
//                           </h3>
//                           <div style={{
//                             display: 'flex',
//                             justifyContent: 'space-between',
//                             marginBottom: '10px'
//                           }}>
//                             <span style={{
//                               backgroundColor: '#e6f7f7',
//                               color: '#002f34',
//                               padding: '4px 8px',
//                               borderRadius: '4px',
//                               fontSize: '12px',
//                               fontWeight: '600'
//                             }}>
//                               {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
//                             </span>
//                             <p style={{ 
//                               margin: 0, 
//                               fontWeight: 'bold', 
//                               color: '#002f34',
//                               fontSize: '18px'
//                             }}>
//                               ₹{post.price?.toLocaleString('en-IN')}
//                             </p>
//                           </div>
//                           <div style={{ 
//                             display: 'flex', 
//                             justifyContent: 'space-between',
//                             gap: '10px',
//                             marginTop: '15px'
//                           }}>
//                             <button
//                               onClick={() => togglePropertyStatus(post.id, post.category)}
//                               style={{
//                                 padding: '8px 12px',
//                                 backgroundColor: post.status === 'inactive' ? '#4CAF50' : '#f44336',
//                                 color: 'white',
//                                 border: 'none',
//                                 borderRadius: '4px',
//                                 cursor: 'pointer',
//                                 fontWeight: '600',
//                                 fontSize: '14px',
//                                 display: 'flex',
//                                 alignItems: 'center',
//                                 gap: '5px'
//                               }}
//                             >
//                               {post.status === 'inactive' ? <FiEye size={14} /> : <FiEyeOff size={14} />}
//                               {post.status === 'inactive' ? 'Activate' : 'Deactivate'}
//                             </button>
                            
//                             <div style={{ display: 'flex', gap: '10px' }}>
//                               <button
//                                 onClick={() => handleEditProperty(post.id, post.category)}
//                                 style={{
//                                   padding: '8px 12px',
//                                   backgroundColor: '#2196F3',
//                                   color: 'white',
//                                   border: 'none',
//                                   borderRadius: '4px',
//                                   cursor: 'pointer',
//                                   fontWeight: '600',
//                                   fontSize: '14px',
//                                   display: 'flex',
//                                   alignItems: 'center',
//                                   gap: '5px'
//                                 }}
//                               >
//                                 <FiEdit size={14} /> Edit
//                               </button>
                              
//                               <button
//                                 onClick={() => handleDeleteProperty(post.id, post.category)}
//                                 style={{
//                                   padding: '8px 12px',
//                                   backgroundColor: '#ff5252',
//                                   color: 'white',
//                                   border: 'none',
//                                   borderRadius: '4px',
//                                   cursor: 'pointer',
//                                   fontWeight: '600',
//                                   fontSize: '14px',
//                                   display: 'flex',
//                                   alignItems: 'center',
//                                   gap: '5px'
//                                 }}
//                               >
//                                 <FiTrash2 size={14} /> Delete
//                               </button>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>
//           ) : activeTab === 'purchases' ? (
//             <div>
//               <h2 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '20px' 
//               }}>
//                 My Purchases ({purchases.length})
//               </h2>
//               {purchases.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Purchases Yet</h3>
//                   <p style={{ color: '#666' }}>You haven't made any purchases yet.</p>
//                 </div>
//               ) : (
//                 <div style={{
//                   backgroundColor: 'white',
//                   borderRadius: '8px',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
//                   overflow: 'hidden'
//                 }}>
//                   <table style={{
//                     width: '100%',
//                     borderCollapse: 'collapse'
//                   }}>
//                     <thead>
//                       <tr style={{
//                         backgroundColor: '#f8f9fa',
//                         borderBottom: '1px solid #eee'
//                       }}>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Property</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Date</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Amount</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Status</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {purchases.map((purchase, index) => (
//                         <tr key={index} style={{
//                           borderBottom: '1px solid #eee',
//                           ':last-child': {
//                             borderBottom: 'none'
//                           }
//                         }}>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: '500'
//                           }}>
//                             {purchase.propertyTitle}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {new Date(purchase.date).toLocaleDateString()}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: 'bold'
//                           }}>
//                             ₹{purchase.amount?.toLocaleString('en-IN')}
//                           </td>
//                           <td style={{
//                             padding: '15px'
//                           }}>
//                             <span style={{
//                               backgroundColor: purchase.status === 'Completed' ? '#e6f7f7' : '#fff8e1',
//                               color: purchase.status === 'Completed' ? '#002f34' : '#ff8f00',
//                               padding: '6px 12px',
//                               borderRadius: '20px',
//                               fontSize: '14px',
//                               fontWeight: '600'
//                             }}>
//                               {purchase.status || 'Completed'}
//                             </span>
//                           </td>
//                           <td style={{
//                             padding: '15px'
//                           }}>
//                             <button
//                               onClick={() => navigate(`/property/${purchase.propertyId}`)}
//                               style={{
//                                 backgroundColor: '#002f34',
//                                 color: 'white',
//                                 border: 'none',
//                                 padding: '8px 15px',
//                                 borderRadius: '4px',
//                                 cursor: 'pointer',
//                                 fontWeight: '600',
//                                 fontSize: '14px',
//                                 transition: 'all 0.2s',
//                                 ':hover': {
//                                   backgroundColor: '#004950'
//                                 }
//                               }}
//                             >
//                               View
//                             </button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//               )}
//             </div>
//           ) : activeTab === 'clients' ? (
//             <div>
//               <h2 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '20px' 
//               }}>
//                 Interested Clients ({interestedClients.length})
//               </h2>
              
//               {interestedClients.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Interested Clients Yet</h3>
//                   <p style={{ color: '#666' }}>You'll see interested clients here when they contact you about your properties.</p>
//                 </div>
//               ) : (
//                 <div style={{
//                   backgroundColor: 'white',
//                   borderRadius: '8px',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
//                   overflow: 'hidden'
//                 }}>
//                   <table style={{
//                     width: '100%',
//                     borderCollapse: 'collapse'
//                   }}>
//                     <thead>
//                       <tr style={{
//                         backgroundColor: '#f8f9fa',
//                         borderBottom: '1px solid #eee'
//                       }}>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Property</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Client</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Contact</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Message</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {interestedClients.map((client, index) => (
//                         <tr key={index} style={{
//                           borderBottom: '1px solid #eee',
//                           ':last-child': {
//                             borderBottom: 'none'
//                           }
//                         }}>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: '500'
//                           }}>
//                             {client.propertyTitle}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             {client.name}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             <div style={{ marginBottom: '5px' }}>{client.mobile}</div>
//                             <div style={{ color: '#666', fontSize: '14px' }}>{client.email}</div>
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {client.message || 'No message'}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {new Date(client.timestamp).toLocaleDateString()}
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//               )}
//             </div>
//           ) : null}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;