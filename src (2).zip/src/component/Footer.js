import React from 'react';

const Footer = () => {
  return (
    <footer style={{
      backgroundColor: '#002f34',
      color: 'white',
      padding: '60px 20px 30px',
      marginTop: '80px'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '40px'
      }}>
        <div>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            marginBottom: '20px'
          }}>
            <div style={{
              backgroundColor: '#23e5db',
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginRight: '12px'
            }}>
              <span style={{
                color: '#002f34',
                fontSize: '20px',
                fontWeight: 'bold'
              }}>O</span>
            </div>
            <h3 style={{ 
              color: 'white', 
              margin: 0,
              fontSize: '24px',
              fontWeight: '800'
            }}>OLX</h3>
          </div>
          <p style={{
            color: '#c0c0c0',
            lineHeight: '1.6',
            fontSize: '15px'
          }}>
            The leading marketplace for buying and selling goods and services. Join millions of users today.
          </p>
          <div style={{
            display: 'flex',
            gap: '15px',
            marginTop: '20px'
          }}>
            <button style={{
              backgroundColor: 'white',
              color: '#002f34',
              border: 'none',
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              ':hover': {
                transform: 'translateY(-3px)'
              }
            }}>
              <span style={{ fontSize: '20px' }}>👍</span>
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#002f34',
              border: 'none',
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              ':hover': {
                transform: 'translateY(-3px)'
              }
            }}>
              <span style={{ fontSize: '20px' }}>👎</span>
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#002f34',
              border: 'none',
              width: '40px',
              height: '40px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              ':hover': {
                transform: 'translateY(-3px)'
              }
            }}>
              <span style={{ fontSize: '20px' }}>❤️</span>
            </button>
          </div>
        </div>
        
        <div>
          <h4 style={{ 
            marginTop: 0,
            marginBottom: '20px',
            fontSize: '18px',
            fontWeight: '700'
          }}>Quick Links</h4>
          <ul style={{ 
            listStyle: 'none', 
            padding: 0,
            display: 'grid',
            gap: '12px'
          }}>
            {['About Us', 'Careers', 'Blog', 'Press', 'Contact Us'].map(item => (
              <li key={item}>
                <a href="#" style={{ 
                  color: '#c0c0c0',
                  textDecoration: 'none',
                  transition: 'all 0.2s ease',
                  ':hover': {
                    color: 'white'
                  }
                }}>{item}</a>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <h4 style={{ 
            marginTop: 0,
            marginBottom: '20px',
            fontSize: '18px',
            fontWeight: '700'
          }}>Help & Support</h4>
          <ul style={{ 
            listStyle: 'none', 
            padding: 0,
            display: 'grid',
            gap: '12px'
          }}>
            {['Help Center', 'Safety Tips', 'Privacy Policy', 'Terms of Service', 'FAQ'].map(item => (
              <li key={item}>
                <a href="#" style={{ 
                  color: '#c0c0c0',
                  textDecoration: 'none',
                  transition: 'all 0.2s ease',
                  ':hover': {
                    color: 'white'
                  }
                }}>{item}</a>
              </li>
            ))}
          </ul>
        </div>
        
        <div>
          <h4 style={{ 
            marginTop: 0,
            marginBottom: '20px',
            fontSize: '18px',
            fontWeight: '700'
          }}>Download Our App</h4>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '15px'
          }}>
            <button style={{
              backgroundColor: 'white',
              color: '#002f34',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease',
              ':hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
              }
            }}>
              <span style={{ marginRight: '10px', fontSize: '20px' }}>📱</span>
              App Store
            </button>
            <button style={{
              backgroundColor: 'white',
              color: '#002f34',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease',
              ':hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
              }
            }}>
              <span style={{ marginRight: '10px', fontSize: '20px' }}>🤖</span>
              Google Play
            </button>
          </div>
        </div>
      </div>
      
      <div style={{
        maxWidth: '1200px',
        margin: '50px auto 0',
        paddingTop: '30px',
        borderTop: '1px solid rgba(255,255,255,0.1)',
        textAlign: 'center',
        fontSize: '14px',
        color: '#c0c0c0'
      }}>
        © {new Date().getFullYear()} OLX Clone. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;