
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const Navbar = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [showProfileModal, setShowProfileModal] = useState(false);

  const toggleProfileModal = () => {
    setShowProfileModal(!showProfileModal);
  };
  return (
    <header style={{
      background: 'linear-gradient(135deg, #002f34 0%, #005f6b 100%)',
      padding: '15px 0',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      boxShadow: '0 4px 12px rgba(0, 47, 52, 0.1)'
    }}>
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        padding: '0 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
       <div style={{
          display: 'flex',
          alignItems: 'center',
          cursor: 'pointer'
        }} onClick={() => window.scrollTo(0, 0)}>
          <div style={{
            backgroundColor: '#23e5db',
            width: '40px',
            height: '40px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: '10px'
          }}>
            <span style={{
              color: '#002f34',
              fontSize: '20px',
              fontWeight: 'bold'
            }}>O</span>
          </div>
          <h1 style={{
            color: 'white',
            margin: 0,
            fontSize: '24px',
            fontWeight: '800',
            letterSpacing: '-0.5px'
          }}>RealEstate</h1>
        </div>

        {/* Search Bar */}
        <div style={{
          flex: 1,
          maxWidth: '600px',
          margin: '0 20px',
          position: 'relative'
        }}>
          <div style={{
            display: 'flex',
            backgroundColor: 'white',
            borderRadius: '8px',
            overflow: 'hidden',
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <input
              type="text"
              placeholder="Search for cars, phones, clothes..."
              style={{
                flex: 1,
                padding: '12px 20px',
                border: 'none',
                fontSize: '16px',
                outline: 'none'
              }}
            />
            <button style={{
              backgroundColor: '#23e5db',
              color: '#002f34',
              border: 'none',
              padding: '0 20px',
              cursor: 'pointer',
              fontWeight: '600',
              display: 'flex',
              alignItems: 'center'
            }}>
              <span style={{ marginRight: '8px' }}>🔍</span>
              Search
            </button>
          </div>
        </div>
        {/* Navigation */}
        <nav>
          <ul style={{
            display: 'flex',
            listStyle: 'none',
            margin: 0,
            padding: 0,
            gap: '15px'
          }}>

<li>
            <button
              onClick={() => navigate('/sell')}
              style={{
                backgroundColor: '#ffce32',
                border: 'none',
                color: '#002f34',
                cursor: 'pointer',
                fontWeight: '600',
                padding: '10px 20px',
                borderRadius: '8px',
                fontSize: '16px',
                display: 'flex',
                alignItems: 'center',
                transition: 'all 0.2s ease',
                ':hover': {
                  transform: 'translateY(-2px)',
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                }
              }}
            >
              <span style={{ marginRight: '8px', fontSize: '20px' }}>💰</span>
              Sell
            </button>
          </li>

          {/* Profile Button */}
          {user && (
            <li style={{ position: 'relative' }}>
              <button 
                onClick={toggleProfileModal}
                style={{
                  backgroundColor: 'transparent',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  display: 'flex',
                  alignItems: 'center',
                  padding: '8px 12px',
                  borderRadius: '8px',
                  transition: 'all 0.2s ease',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <span style={{ marginRight: '8px', fontSize: '20px' }}>👤</span>
                Profile
              </button>

              {/* Profile Modal/Dropdown */}
              {showProfileModal && (
                <div style={{
                  position: 'absolute',
                  right: 0,
                  top: '100%',
                  backgroundColor: 'white',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                  width: '300px',
                  padding: '20px',
                  zIndex: 101,
                  marginTop: '10px'
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    marginBottom: '20px'
                  }}>
                    <div style={{
                      width: '60px',
                      height: '60px',
                      borderRadius: '50%',
                      backgroundColor: '#23e5db',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      marginRight: '15px',
                      fontSize: '24px',
                      color: '#002f34',
                      fontWeight: 'bold'
                    }}>
                      {user.username ? user.username.charAt(0).toUpperCase() : 'U'}
                    </div>
                    <div>
                      <h3 style={{ margin: 0, color: '#002f34' }}>{user.username || 'User'}</h3>
                      <p style={{ margin: '5px 0 0', color: '#666', fontSize: '14px' }}>{user.mobile}</p>
                    </div>
                  </div>

                  <div style={{
                    borderTop: '1px solid #eee',
                    paddingTop: '15px'
                  }}>
                    {/* Add Dashboard Button */}
                    <button
                      onClick={() => {
                        navigate('/dashboard');
                        setShowProfileModal(false);
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        width: '100%',
                        padding: '10px',
                        backgroundColor: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        color: '#002f34',
                        fontSize: '15px',
                        borderRadius: '4px',
                        ':hover': {
                          backgroundColor: '#f5f5f5'
                        }
                      }}
                    >
                      <span style={{ marginRight: '10px' }}>📊</span>
                      Dashboard
                    </button>

                    <button
                      onClick={() => {
                        navigate('/settings');
                        setShowProfileModal(false);
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        width: '100%',
                        padding: '10px',
                        backgroundColor: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        color: '#002f34',
                        fontSize: '15px',
                        borderRadius: '4px',
                        ':hover': {
                          backgroundColor: '#f5f5f5'
                        }
                      }}
                    >
                      <span style={{ marginRight: '10px' }}>⚙️</span>
                      Account Settings
                    </button>

                    <button
                      onClick={() => {
                        logout();
                        setShowProfileModal(false);
                        navigate('/');
                      }}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        width: '100%',
                        padding: '10px',
                        backgroundColor: 'transparent',
                        border: 'none',
                        cursor: 'pointer',
                        color: '#002f34',
                        fontSize: '15px',
                        borderRadius: '4px',
                        marginTop: '5px',
                        ':hover': {
                          backgroundColor: '#f5f5f5'
                        }
                      }}
                    >
                      <span style={{ marginRight: '10px' }}>🚪</span>
                      Logout
                    </button>
                  </div>
                </div>
              )}
            </li>
          )}

          </ul>
        </nav>
      </div>

      {/* Click outside to close modal */}
      {showProfileModal && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 100,
            backgroundColor: 'rgba(0,0,0,0.1)'
          }}
          onClick={toggleProfileModal}
        />
      )}
    </header>
  );
};

export default Navbar;

