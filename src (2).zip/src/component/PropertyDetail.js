// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';
// import { getDatabase, ref, onValue } from 'firebase/database';

// const PropertyDetail = () => {
//   const { category, id } = useParams();
//   const [property, setProperty] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [sellerInfo, setSellerInfo] = useState(null);

//   useEffect(() => {
//     const db = getDatabase();
//     const customersRef = ref(db, 'delar/customers');
    
//     onValue(customersRef, (snapshot) => {
//       const customers = snapshot.val();
//       if (customers) {
//         // Find the property across all customers
//         for (const [mobile, customer] of Object.entries(customers)) {
//           if (customer.properties && customer.properties[category] && customer.properties[category][id]) {
//             setProperty({
//               ...customer.properties[category][id],
//               id,
//               category,
//               sellerMobile: mobile
//             });
//             setSellerInfo({
//               name: customer.username,
//               mobile: customer.mobile,
//               address: customer.address
//             });
//             break;
//           }
//         }
//       }
//       setLoading(false);
//     });

//     return () => onValue(customersRef, () => {});
//   }, [category, id]);

//   if (loading) {
//     return <div style={{ textAlign: 'center', padding: '40px' }}>Loading...</div>;
//   }

//   if (!property) {
//     return <div style={{ textAlign: 'center', padding: '40px' }}>Property not found</div>;
//   }

//   return (
//     <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
//       <div style={{ 
//         backgroundColor: 'white',
//         borderRadius: '8px',
//         boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//         overflow: 'hidden'
//       }}>
//         {/* Image Gallery */}
//         <div style={{
//           display: 'grid',
//           gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//           gap: '10px',
//           padding: '20px'
//         }}>
//           {property.images?.map((image, index) => (
//             <img 
//               key={index}
//               src={image}
//               alt={`Property ${index + 1}`}
//               style={{
//                 width: '100%',
//                 height: '250px',
//                 objectFit: 'cover',
//                 borderRadius: '4px'
//               }}
//             />
//           ))}
//         </div>

//         {/* Property Details */}
//         <div style={{ padding: '20px' }}>
//           <h1 style={{ color: '#002f34', marginBottom: '10px' }}>{property.title}</h1>
//           <div style={{ 
//             display: 'flex',
//             justifyContent: 'space-between',
//             alignItems: 'center',
//             marginBottom: '20px'
//           }}>
//             <h2 style={{ color: '#002f34', margin: 0 }}>
//               ₹{property.price?.toLocaleString('en-IN')}
//             </h2>
//             <span style={{
//               backgroundColor: '#23e5db',
//               color: '#002f34',
//               padding: '5px 10px',
//               borderRadius: '4px',
//               fontWeight: '600',
//               textTransform: 'capitalize'
//             }}>
//               {property.category}
//             </span>
//           </div>

//           <div style={{ 
//             display: 'grid',
//             gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
//             gap: '20px',
//             marginBottom: '30px'
//           }}>
//             {property.bedrooms && (
//               <div>
//                 <h4 style={{ color: '#666', margin: '0 0 5px' }}>Bedrooms</h4>
//                 <p style={{ margin: 0, fontWeight: '600' }}>{property.bedrooms}</p>
//               </div>
//             )}
//             {property.bathrooms && (
//               <div>
//                 <h4 style={{ color: '#666', margin: '0 0 5px' }}>Bathrooms</h4>
//                 <p style={{ margin: 0, fontWeight: '600' }}>{property.bathrooms}</p>
//               </div>
//             )}
//             {(property.area || property.plotArea) && (
//               <div>
//                 <h4 style={{ color: '#666', margin: '0 0 5px' }}>Area</h4>
//                 <p style={{ margin: 0, fontWeight: '600' }}>
//                   {property.area ? `${property.area} sq.ft` : `${property.plotArea} ${property.category === 'land' ? 'acres' : 'sq.yd'}`}
//                 </p>
//               </div>
//             )}
//             {property.furnished && (
//               <div>
//                 <h4 style={{ color: '#666', margin: '0 0 5px' }}>Furnishing</h4>
//                 <p style={{ margin: 0, fontWeight: '600', textTransform: 'capitalize' }}>
//                   {property.furnished}
//                 </p>
//               </div>
//             )}
//           </div>

//           <div style={{ marginBottom: '30px' }}>
//             <h3 style={{ color: '#002f34', marginBottom: '10px' }}>Description</h3>
//             <p style={{ lineHeight: '1.6' }}>{property.description}</p>
//           </div>

//           <div style={{ marginBottom: '30px' }}>
//             <h3 style={{ color: '#002f34', marginBottom: '10px' }}>Location</h3>
//             <p>{property.location}</p>
//             {/* You could add a map here using Google Maps or similar */}
//           </div>

//           {/* Seller Information */}
//           <div style={{ 
//             backgroundColor: '#f5f5f5',
//             borderRadius: '8px',
//             padding: '20px',
//             marginTop: '30px'
//           }}>
//             <h3 style={{ color: '#002f34', marginBottom: '15px' }}>Contact Seller</h3>
//             {sellerInfo && (
//               <div style={{
//                 display: 'grid',
//                 gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
//                 gap: '20px'
//               }}>
//                 <div>
//                   <h4 style={{ color: '#666', margin: '0 0 5px' }}>Name</h4>
//                   <p style={{ margin: 0, fontWeight: '600' }}>{sellerInfo.name}</p>
//                 </div>
//                 <div>
//                   <h4 style={{ color: '#666', margin: '0 0 5px' }}>Mobile</h4>
//                   <p style={{ margin: 0, fontWeight: '600' }}>{sellerInfo.mobile}</p>
//                 </div>
//                 <div>
//                   <h4 style={{ color: '#666', margin: '0 0 5px' }}>Address</h4>
//                   <p style={{ margin: 0, fontWeight: '600' }}>{sellerInfo.address}</p>
//                 </div>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PropertyDetail;



















// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';
// import { getDatabase, ref, onValue } from 'firebase/database';

// const PropertyDetail = () => {
//   const { category, id } = useParams();
//   const [property, setProperty] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [sellerInfo, setSellerInfo] = useState(null);
//   const [showOfferForm, setShowOfferForm] = useState(false);
//   const [offerForm, setOfferForm] = useState({
//     name: '',
//     email: '',
//     phone: '',
//     offerAmount: '',
//     message: ''
//   });

//   useEffect(() => {
//     const db = getDatabase();
//     const customersRef = ref(db, 'delar/customers');
    
//     onValue(customersRef, (snapshot) => {
//       const customers = snapshot.val();
//       if (customers) {
//         for (const [mobile, customer] of Object.entries(customers)) {
//           if (customer.properties && customer.properties[category] && customer.properties[category][id]) {
//             setProperty({
//               ...customer.properties[category][id],
//               id,
//               category,
//               sellerMobile: mobile
//             });
//             setSellerInfo({
//               name: customer.username,
//               mobile: customer.mobile,
//               address: customer.address
//             });
//             break;
//           }
//         }
//       }
//       setLoading(false);
//     });

//     return () => onValue(customersRef, () => {});
//   }, [category, id]);

//   const handleOfferChange = (e) => {
//     const { name, value } = e.target;
//     setOfferForm(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };

//   const handleOfferSubmit = (e) => {
//     e.preventDefault();
//     // Here you would typically send the offer to your backend
//     console.log('Offer submitted:', {
//       ...offerForm,
//       propertyId: id,
//       propertyTitle: property.title,
//       sellerMobile: sellerInfo.mobile
//     });
//     alert('Your offer has been submitted successfully!');
//     setShowOfferForm(false);
//     // Reset form
//     setOfferForm({
//       name: '',
//       email: '',
//       phone: '',
//       offerAmount: '',
//       message: ''
//     });
//   };

//   if (loading) {
//     return <div style={{ 
//       textAlign: 'center', 
//       padding: '40px',
//       fontSize: '18px',
//       color: '#002f34'
//     }}>Loading property details...</div>;
//   }

//   if (!property) {
//     return <div style={{ 
//       textAlign: 'center', 
//       padding: '40px',
//       fontSize: '18px',
//       color: '#002f34'
//     }}>Property not found</div>;
//   }

//   return (
//     <div style={{ 
//       maxWidth: '1200px', 
//       margin: '0 auto', 
//       padding: '20px',
//       fontFamily: '"Roboto", sans-serif'
//     }}>
//       {/* Offer Form Modal */}
//       {showOfferForm && (
//         <div style={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           right: 0,
//           bottom: 0,
//           backgroundColor: 'rgba(0,47,52,0.8)',
//           display: 'flex',
//           justifyContent: 'center',
//           alignItems: 'center',
//           zIndex: 1000,
//           padding: '20px'
//         }}>
//           <div style={{
//             backgroundColor: 'white',
//             borderRadius: '8px',
//             padding: '30px',
//             width: '100%',
//             maxWidth: '500px',
//             boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
//             position: 'relative'
//           }}>
//             <button 
//               onClick={() => setShowOfferForm(false)}
//               style={{
//                 position: 'absolute',
//                 top: '15px',
//                 right: '15px',
//                 background: 'none',
//                 border: 'none',
//                 fontSize: '24px',
//                 cursor: 'pointer',
//                 color: '#666',
//                 padding: '5px'
//               }}
//             >
//               &times;
//             </button>
            
//             <h2 style={{ 
//               color: '#002f34', 
//               margin: '0 0 20px',
//               fontSize: '24px'
//             }}>
//               Make an Offer for {property.title}
//             </h2>
            
//             <form onSubmit={handleOfferSubmit}>
//               <div style={{ marginBottom: '20px' }}>
//                 <label style={{
//                   display: 'block',
//                   marginBottom: '8px',
//                   fontWeight: '600',
//                   color: '#333',
//                   fontSize: '14px'
//                 }}>
//                   Your Full Name *
//                 </label>
//                 <input
//                   type="text"
//                   name="name"
//                   value={offerForm.name}
//                   onChange={handleOfferChange}
//                   required
//                   style={{
//                     width: '100%',
//                     padding: '12px',
//                     border: '1px solid #ddd',
//                     borderRadius: '4px',
//                     fontSize: '16px',
//                     boxSizing: 'border-box'
//                   }}
//                   placeholder="Enter your name"
//                 />
//               </div>
              
//               <div style={{ marginBottom: '20px' }}>
//                 <label style={{
//                   display: 'block',
//                   marginBottom: '8px',
//                   fontWeight: '600',
//                   color: '#333',
//                   fontSize: '14px'
//                 }}>
//                   Email Address *
//                 </label>
//                 <input
//                   type="email"
//                   name="email"
//                   value={offerForm.email}
//                   onChange={handleOfferChange}
//                   required
//                   style={{
//                     width: '100%',
//                     padding: '12px',
//                     border: '1px solid #ddd',
//                     borderRadius: '4px',
//                     fontSize: '16px',
//                     boxSizing: 'border-box'
//                   }}
//                   placeholder="Enter your email"
//                 />
//               </div>
              
//               <div style={{ marginBottom: '20px' }}>
//                 <label style={{
//                   display: 'block',
//                   marginBottom: '8px',
//                   fontWeight: '600',
//                   color: '#333',
//                   fontSize: '14px'
//                 }}>
//                   Phone Number *
//                 </label>
//                 <input
//                   type="tel"
//                   name="phone"
//                   value={offerForm.phone}
//                   onChange={handleOfferChange}
//                   required
//                   style={{
//                     width: '100%',
//                     padding: '12px',
//                     border: '1px solid #ddd',
//                     borderRadius: '4px',
//                     fontSize: '16px',
//                     boxSizing: 'border-box'
//                   }}
//                   placeholder="Enter your phone number"
//                 />
//               </div>
              
//               <div style={{ marginBottom: '20px' }}>
//                 <label style={{
//                   display: 'block',
//                   marginBottom: '8px',
//                   fontWeight: '600',
//                   color: '#333',
//                   fontSize: '14px'
//                 }}>
//                   Your Offer Amount (₹) *
//                 </label>
//                 <div style={{ position: 'relative' }}>
//                   <span style={{
//                     position: 'absolute',
//                     left: '12px',
//                     top: '12px',
//                     color: '#666',
//                     fontWeight: '600'
//                   }}>
//                     ₹
//                   </span>
//                   <input
//                     type="number"
//                     name="offerAmount"
//                     value={offerForm.offerAmount}
//                     onChange={handleOfferChange}
//                     required
//                     style={{
//                       width: '100%',
//                       padding: '12px 12px 12px 30px',
//                       border: '1px solid #ddd',
//                       borderRadius: '4px',
//                       fontSize: '16px',
//                       boxSizing: 'border-box'
//                     }}
//                     placeholder="Enter your offer amount"
//                     min="1"
//                   />
//                 </div>
//                 <p style={{
//                   margin: '5px 0 0',
//                   fontSize: '12px',
//                   color: '#666'
//                 }}>
//                   Current price: ₹{property.price?.toLocaleString('en-IN')}
//                 </p>
//               </div>
              
//               <div style={{ marginBottom: '25px' }}>
//                 <label style={{
//                   display: 'block',
//                   marginBottom: '8px',
//                   fontWeight: '600',
//                   color: '#333',
//                   fontSize: '14px'
//                 }}>
//                   Message to Seller
//                 </label>
//                 <textarea
//                   name="message"
//                   value={offerForm.message}
//                   onChange={handleOfferChange}
//                   rows="4"
//                   style={{
//                     width: '100%',
//                     padding: '12px',
//                     border: '1px solid #ddd',
//                     borderRadius: '4px',
//                     fontSize: '16px',
//                     resize: 'vertical',
//                     boxSizing: 'border-box'
//                   }}
//                   placeholder="Write your message (optional)"
//                 />
//               </div>
              
//               <button
//                 type="submit"
//                 style={{
//                   backgroundColor: '#23e5db',
//                   color: '#002f34',
//                   border: 'none',
//                   padding: '14px 20px',
//                   borderRadius: '4px',
//                   fontSize: '16px',
//                   fontWeight: '600',
//                   cursor: 'pointer',
//                   width: '100%',
//                   transition: 'all 0.3s ease',
//                   ':hover': {
//                     backgroundColor: '#1fd1d1',
//                     transform: 'translateY(-2px)'
//                   }
//                 }}
//               >
//                 Submit Offer
//               </button>
//             </form>
//           </div>
//         </div>
//       )}

//       {/* Property Detail Content */}
//       <div style={{ 
//         backgroundColor: 'white',
//         borderRadius: '8px',
//         boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//         overflow: 'hidden',
//         marginBottom: '30px'
//       }}>
//         {/* Image Gallery */}
//         <div style={{
//           display: 'grid',
//           gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//           gap: '10px',
//           padding: '20px'
//         }}>
//           {property.images?.map((image, index) => (
//             <img 
//               key={index}
//               src={image}
//               alt={`Property ${index + 1}`}
//               style={{
//                 width: '100%',
//                 height: '250px',
//                 objectFit: 'cover',
//                 borderRadius: '4px',
//                 boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
//               }}
//             />
//           ))}
//         </div>

//         {/* Property Details */}
//         <div style={{ padding: '20px' }}>
//           <h1 style={{ 
//             color: '#002f34', 
//             marginBottom: '10px',
//             fontSize: '28px',
//             fontWeight: '700'
//           }}>
//             {property.title}
//           </h1>
          
//           <div style={{ 
//             display: 'flex',
//             justifyContent: 'space-between',
//             alignItems: 'center',
//             marginBottom: '20px',
//             flexWrap: 'wrap',
//             gap: '15px'
//           }}>
//             <h2 style={{ 
//               color: '#002f34', 
//               margin: 0,
//               fontSize: '24px'
//             }}>
//               ₹{property.price?.toLocaleString('en-IN')}
//             </h2>
//             <span style={{
//               backgroundColor: '#23e5db',
//               color: '#002f34',
//               padding: '6px 12px',
//               borderRadius: '4px',
//               fontWeight: '600',
//               textTransform: 'capitalize',
//               fontSize: '14px'
//             }}>
//               {property.category}
//             </span>
//           </div>

//           {/* Key Features */}
//           <div style={{ 
//             display: 'grid',
//             gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
//             gap: '20px',
//             marginBottom: '30px',
//             padding: '15px',
//             backgroundColor: '#f9f9f9',
//             borderRadius: '8px'
//           }}>
//             {property.bedrooms && (
//               <div>
//                 <h4 style={{ 
//                   color: '#666', 
//                   margin: '0 0 5px',
//                   fontSize: '14px'
//                 }}>
//                   Bedrooms
//                 </h4>
//                 <p style={{ 
//                   margin: 0, 
//                   fontWeight: '600',
//                   fontSize: '18px',
//                   color: '#002f34'
//                 }}>
//                   {property.bedrooms}
//                 </p>
//               </div>
//             )}
//             {property.bathrooms && (
//               <div>
//                 <h4 style={{ 
//                   color: '#666', 
//                   margin: '0 0 5px',
//                   fontSize: '14px'
//                 }}>
//                   Bathrooms
//                 </h4>
//                 <p style={{ 
//                   margin: 0, 
//                   fontWeight: '600',
//                   fontSize: '18px',
//                   color: '#002f34'
//                 }}>
//                   {property.bathrooms}
//                 </p>
//               </div>
//             )}
//             {(property.area || property.plotArea) && (
//               <div>
//                 <h4 style={{ 
//                   color: '#666', 
//                   margin: '0 0 5px',
//                   fontSize: '14px'
//                 }}>
//                   Area
//                 </h4>
//                 <p style={{ 
//                   margin: 0, 
//                   fontWeight: '600',
//                   fontSize: '18px',
//                   color: '#002f34'
//                 }}>
//                   {property.area ? `${property.area} sq.ft` : 
//                    `${property.plotArea} ${property.category === 'land' ? 'acres' : 'sq.yd'}`}
//                 </p>
//               </div>
//             )}
//             {property.furnished && (
//               <div>
//                 <h4 style={{ 
//                   color: '#666', 
//                   margin: '0 0 5px',
//                   fontSize: '14px'
//                 }}>
//                   Furnishing
//                 </h4>
//                 <p style={{ 
//                   margin: 0, 
//                   fontWeight: '600',
//                   fontSize: '18px',
//                   color: '#002f34',
//                   textTransform: 'capitalize'
//                 }}>
//                   {property.furnished}
//                 </p>
//               </div>
//             )}
//           </div>

//           {/* Description */}
//           <div style={{ marginBottom: '30px' }}>
//             <h3 style={{ 
//               color: '#002f34', 
//               marginBottom: '15px',
//               fontSize: '20px'
//             }}>
//               Description
//             </h3>
//             <p style={{ 
//               lineHeight: '1.6',
//               color: '#333',
//               fontSize: '16px'
//             }}>
//               {property.description}
//             </p>
//           </div>

//           {/* Location */}
//           <div style={{ marginBottom: '30px' }}>
//             <h3 style={{ 
//               color: '#002f34', 
//               marginBottom: '15px',
//               fontSize: '20px'
//             }}>
//               Location
//             </h3>
//             <p style={{
//               color: '#333',
//               fontSize: '16px'
//             }}>
//               {property.location}
//             </p>
//             {/* Placeholder for map integration */}
//             <div style={{
//               height: '200px',
//               backgroundColor: '#f5f5f5',
//               borderRadius: '8px',
//               marginTop: '15px',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               color: '#666'
//             }}>
//               [Map would be displayed here]
//             </div>
//           </div>

//           {/* Contact Seller Section */}
//           <div style={{ 
//             backgroundColor: '#f5f5f5',
//             borderRadius: '8px',
//             padding: '25px',
//             marginTop: '30px'
//           }}>
//             <h3 style={{ 
//               color: '#002f34', 
//               marginBottom: '20px',
//               fontSize: '20px'
//             }}>
//               Contact Seller
//             </h3>
            
//             {sellerInfo && (
//               <>
             
                
//                 <div style={{
//                   display: 'flex',
//                   gap: '15px',
//                   flexWrap: 'wrap'
//                 }}>
//                   <button
//                     onClick={() => setShowOfferForm(true)}
//                     style={{
//                       backgroundColor: '#23e5db',
//                       color: '#002f34',
//                       border: 'none',
//                       padding: '12px 24px',
//                       borderRadius: '4px',
//                       fontSize: '16px',
//                       fontWeight: '600',
//                       cursor: 'pointer',
//                       transition: 'all 0.3s ease',
//                       flex: '1',
//                       minWidth: '180px',
//                       ':hover': {
//                         backgroundColor: '#1fd1d1',
//                         transform: 'translateY(-2px)'
//                       }
//                     }}
//                   >
//                     Make Offer
//                   </button>
                  
//                   <a
//                     href={`tel:${sellerInfo.mobile}`}
//                     style={{
//                       backgroundColor: '#002f34',
//                       color: 'white',
//                       border: 'none',
//                       padding: '12px 24px',
//                       borderRadius: '4px',
//                       fontSize: '16px',
//                       fontWeight: '600',
//                       cursor: 'pointer',
//                       textDecoration: 'none',
//                       textAlign: 'center',
//                       transition: 'all 0.3s ease',
//                       flex: '1',
//                       minWidth: '180px',
//                       ':hover': {
//                         backgroundColor: '#001a1d',
//                         transform: 'translateY(-2px)'
//                       }
//                     }}
//                   >
//                     Call Now
//                   </a>
//                 </div>
//               </>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PropertyDetail;









import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getDatabase, ref, onValue, push, set } from 'firebase/database';

const PropertyDetail = () => {
  const { category, id } = useParams();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sellerInfo, setSellerInfo] = useState(null);
  const [showOfferForm, setShowOfferForm] = useState(false);
  const [offerForm, setOfferForm] = useState({
    name: '',
    email: '',
    phone: '',
    offerAmount: '',
    message: ''
  });

  useEffect(() => {
    const db = getDatabase();
    const customersRef = ref(db, 'delar/customers');
    
    onValue(customersRef, (snapshot) => {
      const customers = snapshot.val();
      if (customers) {
        for (const [mobile, customer] of Object.entries(customers)) {
          if (customer.properties && customer.properties[category] && customer.properties[category][id]) {
            setProperty({
              ...customer.properties[category][id],
              id,
              category,
              sellerMobile: mobile
            });
            setSellerInfo({
              name: customer.username,
              mobile: customer.mobile,
              address: customer.address
            });
            break;
          }
        }
      }
      setLoading(false);
    });

    return () => onValue(customersRef, () => {});
  }, [category, id]);

  const handleOfferChange = (e) => {
    const { name, value } = e.target;
    setOfferForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleOfferSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const db = getDatabase();
      const offersRef = ref(db, 'delar/admin/offers');
      
      // Create a new offer with an auto-generated ID
      const newOfferRef = push(offersRef);
      
      // Prepare the offer data
      const offerData = {
        ...offerForm,
        propertyId: id,
        propertyTitle: property.title,
        propertyCategory: category,
        propertyPrice: property.price,
        sellerMobile: sellerInfo.mobile,
        sellerName: sellerInfo.name,
        timestamp: Date.now(),
        status: 'pending' // You can add status for tracking
      };
      
      // Save the offer to Firebase
      await set(newOfferRef, offerData);
      
      alert('Your offer has been submitted successfully!');
      setShowOfferForm(false);
      // Reset form
      setOfferForm({
        name: '',
        email: '',
        phone: '',
        offerAmount: '',
        message: ''
      });
      
    } catch (error) {
      console.error('Error submitting offer:', error);
      alert('There was an error submitting your offer. Please try again.');
    }
  };

  if (loading) {
    return <div style={{ 
      textAlign: 'center', 
      padding: '40px',
      fontSize: '18px',
      color: '#002f34'
    }}>Loading property details...</div>;
  }

  if (!property) {
    return <div style={{ 
      textAlign: 'center', 
      padding: '40px',
      fontSize: '18px',
      color: '#002f34'
    }}>Property not found</div>;
  }


  

  //   <div style={{ 
  //     maxWidth: '1200px', 
  //     margin: '0 auto', 
  //     padding: '20px',
  //     fontFamily: '"Roboto", sans-serif'
  //   }}>
  //     {/* Offer Form Modal */}
  //     {showOfferForm && (
  //       <div style={{
  //         position: 'fixed',
  //         top: 0,
  //         left: 0,
  //         right: 0,
  //         bottom: 0,
  //         backgroundColor: 'rgba(0,47,52,0.8)',
  //         display: 'flex',
  //         justifyContent: 'center',
  //         alignItems: 'center',
  //         zIndex: 1000,
  //         padding: '20px'
  //       }}>
  //         <div style={{
  //           backgroundColor: 'white',
  //           borderRadius: '8px',
  //           padding: '30px',
  //           width: '100%',
  //           maxWidth: '500px',
  //           boxShadow: '0 4px 20px rgba(0,0,0,0.2)',
  //           position: 'relative'
  //         }}>
  //           <button 
  //             onClick={() => setShowOfferForm(false)}
  //             style={{
  //               position: 'absolute',
  //               top: '15px',
  //               right: '15px',
  //               background: 'none',
  //               border: 'none',
  //               fontSize: '24px',
  //               cursor: 'pointer',
  //               color: '#666',
  //               padding: '5px'
  //             }}
  //           >
  //             &times;
  //           </button>
            
  //           <h2 style={{ 
  //             color: '#002f34', 
  //             margin: '0 0 20px',
  //             fontSize: '24px'
  //           }}>
  //             Make an Offer for {property.title}
  //           </h2>
            
  //           <form onSubmit={handleOfferSubmit}>
  //             <div style={{ marginBottom: '20px' }}>
  //               <label style={{
  //                 display: 'block',
  //                 marginBottom: '8px',
  //                 fontWeight: '600',
  //                 color: '#333',
  //                 fontSize: '14px'
  //               }}>
  //                 Your Full Name *
  //               </label>
  //               <input
  //                 type="text"
  //                 name="name"
  //                 value={offerForm.name}
  //                 onChange={handleOfferChange}
  //                 required
  //                 style={{
  //                   width: '100%',
  //                   padding: '12px',
  //                   border: '1px solid #ddd',
  //                   borderRadius: '4px',
  //                   fontSize: '16px',
  //                   boxSizing: 'border-box'
  //                 }}
  //                 placeholder="Enter your name"
  //               />
  //             </div>
              
  //             <div style={{ marginBottom: '20px' }}>
  //               <label style={{
  //                 display: 'block',
  //                 marginBottom: '8px',
  //                 fontWeight: '600',
  //                 color: '#333',
  //                 fontSize: '14px'
  //               }}>
  //                 Email Address *
  //               </label>
  //               <input
  //                 type="email"
  //                 name="email"
  //                 value={offerForm.email}
  //                 onChange={handleOfferChange}
  //                 required
  //                 style={{
  //                   width: '100%',
  //                   padding: '12px',
  //                   border: '1px solid #ddd',
  //                   borderRadius: '4px',
  //                   fontSize: '16px',
  //                   boxSizing: 'border-box'
  //                 }}
  //                 placeholder="Enter your email"
  //               />
  //             </div>
              
  //             <div style={{ marginBottom: '20px' }}>
  //               <label style={{
  //                 display: 'block',
  //                 marginBottom: '8px',
  //                 fontWeight: '600',
  //                 color: '#333',
  //                 fontSize: '14px'
  //               }}>
  //                 Phone Number *
  //               </label>
  //               <input
  //                 type="tel"
  //                 name="phone"
  //                 value={offerForm.phone}
  //                 onChange={handleOfferChange}
  //                 required
  //                 style={{
  //                   width: '100%',
  //                   padding: '12px',
  //                   border: '1px solid #ddd',
  //                   borderRadius: '4px',
  //                   fontSize: '16px',
  //                   boxSizing: 'border-box'
  //                 }}
  //                 placeholder="Enter your phone number"
  //               />
  //             </div>
              
  //             <div style={{ marginBottom: '20px' }}>
  //               <label style={{
  //                 display: 'block',
  //                 marginBottom: '8px',
  //                 fontWeight: '600',
  //                 color: '#333',
  //                 fontSize: '14px'
  //               }}>
  //                 Your Offer Amount (₹) *
  //               </label>
  //               <div style={{ position: 'relative' }}>
  //                 <span style={{
  //                   position: 'absolute',
  //                   left: '12px',
  //                   top: '12px',
  //                   color: '#666',
  //                   fontWeight: '600'
  //                 }}>
  //                   ₹
  //                 </span>
  //                 <input
  //                   type="number"
  //                   name="offerAmount"
  //                   value={offerForm.offerAmount}
  //                   onChange={handleOfferChange}
  //                   required
  //                   style={{
  //                     width: '100%',
  //                     padding: '12px 12px 12px 30px',
  //                     border: '1px solid #ddd',
  //                     borderRadius: '4px',
  //                     fontSize: '16px',
  //                     boxSizing: 'border-box'
  //                   }}
  //                   placeholder="Enter your offer amount"
  //                   min="1"
  //                 />
  //               </div>
  //               <p style={{
  //                 margin: '5px 0 0',
  //                 fontSize: '12px',
  //                 color: '#666'
  //               }}>
  //                 Current price: ₹{property.price?.toLocaleString('en-IN')}
  //               </p>
  //             </div>
              
  //             <div style={{ marginBottom: '25px' }}>
  //               <label style={{
  //                 display: 'block',
  //                 marginBottom: '8px',
  //                 fontWeight: '600',
  //                 color: '#333',
  //                 fontSize: '14px'
  //               }}>
  //                 Message to Seller
  //               </label>
  //               <textarea
  //                 name="message"
  //                 value={offerForm.message}
  //                 onChange={handleOfferChange}
  //                 rows="4"
  //                 style={{
  //                   width: '100%',
  //                   padding: '12px',
  //                   border: '1px solid #ddd',
  //                   borderRadius: '4px',
  //                   fontSize: '16px',
  //                   resize: 'vertical',
  //                   boxSizing: 'border-box'
  //                 }}
  //                 placeholder="Write your message (optional)"
  //               />
  //             </div>
              
  //             <button
  //               type="submit"
  //               style={{
  //                 backgroundColor: '#23e5db',
  //                 color: '#002f34',
  //                 border: 'none',
  //                 padding: '14px 20px',
  //                 borderRadius: '4px',
  //                 fontSize: '16px',
  //                 fontWeight: '600',
  //                 cursor: 'pointer',
  //                 width: '100%',
  //                 transition: 'all 0.3s ease',
  //                 ':hover': {
  //                   backgroundColor: '#1fd1d1',
  //                   transform: 'translateY(-2px)'
  //                 }
  //               }}
  //             >
  //               Submit Offer
  //             </button>
  //           </form>
  //         </div>
  //       </div>
  //     )}

  //     {/* Property Detail Content */}
  //     <div style={{ 
  //       backgroundColor: 'white',
  //       borderRadius: '8px',
  //       boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  //       overflow: 'hidden',
  //       marginBottom: '30px'
  //     }}>
  //       {/* Image Gallery */}
  //       <div style={{
  //         display: 'grid',
  //         gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
  //         gap: '10px',
  //         padding: '20px'
  //       }}>
  //         {property.images?.map((image, index) => (
  //           <img 
  //             key={index}
  //             src={image}
  //             alt={`Property ${index + 1}`}
  //             style={{
  //               width: '100%',
  //               height: '250px',
  //               objectFit: 'cover',
  //               borderRadius: '4px',
  //               boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  //             }}
  //           />
  //         ))}
  //       </div>

  //       {/* Property Details */}
  //       <div style={{ padding: '20px' }}>
  //         <h1 style={{ 
  //           color: '#002f34', 
  //           marginBottom: '10px',
  //           fontSize: '28px',
  //           fontWeight: '700'
  //         }}>
  //           {property.title}
  //         </h1>
          
  //         <div style={{ 
  //           display: 'flex',
  //           justifyContent: 'space-between',
  //           alignItems: 'center',
  //           marginBottom: '20px',
  //           flexWrap: 'wrap',
  //           gap: '15px'
  //         }}>
  //           <h2 style={{ 
  //             color: '#002f34', 
  //             margin: 0,
  //             fontSize: '24px'
  //           }}>
  //             ₹{property.price?.toLocaleString('en-IN')}
  //           </h2>
  //           <span style={{
  //             backgroundColor: '#23e5db',
  //             color: '#002f34',
  //             padding: '6px 12px',
  //             borderRadius: '4px',
  //             fontWeight: '600',
  //             textTransform: 'capitalize',
  //             fontSize: '14px'
  //           }}>
  //             {property.category}
  //           </span>
  //         </div>

  //         {/* Key Features */}
  //         <div style={{ 
  //           display: 'grid',
  //           gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
  //           gap: '20px',
  //           marginBottom: '30px',
  //           padding: '15px',
  //           backgroundColor: '#f9f9f9',
  //           borderRadius: '8px'
  //         }}>
  //           {property.bedrooms && (
  //             <div>
  //               <h4 style={{ 
  //                 color: '#666', 
  //                 margin: '0 0 5px',
  //                 fontSize: '14px'
  //               }}>
  //                 Bedrooms
  //               </h4>
  //               <p style={{ 
  //                 margin: 0, 
  //                 fontWeight: '600',
  //                 fontSize: '18px',
  //                 color: '#002f34'
  //               }}>
  //                 {property.bedrooms}
  //               </p>
  //             </div>
  //           )}
  //           {property.bathrooms && (
  //             <div>
  //               <h4 style={{ 
  //                 color: '#666', 
  //                 margin: '0 0 5px',
  //                 fontSize: '14px'
  //               }}>
  //                 Bathrooms
  //               </h4>
  //               <p style={{ 
  //                 margin: 0, 
  //                 fontWeight: '600',
  //                 fontSize: '18px',
  //                 color: '#002f34'
  //               }}>
  //                 {property.bathrooms}
  //               </p>
  //             </div>
  //           )}
  //           {(property.area || property.plotArea) && (
  //             <div>
  //               <h4 style={{ 
  //                 color: '#666', 
  //                 margin: '0 0 5px',
  //                 fontSize: '14px'
  //               }}>
  //                 Area
  //               </h4>
  //               <p style={{ 
  //                 margin: 0, 
  //                 fontWeight: '600',
  //                 fontSize: '18px',
  //                 color: '#002f34'
  //               }}>
  //                 {property.area ? `${property.area} sq.ft` : 
  //                  `${property.plotArea} ${property.category === 'land' ? 'acres' : 'sq.yd'}`}
  //               </p>
  //             </div>
  //           )}
  //           {property.furnished && (
  //             <div>
  //               <h4 style={{ 
  //                 color: '#666', 
  //                 margin: '0 0 5px',
  //                 fontSize: '14px'
  //               }}>
  //                 Furnishing
  //               </h4>
  //               <p style={{ 
  //                 margin: 0, 
  //                 fontWeight: '600',
  //                 fontSize: '18px',
  //                 color: '#002f34',
  //                 textTransform: 'capitalize'
  //               }}>
  //                 {property.furnished}
  //               </p>
  //             </div>
  //           )}
  //         </div>

  //         {/* Description */}
  //         <div style={{ marginBottom: '30px' }}>
  //           <h3 style={{ 
  //             color: '#002f34', 
  //             marginBottom: '15px',
  //             fontSize: '20px'
  //           }}>
  //             Description
  //           </h3>
  //           <p style={{ 
  //             lineHeight: '1.6',
  //             color: '#333',
  //             fontSize: '16px'
  //           }}>
  //             {property.description}
  //           </p>
  //         </div>

  //         {/* Location */}
  //         <div style={{ marginBottom: '30px' }}>
  //           <h3 style={{ 
  //             color: '#002f34', 
  //             marginBottom: '15px',
  //             fontSize: '20px'
  //           }}>
  //             Location
  //           </h3>
  //           <p style={{
  //             color: '#333',
  //             fontSize: '16px'
  //           }}>
  //             {property.location}
  //           </p>
  //           {/* Placeholder for map integration */}
  //           <div style={{
  //             height: '200px',
  //             backgroundColor: '#f5f5f5',
  //             borderRadius: '8px',
  //             marginTop: '15px',
  //             display: 'flex',
  //             alignItems: 'center',
  //             justifyContent: 'center',
  //             color: '#666'
  //           }}>
  //             [Map would be displayed here]
  //           </div>
  //         </div>

  //         {/* Contact Seller Section */}
  //         <div style={{ 
  //           backgroundColor: '#f5f5f5',
  //           borderRadius: '8px',
  //           padding: '25px',
  //           marginTop: '30px'
  //         }}>
  //           <h3 style={{ 
  //             color: '#002f34', 
  //             marginBottom: '20px',
  //             fontSize: '20px'
  //           }}>
  //             Contact Seller
  //           </h3>
            
  //           {sellerInfo && (
  //             <>
  //               <div style={{
  //                 display: 'flex',
  //                 gap: '15px',
  //                 flexWrap: 'wrap'
  //               }}>
  //                 <button
  //                   onClick={() => setShowOfferForm(true)}
  //                   style={{
  //                     backgroundColor: '#23e5db',
  //                     color: '#002f34',
  //                     border: 'none',
  //                     padding: '12px 24px',
  //                     borderRadius: '4px',
  //                     fontSize: '16px',
  //                     fontWeight: '600',
  //                     cursor: 'pointer',
  //                     transition: 'all 0.3s ease',
  //                     flex: '1',
  //                     minWidth: '180px',
  //                     ':hover': {
  //                       backgroundColor: '#1fd1d1',
  //                       transform: 'translateY(-2px)'
  //                     }
  //                   }}
  //                 >
  //                   Make Offer
  //                 </button>
                  
  //                 <a
  //                   href={`tel:${sellerInfo.mobile}`}
  //                   style={{
  //                     backgroundColor: '#002f34',
  //                     color: 'white',
  //                     border: 'none',
  //                     padding: '12px 24px',
  //                     borderRadius: '4px',
  //                     fontSize: '16px',
  //                     fontWeight: '600',
  //                     cursor: 'pointer',
  //                     textDecoration: 'none',
  //                     textAlign: 'center',
  //                     transition: 'all 0.3s ease',
  //                     flex: '1',
  //                     minWidth: '180px',
  //                     ':hover': {
  //                       backgroundColor: '#001a1d',
  //                       transform: 'translateY(-2px)'
  //                     }
  //                   }}
  //                 >
  //                   Call Now
  //                 </a>
  //               </div>
  //             </>
  //           )}
  //         </div>
  //       </div>
  //     </div>
  //   </div>
  // );



  return (
    <div style={{ 
      maxWidth: '1400px', 
      margin: '0 auto', 
      padding: '30px 20px',
      fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, sans-serif'
    }}>
      {/* Offer Form Modal */}
      {showOfferForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,47,52,0.9)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000,
          padding: '20px',
          backdropFilter: 'blur(5px)'
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '40px',
            width: '100%',
            maxWidth: '600px',
            boxShadow: '0 10px 30px rgba(0,0,0,0.15)',
            position: 'relative',
            animation: 'modalFadeIn 0.3s ease-out'
          }}>
            <button 
              onClick={() => setShowOfferForm(false)}
              style={{
                position: 'absolute',
                top: '20px',
                right: '20px',
                background: 'none',
                border: 'none',
                fontSize: '28px',
                cursor: 'pointer',
                color: '#666',
                padding: '5px',
                transition: 'all 0.2s',
                ':hover': {
                  color: '#002f34',
                  transform: 'rotate(90deg)'
                }
              }}
            >
              &times;
            </button>
            
            <div style={{ marginBottom: '30px' }}>
              <h2 style={{ 
                color: '#002f34', 
                margin: '0 0 10px',
                fontSize: '28px',
                fontWeight: '700',
                lineHeight: '1.3'
              }}>
                Make an Offer for<br />
                <span style={{ color: '#23e5db' }}>{property.title}</span>
              </h2>
              <p style={{ 
                color: '#666',
                margin: 0,
                fontSize: '16px'
              }}>
                Current Price: <span style={{ fontWeight: '600' }}>₹{property.price?.toLocaleString('en-IN')}</span>
              </p>
            </div>
            
            <form onSubmit={handleOfferSubmit}>
              <div style={{ 
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '20px',
                marginBottom: '20px'
              }}>
                <div>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontWeight: '600',
                    color: '#333',
                    fontSize: '14px'
                  }}>
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={offerForm.name}
                    onChange={handleOfferChange}
                    required
                    style={{
                      width: '100%',
                      padding: '14px',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                      fontSize: '16px',
                      boxSizing: 'border-box',
                      transition: 'all 0.3s',
                      ':focus': {
                        borderColor: '#23e5db',
                        outline: 'none',
                        boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                      }
                    }}
                    placeholder="John Doe"
                  />
                </div>
                
                <div>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontWeight: '600',
                    color: '#333',
                    fontSize: '14px'
                  }}>
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={offerForm.email}
                    onChange={handleOfferChange}
                    required
                    style={{
                      width: '100%',
                      padding: '14px',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                      fontSize: '16px',
                      boxSizing: 'border-box',
                      transition: 'all 0.3s',
                      ':focus': {
                        borderColor: '#23e5db',
                        outline: 'none',
                        boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                      }
                    }}
                    placeholder="your@email.com"
                  />
                </div>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontWeight: '600',
                  color: '#333',
                  fontSize: '14px'
                }}>
                  Phone Number *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={offerForm.phone}
                  onChange={handleOfferChange}
                  required
                  style={{
                    width: '100%',
                    padding: '14px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '16px',
                    boxSizing: 'border-box',
                    transition: 'all 0.3s',
                    ':focus': {
                      borderColor: '#23e5db',
                      outline: 'none',
                      boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                    }
                  }}
                  placeholder="+91 9876543210"
                />
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontWeight: '600',
                  color: '#333',
                  fontSize: '14px'
                }}>
                  Your Offer Amount *
                </label>
                <div style={{ position: 'relative' }}>
                  <span style={{
                    position: 'absolute',
                    left: '15px',
                    top: '15px',
                    color: '#666',
                    fontWeight: '600',
                    fontSize: '18px'
                  }}>
                    ₹
                  </span>
                  <input
                    type="number"
                    name="offerAmount"
                    value={offerForm.offerAmount}
                    onChange={handleOfferChange}
                    required
                    style={{
                      width: '100%',
                      padding: '14px 14px 14px 40px',
                      border: '1px solid #e0e0e0',
                      borderRadius: '8px',
                      fontSize: '18px',
                      fontWeight: '600',
                      boxSizing: 'border-box',
                      transition: 'all 0.3s',
                      ':focus': {
                        borderColor: '#23e5db',
                        outline: 'none',
                        boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                      }
                    }}
                    placeholder="Enter amount"
                    min="1"
                  />
                </div>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  marginTop: '5px'
                }}>
                  <p style={{
                    margin: 0,
                    fontSize: '13px',
                    color: '#666'
                  }}>
                    Minimum offer: ₹{(property.price * 0.9).toLocaleString('en-IN')} (10% below)
                  </p>
                  <p style={{
                    margin: 0,
                    fontSize: '13px',
                    color: '#666'
                  }}>
                    Market value: ₹{(property.price * 1.1).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
              
              <div style={{ marginBottom: '30px' }}>
                <label style={{
                  display: 'block',
                  marginBottom: '8px',
                  fontWeight: '600',
                  color: '#333',
                  fontSize: '14px'
                }}>
                  Message to Seller
                </label>
                <textarea
                  name="message"
                  value={offerForm.message}
                  onChange={handleOfferChange}
                  rows="5"
                  style={{
                    width: '100%',
                    padding: '14px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '16px',
                    resize: 'vertical',
                    boxSizing: 'border-box',
                    transition: 'all 0.3s',
                    ':focus': {
                      borderColor: '#23e5db',
                      outline: 'none',
                      boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                    }
                  }}
                  placeholder="Tell the seller why you're interested and any terms you'd like to include..."
                />
              </div>
              
              <button
                type="submit"
                style={{
                  backgroundColor: '#23e5db',
                  color: '#002f34',
                  border: 'none',
                  padding: '16px',
                  borderRadius: '8px',
                  fontSize: '18px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  width: '100%',
                  transition: 'all 0.3s ease',
                  boxShadow: '0 4px 15px rgba(35,229,219,0.3)',
                  ':hover': {
                    backgroundColor: '#1fd1d1',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 6px 20px rgba(35,229,219,0.4)'
                  },
                  ':active': {
                    transform: 'translateY(0)'
                  }
                }}
              >
                Submit Offer
              </button>
            </form>
          </div>
        </div>
      )}
  
      {/* Property Detail Content */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '16px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.05)',
        overflow: 'hidden',
        marginBottom: '40px',
        border: '1px solid rgba(0,0,0,0.05)'
      }}>
        {/* Image Gallery */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '2fr 1fr 1fr',
          gridTemplateRows: 'auto auto',
          gap: '10px',
          height: '500px',
          '@media (max-width: 768px)': {
            gridTemplateColumns: '1fr',
            height: 'auto'
          }
        }}>
          {property.images?.slice(0, 3).map((image, index) => (
            <div 
              key={index}
              style={{
                position: 'relative',
                overflow: 'hidden',
                borderRadius: index === 0 ? '16px 0 0 0' : 
                            index === 1 ? '0 16px 0 0' : 
                            index === 2 ? '0 0 16px 0' : '0',
                gridRow: index === 0 ? 'span 2' : 'span 1',
                cursor: 'pointer',
                ':hover img': {
                  transform: 'scale(1.03)'
                }
              }}
            >
              <img 
                src={image}
                alt={`Property ${index + 1}`}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  transition: 'transform 0.5s ease'
                }}
              />
              {index === 0 && (
                <div style={{
                  position: 'absolute',
                  bottom: '20px',
                  left: '20px',
                  backgroundColor: 'rgba(0,47,52,0.8)',
                  color: 'white',
                  padding: '8px 16px',
                  borderRadius: '20px',
                  fontSize: '14px',
                  fontWeight: '600'
                }}>
                  {property.images?.length} Photos
                </div>
              )}
            </div>
          ))}
        </div>
  
        {/* Property Details */}
        <div style={{ padding: '40px' }}>
          <div style={{ 
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginBottom: '30px',
            flexWrap: 'wrap',
            gap: '20px'
          }}>
            <div>
              <h1 style={{ 
                color: '#002f34', 
                marginBottom: '10px',
                fontSize: '32px',
                fontWeight: '800',
                lineHeight: '1.2'
              }}>
                {property.title}
              </h1>
              
              <div style={{ 
                display: 'flex',
                alignItems: 'center',
                gap: '15px',
                marginBottom: '15px'
              }}>
                <div style={{ 
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px',
                  color: '#666',
                  fontSize: '16px'
                }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17.657 16.657L13.414 20.9C13.039 21.2746 12.5306 21.4852 12.0005 21.4852C11.4704 21.4852 10.962 21.2746 10.587 20.9L6.343 16.657C5.22422 15.5382 4.46234 14.1127 4.15369 12.5609C3.84504 11.009 4.00349 9.40055 4.60901 7.93872C5.21452 6.47689 6.2399 5.22753 7.55548 4.34851C8.87107 3.4695 10.4178 3.00029 12 3.00029C13.5822 3.00029 15.1289 3.4695 16.4445 4.34851C17.7601 5.22753 18.7855 6.47689 19.391 7.93872C19.9965 9.40055 20.155 11.009 19.8463 12.5609C19.5377 14.1127 18.7758 15.5382 17.657 16.657Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M15 11C15 12.6569 13.6569 14 12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  {property.location}
                </div>
              </div>
            </div>
            
            <div style={{ 
              backgroundColor: '#f8fafc',
              padding: '20px',
              borderRadius: '12px',
              minWidth: '250px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
              border: '1px solid rgba(0,0,0,0.05)'
            }}>
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '15px'
              }}>
                <span style={{
                  color: '#666',
                  fontSize: '16px',
                  fontWeight: '500'
                }}>
                  Price
                </span>
                <span style={{ 
                  color: '#002f34', 
                  fontSize: '28px',
                  fontWeight: '800'
                }}>
                  ₹{property.price?.toLocaleString('en-IN')}
                </span>
              </div>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: '5px'
              }}>
                <span style={{
                  color: '#666',
                  fontSize: '14px'
                }}>
                  Price per sq.ft
                </span>
                <span style={{ 
                  color: '#002f34',
                  fontSize: '16px',
                  fontWeight: '600'
                }}>
                  ₹{(property.price / (property.area || property.plotArea * 43560)).toLocaleString('en-IN')}
                </span>
              </div>
              
              <button
                onClick={() => setShowOfferForm(true)}
                style={{
                  width: '100%',
                  backgroundColor: '#23e5db',
                  color: '#002f34',
                  border: 'none',
                  padding: '14px',
                  borderRadius: '8px',
                  fontSize: '16px',
                  fontWeight: '700',
                  cursor: 'pointer',
                  marginTop: '15px',
                  transition: 'all 0.3s',
                  ':hover': {
                    backgroundColor: '#1fd1d1',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 4px 12px rgba(35,229,219,0.3)'
                  }
                }}
              >
                Make an Offer
              </button>
            </div>
          </div>
  
          {/* Key Features */}
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
            gap: '25px',
            marginBottom: '40px',
            padding: '25px',
            backgroundColor: '#f8fafc',
            borderRadius: '12px',
            border: '1px solid rgba(0,0,0,0.05)'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{
                width: '60px',
                height: '60px',
                backgroundColor: 'white',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 10px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
              }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M3 9H21M7 3V5M17 3V5M6 12H8M11 12H13M16 12H18M6 15H8M11 15H13M16 15H18M6 18H8M11 18H13M16 18H18M6.2 21H17.8C18.9201 21 19.4802 21 19.908 20.782C20.2843 20.5903 20.5903 20.2843 20.782 19.908C21 19.4802 21 18.9201 21 17.8V8.2C21 7.07989 21 6.51984 20.782 6.09202C20.5903 5.71569 20.2843 5.40973 19.908 5.21799C19.4802 5 18.9201 5 17.8 5H6.2C5.0799 5 4.51984 5 4.09202 5.21799C3.71569 5.40973 3.40973 5.71569 3.21799 6.09202C3 6.51984 3 7.07989 3 8.2V17.8C3 18.9201 3 19.4802 3.21799 19.908C3.40973 20.2843 3.71569 20.5903 4.09202 20.782C4.51984 21 5.07989 21 6.2 21Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h4 style={{ 
                color: '#666', 
                margin: '0 0 5px',
                fontSize: '14px'
              }}>
                Listed On
              </h4>
              <p style={{ 
                margin: 0, 
                fontWeight: '700',
                fontSize: '18px',
                color: '#002f34'
              }}>
                {new Date(property.createdAt).toLocaleDateString()}
              </p>
            </div>
            
            {property.bedrooms && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 10px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 5V19C3 20.1046 3.89543 21 5 21H19C20.1046 21 21 20.1046 21 19V5C21 3.89543 20.1046 3 19 3H5C3.89543 3 3 3.89543 3 5Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 10H21" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M10 10V21" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h4 style={{ 
                  color: '#666', 
                  margin: '0 0 5px',
                  fontSize: '14px'
                }}>
                  Bedrooms
                </h4>
                <p style={{ 
                  margin: 0, 
                  fontWeight: '700',
                  fontSize: '18px',
                  color: '#002f34'
                }}>
                  {property.bedrooms}
                </p>
              </div>
            )}
            
            {property.bathrooms && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 10px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6H6V18H18V6Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8 3V6" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M16 3V6" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M10 14L12 12L14 14" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M12 12V18" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h4 style={{ 
                  color: '#666', 
                  margin: '0 0 5px',
                  fontSize: '14px'
                }}>
                  Bathrooms
                </h4>
                <p style={{ 
                  margin: 0, 
                  fontWeight: '700',
                  fontSize: '18px',
                  color: '#002f34'
                }}>
                  {property.bathrooms}
                </p>
              </div>
            )}
            
            {(property.area || property.plotArea) && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 10px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 6H15V18H3V6Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M9 6V18" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M21 9H15" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M21 15H15" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h4 style={{ 
                  color: '#666', 
                  margin: '0 0 5px',
                  fontSize: '14px'
                }}>
                  {property.category === 'land' ? 'Plot Area' : 'Built Area'}
                </h4>
                <p style={{ 
                  margin: 0, 
                  fontWeight: '700',
                  fontSize: '18px',
                  color: '#002f34'
                }}>
                  {property.area ? `${property.area} sq.ft` : 
                   `${property.plotArea} ${property.category === 'land' ? 'acres' : 'sq.yd'}`}
                </p>
              </div>
            )}
            
            {property.furnished && (
              <div style={{ textAlign: 'center' }}>
                <div style={{
                  width: '60px',
                  height: '60px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 10px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 21V5C19 3.89543 18.1046 3 17 3H7C5.89543 3 5 3.89543 5 5V21M19 21L21 21M19 21H14M5 21L3 21M5 21H10M9 7H15M9 11H15M10 21V16C10 15.4477 10.4477 15 11 15H13C13.5523 15 14 15.4477 14 16V21M10 21H14" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h4 style={{ 
                  color: '#666', 
                  margin: '0 0 5px',
                  fontSize: '14px'
                }}>
                  Furnishing
                </h4>
                <p style={{ 
                  margin: 0, 
                  fontWeight: '700',
                  fontSize: '18px',
                  color: '#002f34',
                  textTransform: 'capitalize'
                }}>
                  {property.furnished}
                </p>
              </div>
            )}
          </div>
  
          {/* Description */}
          <div style={{ marginBottom: '40px' }}>
            <h3 style={{ 
              color: '#002f34', 
              marginBottom: '20px',
              fontSize: '24px',
              fontWeight: '700',
              position: 'relative',
              paddingBottom: '10px',
              ':after': {
                content: '""',
                position: 'absolute',
                bottom: 0,
                left: 0,
                width: '60px',
                height: '4px',
                backgroundColor: '#23e5db',
                borderRadius: '2px'
              }
            }}>
              Description
            </h3>
            <p style={{ 
              lineHeight: '1.7',
              color: '#333',
              fontSize: '16px',
              marginBottom: '20px'
            }}>
              {property.description}
            </p>
            
            {property.amenities && property.amenities.length > 0 && (
              <>
                <h4 style={{
                  color: '#002f34',
                  margin: '30px 0 15px',
                  fontSize: '18px',
                  fontWeight: '600'
                }}>
                  Amenities
                </h4>
                <div style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
                  gap: '15px'
                }}>
                  {property.amenities.map((amenity, index) => (
                    <div key={index} style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px'
                    }}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="#23e5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      <span style={{ color: '#333' }}>{amenity}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
  
          {/* Location */}
          <div style={{ marginBottom: '40px' }}>
            <h3 style={{ 
              color: '#002f34', 
              marginBottom: '20px',
              fontSize: '24px',
              fontWeight: '700',
              position: 'relative',
              paddingBottom: '10px',
              ':after': {
                content: '""',
                position: 'absolute',
                bottom: 0,
                left: 0,
                width: '60px',
                height: '4px',
                backgroundColor: '#23e5db',
                borderRadius: '2px'
              }
            }}>
              Location
            </h3>
            <p style={{
              color: '#333',
              fontSize: '16px',
              marginBottom: '15px'
            }}>
              {property.location}
            </p>
            
            {/* Map Placeholder */}
            <div style={{
              height: '400px',
              backgroundColor: '#f5f5f5',
              borderRadius: '12px',
              marginTop: '15px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#666',
              border: '1px solid #e0e0e0',
              overflow: 'hidden',
              position: 'relative'
            }}>
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                background: 'linear-gradient(135deg, #f5f5f5 25%, #e0e0e0 25%, #e0e0e0 50%, #f5f5f5 50%, #f5f5f5 75%, #e0e0e0 75%, #e0e0e0 100%)',
                backgroundSize: '40px 40px',
                opacity: 0.3
              }}></div>
              <div style={{
                backgroundColor: 'white',
                padding: '15px 25px',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                zIndex: 1,
                display: 'flex',
                alignItems: 'center',
                gap: '10px'
              }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 20L15 4M12 17L15 20L18 17M12 7L9 4L12 1" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span style={{ fontWeight: '600' }}>Interactive Map Would Display Here</span>
              </div>
            </div>
          </div>
  
          {/* Contact Seller Section */}
          <div style={{ 
            backgroundColor: '#f8fafc',
            borderRadius: '16px',
            padding: '40px',
            marginTop: '40px',
            border: '1px solid rgba(0,0,0,0.05)',
            boxShadow: '0 4px 20px rgba(0,0,0,0.03)'
          }}>
            <h3 style={{ 
              color: '#002f34', 
              marginBottom: '30px',
              fontSize: '24px',
              fontWeight: '700',
              textAlign: 'center'
            }}>
              Interested in this property?
            </h3>
            
            {sellerInfo && (
              <div style={{
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '20px',
                '@media (max-width: 768px)': {
                  gridTemplateColumns: '1fr'
                }
              }}>
                <div style={{
                  backgroundColor: 'white',
                  borderRadius: '12px',
                  padding: '25px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center'
                }}>
                  <div style={{
                    width: '80px',
                    height: '80px',
                    borderRadius: '50%',
                    backgroundColor: '#e6f7f6',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: '20px'
                  }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M16 7C16 9.20914 14.2091 11 12 11C9.79086 11 8 9.20914 8 7C8 4.79086 9.79086 3 12 3C14.2091 3 16 4.79086 16 7Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M12 14C8.13401 14 5 17.134 5 21H19C19 17.134 15.866 14 12 14Z" stroke="#002f34" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <h4 style={{ 
                    margin: '0 0 5px',
                    color: '#002f34',
                    fontSize: '20px',
                    fontWeight: '600'
                  }}>
                    {sellerInfo.name}
                  </h4>
                  <p style={{ 
                    margin: '0 0 15px',
                    color: '#666',
                    fontSize: '16px'
                  }}>
                    Property Owner
                  </p>
                  <div style={{
                    display: 'flex',
                    gap: '10px'
                  }}>
                    <a
                      href={`tel:${sellerInfo.mobile}`}
                      style={{
                        backgroundColor: '#002f34',
                        color: 'white',
                        border: 'none',
                        padding: '12px 20px',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        textDecoration: 'none',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.3s',
                        ':hover': {
                          backgroundColor: '#001a1d',
                          transform: 'translateY(-2px)',
                          boxShadow: '0 4px 12px rgba(0,47,52,0.2)'
                        }
                      }}
                    >
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 5C3 3.89543 3.89543 3 5 3H8.27924C8.70967 3 9.09181 3.27543 9.22792 3.68377L10.7257 8.17721C10.8831 8.64932 10.6694 9.16531 10.2243 9.38787L7.96701 10.5165C9.06925 12.9612 11.0388 14.9308 13.4835 16.033L14.6121 13.7757C14.8347 13.3306 15.3507 13.1169 15.8228 13.2743L20.3162 14.7721C20.7246 14.9082 21 15.2903 21 15.7208V19C21 20.1046 20.1046 21 19 21H18C9.71573 21 3 14.2843 3 6V5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Call Now
                    </a>
                    <button
                      onClick={() => setShowOfferForm(true)}
                      style={{
                        backgroundColor: '#23e5db',
                        color: '#002f34',
                        border: 'none',
                        padding: '12px 20px',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.3s',
                        ':hover': {
                          backgroundColor: '#1fd1d1',
                          transform: 'translateY(-2px)',
                          boxShadow: '0 4px 12px rgba(35,229,219,0.2)'
                        }
                      }}
                    >
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8 10H8.01M12 10H12.01M16 10H16.01M9 16H5C3.89543 16 3 15.1046 3 14V6C3 4.89543 3.89543 4 5 4H19C20.1046 4 21 4.89543 21 6V14C21 15.1046 20.1046 16 19 16H14L9 21V16Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Message
                    </button>
                  </div>
                </div>
                
                <div style={{
                  backgroundColor: 'white',
                  borderRadius: '12px',
                  padding: '25px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
                }}>
                  <h4 style={{ 
                    margin: '0 0 20px',
                    color: '#002f34',
                    fontSize: '20px',
                    fontWeight: '600',
                    textAlign: 'center'
                  }}>
                    Schedule a Visit
                  </h4>
                  <form>
                    <div style={{ marginBottom: '15px' }}>
                      <input
                        type="text"
                        placeholder="Your Name"
                        style={{
                          width: '100%',
                          padding: '14px',
                          border: '1px solid #e0e0e0',
                          borderRadius: '8px',
                          fontSize: '16px',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s',
                          ':focus': {
                            borderColor: '#23e5db',
                            outline: 'none',
                            boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                          }
                        }}
                      />
                    </div>
                    <div style={{ marginBottom: '15px' }}>
                      <input
                        type="email"
                        placeholder="Email Address"
                        style={{
                          width: '100%',
                          padding: '14px',
                          border: '1px solid #e0e0e0',
                          borderRadius: '8px',
                          fontSize: '16px',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s',
                          ':focus': {
                            borderColor: '#23e5db',
                            outline: 'none',
                            boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                          }
                        }}
                      />
                    </div>
                    <div style={{ marginBottom: '15px' }}>
                      <input
                        type="tel"
                        placeholder="Phone Number"
                        style={{
                          width: '100%',
                          padding: '14px',
                          border: '1px solid #e0e0e0',
                          borderRadius: '8px',
                          fontSize: '16px',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s',
                          ':focus': {
                            borderColor: '#23e5db',
                            outline: 'none',
                            boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                          }
                        }}
                      />
                    </div>
                    <div style={{ marginBottom: '20px' }}>
                      <input
                        type="datetime-local"
                        style={{
                          width: '100%',
                          padding: '14px',
                          border: '1px solid #e0e0e0',
                          borderRadius: '8px',
                          fontSize: '16px',
                          boxSizing: 'border-box',
                          transition: 'all 0.3s',
                          ':focus': {
                            borderColor: '#23e5db',
                            outline: 'none',
                            boxShadow: '0 0 0 3px rgba(35,229,219,0.2)'
                          }
                        }}
                      />
                    </div>
                    <button
                      type="submit"
                      style={{
                        width: '100%',
                        backgroundColor: '#002f34',
                        color: 'white',
                        border: 'none',
                        padding: '14px',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'all 0.3s',
                        ':hover': {
                          backgroundColor: '#001a1d',
                          transform: 'translateY(-2px)',
                          boxShadow: '0 4px 12px rgba(0,47,52,0.2)'
                        }
                      }}
                    >
                      Request Visit
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
  
      {/* Add some global styles for animations */}
      <style>{`
        @keyframes modalFadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );

};

export default PropertyDetail;