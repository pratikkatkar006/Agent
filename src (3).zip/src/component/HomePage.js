
// import React, { useState, useEffect } from 'react';
// import { getDatabase, ref, onValue } from 'firebase/database';
// import Navbar from './Navbar';

// const Home = () => {
//   const [properties, setProperties] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedCategory, setSelectedCategory] = useState('all');

//   useEffect(() => {
//     const db = getDatabase();
//     const propertiesRef = ref(db, 'delar/customers');
    
//     onValue(propertiesRef, (snapshot) => {
//       const data = snapshot.val();
//       if (data) {
//         // Flatten all properties from all users and filter only active ones
//         const allProperties = Object.values(data).flatMap(user => {
//           if (!user.properties) return [];
//           return Object.entries(user.properties).flatMap(([category, props]) => 
//             Object.entries(props).map(([id, property]) => ({
//               id,
//               category,
//               sellerMobile: user.mobile,
//               ...property
//             })).filter(property => property.status === 'active') // Only include active properties
//           );
//         });
//         setProperties(allProperties);
//       } else {
//         setProperties([]);
//       }
//       setLoading(false);
//     });

//     return () => onValue(propertiesRef, () => {});
//   }, []);

//   // Filter properties based on search and category
//   const filteredProperties = properties.filter(property => {
//     const matchesSearch = property.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
//                          property.description.toLowerCase().includes(searchTerm.toLowerCase());
//     const matchesCategory = selectedCategory === 'all' || property.category === selectedCategory;
//     return matchesSearch && matchesCategory;
//   });

//   // Get unique categories for filter
//   const categories = ['all', ...new Set(properties.map(p => p.category))];

//   return (
//     <>
//       <Navbar />
//       <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '20px 30px' }}>
//         {/* Search and Filter Section */}
//         <div style={{ 
//           marginBottom: '40px',
//           backgroundColor: 'white',
//           padding: '25px 30px',
//           borderRadius: '12px',
//           boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
//           border: '1px solid rgba(0,0,0,0.05)'
//         }}>
//           <h2 style={{ 
//             margin: '0 0 20px',
//             color: '#002f34',
//             fontSize: '24px',
//             fontWeight: '600'
//           }}>
//             Discover Your Perfect Property
//           </h2>
//           <div style={{ 
//             display: 'flex', 
//             gap: '15px',
//             alignItems: 'center',
//             flexWrap: 'wrap' 
//           }}>
//             <div style={{ flex: 1, minWidth: '300px' }}>
//               <div style={{ 
//                 position: 'relative',
//                 display: 'flex',
//                 alignItems: 'center'
//               }}>
//                 <input
//                   type="text"
//                   placeholder="Search by location, property type, or keyword..."
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                   style={{
//                     flex: 1,
//                     padding: '14px 20px 14px 45px',
//                     border: '1px solid #e0e0e0',
//                     borderRadius: '8px',
//                     fontSize: '16px',
//                     boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)',
//                     transition: 'all 0.3s',
//                     ':focus': {
//                       borderColor: '#002f34',
//                       outline: 'none',
//                       boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
//                     }
//                   }}
//                 />
//                 <svg 
//                   style={{
//                     position: 'absolute',
//                     left: '15px',
//                     width: '20px',
//                     height: '20px',
//                     color: '#999'
//                   }} 
//                   fill="none" 
//                   stroke="currentColor" 
//                   viewBox="0 0 24 24" 
//                   xmlns="http://www.w3.org/2000/svg"
//                 >
//                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
//                 </svg>
//               </div>
//             </div>
            
//             <select
//               value={selectedCategory}
//               onChange={(e) => setSelectedCategory(e.target.value)}
//               style={{
//                 padding: '14px 20px',
//                 border: '1px solid #e0e0e0',
//                 borderRadius: '8px',
//                 fontSize: '16px',
//                 minWidth: '200px',
//                 backgroundColor: 'white',
//                 appearance: 'none',
//                 backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23002f34%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E")',
//                 backgroundRepeat: 'no-repeat',
//                 backgroundPosition: 'right 15px center',
//                 backgroundSize: '12px',
//                 cursor: 'pointer',
//                 transition: 'all 0.3s',
//                 ':focus': {
//                   borderColor: '#002f34',
//                   outline: 'none',
//                   boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
//                 }
//               }}
//             >
//               {categories.map(category => (
//                 <option key={category} value={category}>
//                   {category === 'all' ? 'All Categories' : category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
//                 </option>
//               ))}
//             </select>
            
//             <button 
//               style={{
//                 padding: '14px 25px',
//                 backgroundColor: '#002f34',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '8px',
//                 fontSize: '16px',
//                 fontWeight: '600',
//                 cursor: 'pointer',
//                 transition: 'all 0.3s',
//                 display: 'flex',
//                 alignItems: 'center',
//                 gap: '8px',
//                 ':hover': {
//                   backgroundColor: '#004950',
//                   transform: 'translateY(-1px)'
//                 }
//               }}
//             >
//               <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//                 <path d="M22 22L20 20M11.5 6C13.7091 6 15.5 7.79086 15.5 10M2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//               </svg>
//               Search
//             </button>
//           </div>
//         </div>
  
//         {/* Results Section */}
//         {loading ? (
//           <div style={{ 
//             textAlign: 'center', 
//             padding: '60px 20px',
//             backgroundColor: 'white',
//             borderRadius: '12px',
//             boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
//           }}>
//             <div style={{
//               display: 'inline-block',
//               width: '50px',
//               height: '50px',
//               border: '3px solid rgba(0,47,52,0.1)',
//               borderTopColor: '#002f34',
//               borderRadius: '50%',
//               animation: 'spin 1s linear infinite',
//               marginBottom: '20px'
//             }}></div>
//             <p style={{ 
//               margin: 0,
//               color: '#002f34',
//               fontSize: '18px',
//               fontWeight: '500'
//             }}>
//               Loading properties...
//             </p>
//           </div>
//         ) : filteredProperties.length === 0 ? (
//           <div style={{ 
//             backgroundColor: 'white',
//             padding: '60px 20px',
//             borderRadius: '12px',
//             textAlign: 'center',
//             boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
//           }}>
//             <svg 
//               style={{
//                 width: '80px',
//                 height: '80px',
//                 color: '#e0e0e0',
//                 marginBottom: '20px'
//               }} 
//               fill="none" 
//               stroke="currentColor" 
//               viewBox="0 0 24 24" 
//               xmlns="http://www.w3.org/2000/svg"
//             >
//               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
//             </svg>
//             <h3 style={{ 
//               margin: '0 0 10px',
//               color: '#002f34',
//               fontSize: '22px',
//               fontWeight: '600'
//             }}>
//               No properties found
//             </h3>
//             <p style={{ 
//               margin: 0,
//               color: '#666',
//               fontSize: '16px',
//               maxWidth: '500px',
//               margin: '0 auto'
//             }}>
//               We couldn't find any properties matching your search criteria. Try adjusting your filters.
//             </p>
//           </div>
//         ) : (
//           <>
//             <div style={{
//               display: 'flex',
//               justifyContent: 'space-between',
//               alignItems: 'center',
//               marginBottom: '25px'
//             }}>
//               <h3 style={{ 
//                 margin: 0,
//                 color: '#002f34',
//                 fontSize: '20px',
//                 fontWeight: '600'
//               }}>
//                 {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
//               </h3>
//               <div style={{
//                 display: 'flex',
//                 alignItems: 'center',
//                 gap: '10px'
//               }}>
//                 <span style={{ 
//                   color: '#666',
//                   fontSize: '14px'
//                 }}>
//                   Sort by:
//                 </span>
//                 <select
//                   style={{
//                     padding: '10px 15px',
//                     border: '1px solid #e0e0e0',
//                     borderRadius: '6px',
//                     fontSize: '14px',
//                     backgroundColor: 'white',
//                     cursor: 'pointer'
//                   }}
//                 >
//                   <option>Most Recent</option>
//                   <option>Price: Low to High</option>
//                   <option>Price: High to Low</option>
//                 </select>
//               </div>
//             </div>
            
//             <div style={{
//               display: 'grid',
//               gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
//               gap: '25px'
//             }}>
//               {filteredProperties.map(property => (
//                 <div 
//                   key={`${property.sellerMobile}-${property.category}-${property.id}`} 
//                   style={{
//                     backgroundColor: 'white',
//                     borderRadius: '12px',
//                     boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
//                     overflow: 'hidden',
//                     transition: 'all 0.3s ease',
//                     border: '1px solid rgba(0,0,0,0.05)',
//                     ':hover': {
//                       transform: 'translateY(-5px)',
//                       boxShadow: '0 8px 25px rgba(0,0,0,0.1)'
//                     }
//                   }}
//                 >
//                   {property.images?.[0] && (
//                     <div style={{ 
//                       position: 'relative',
//                       height: '220px',
//                       overflow: 'hidden',
//                       cursor: 'pointer'
//                     }}
//                       onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
//                     >
//                       <img 
//                         src={property.images[0]} 
//                         alt={property.title}
//                         style={{
//                           width: '100%',
//                           height: '100%',
//                           objectFit: 'cover',
//                           transition: 'transform 0.5s ease',
//                           ':hover': {
//                             transform: 'scale(1.05)'
//                           }
//                         }}
//                       />
//                       <div style={{
//                         position: 'absolute',
//                         top: '15px',
//                         left: '15px',
//                         backgroundColor: 'rgba(0,47,52,0.8)',
//                         color: 'white',
//                         padding: '5px 10px',
//                         borderRadius: '4px',
//                         fontSize: '12px',
//                         fontWeight: '600',
//                         textTransform: 'capitalize'
//                       }}>
//                         {property.category.replace('-', ' ')}
//                       </div>
//                     </div>
//                   )}
//                   <div style={{ padding: '20px' }}>
//                     <div style={{ 
//                       display: 'flex',
//                       justifyContent: 'space-between',
//                       alignItems: 'flex-start',
//                       marginBottom: '15px'
//                     }}>
//                       <h3 style={{ 
//                         margin: 0,
//                         color: '#002f34',
//                         fontSize: '18px',
//                         fontWeight: '600',
//                         cursor: 'pointer',
//                         flex: 1
//                       }}
//                         onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
//                       >
//                         {property.title}
//                       </h3>
//                       <span style={{ 
//                         color: '#002f34',
//                         fontSize: '20px',
//                         fontWeight: '700',
//                         whiteSpace: 'nowrap',
//                         marginLeft: '15px'
//                       }}>
//                         ₹{property.price?.toLocaleString('en-IN')}
//                       </span>
//                     </div>
                    
//                     <div style={{ 
//                       display: 'flex',
//                       alignItems: 'center',
//                       gap: '15px',
//                       marginBottom: '15px'
//                     }}>
//                       <div style={{ 
//                         display: 'flex',
//                         alignItems: 'center',
//                         gap: '5px',
//                         color: '#666',
//                         fontSize: '14px'
//                       }}>
//                         <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//                           <path d="M17.657 16.657L13.414 20.9C13.039 21.2746 12.5306 21.4852 12.0005 21.4852C11.4704 21.4852 10.962 21.2746 10.587 20.9L6.343 16.657C5.22422 15.5382 4.46234 14.1127 4.15369 12.5609C3.84504 11.009 4.00349 9.40055 4.60901 7.93872C5.21452 6.47689 6.2399 5.22753 7.55548 4.34851C8.87107 3.4695 10.4178 3.00029 12 3.00029C13.5822 3.00029 15.1289 3.4695 16.4445 4.34851C17.7601 5.22753 18.7855 6.47689 19.391 7.93872C19.9965 9.40055 20.155 11.009 19.8463 12.5609C19.5377 14.1127 18.7758 15.5382 17.657 16.657Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
//                           <path d="M15 11C15 12.6569 13.6569 14 12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
//                         </svg>
//                         {property.location}
//                       </div>
//                     </div>
                    
//                     <p style={{ 
//                       margin: '0 0 20px',
//                       color: '#666',
//                       fontSize: '14px',
//                       lineHeight: '1.5',
//                       display: '-webkit-box',
//                       WebkitLineClamp: 2,
//                       WebkitBoxOrient: 'vertical',
//                       overflow: 'hidden'
//                     }}>
//                       {property.description}
//                     </p>
                    
//                     <button
//                       onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
//                       style={{
//                         width: '100%',
//                         backgroundColor: 'transparent',
//                         color: '#002f34',
//                         border: '2px solid #002f34',
//                         padding: '10px',
//                         borderRadius: '8px',
//                         fontSize: '16px',
//                         fontWeight: '600',
//                         cursor: 'pointer',
//                         transition: 'all 0.3s',
//                         display: 'flex',
//                         alignItems: 'center',
//                         justifyContent: 'center',
//                         gap: '8px',
//                         ':hover': {
//                           backgroundColor: '#002f34',
//                           color: 'white'
//                         }
//                       }}
//                     >
//                       View Full Details
//                       <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
//                         <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
//                       </svg>
//                     </button>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </>
//         )}
//       </div>
      
//       {/* Add some global styles for animations */}
//       <style>{`
//         @keyframes spin {
//           0% { transform: rotate(0deg); }
//           100% { transform: rotate(360deg); }
//         }
//       `}</style>
//     </>
//   );
// };

// export default Home;





import React, { useState, useEffect } from 'react';
import { getDatabase, ref, onValue, push, set } from 'firebase/database';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import Navbar from './Navbar';

const Home = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  // const [user, setUser] = useState(null);

  const [user, setUser] = useState(() => {
    const auth = getAuth();
    return auth.currentUser;
  });
  // Initialize Firebase Auth
  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Fetch properties from Firebase
  useEffect(() => {
    const db = getDatabase();
    const propertiesRef = ref(db, 'delar/customers');
    
    const unsubscribe = onValue(propertiesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allProperties = Object.values(data).flatMap(user => {
          if (!user.properties) return [];
          return Object.entries(user.properties).flatMap(([category, props]) => 
            Object.entries(props).map(([id, property]) => ({
              id,
              category,
              sellerMobile: user.mobile,
              ...property
            })).filter(property => property.status === 'active')
          );
        });
        setProperties(allProperties);
      } else {
        setProperties([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Track property click and create lead
  const trackPropertyClick = async (property) => {
    const db = getDatabase();
    
    const leadData = {
      propertyId: property.id,
      propertyTitle: property.title,
      propertyCategory: property.category,
      propertyPrice: property.price,
      propertyLocation: property.location,
      clickedAt: Date.now(),
      status: 'new',
      ...(user && {
        userId: user.id,
        userName: user.displayName || 'Anonymous',
        userEmail: user.email || 'Not provided',
        userMobile: user.phoneNumber || 'Not provided'
      })
    };

    try {
      const leadsRef = ref(db, `delar/customers/${property.sellerMobile}/leads`);
      const newLeadRef = push(leadsRef);
      await set(newLeadRef, leadData);
      console.log('Lead recorded successfully');
    } catch (error) {
      console.error('Error recording lead:', error);
    }
  };

  // Handle property click - tracks click and navigates
  const handlePropertyClick = (property) => {
    trackPropertyClick(property);
    window.location.href = `/property/${property.category}/${property.id}`;
  };

  // Filter properties based on search and category
  const filteredProperties = properties.filter(property => {
    const matchesSearch = property.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         property.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || property.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Get unique categories for filter
  const categories = ['all', ...new Set(properties.map(p => p.category))];

  return (
    <>
      <Navbar />
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '20px 30px' }}>
        {/* Search and Filter Section */}
        <div style={{ 
          marginBottom: '40px',
          backgroundColor: 'white',
          padding: '25px 30px',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
          border: '1px solid rgba(0,0,0,0.05)'
        }}>
          <h2 style={{ 
            margin: '0 0 20px',
            color: '#002f34',
            fontSize: '24px',
            fontWeight: '600'
          }}>
            Discover Your Perfect Property
          </h2>
          <div style={{ 
            display: 'flex', 
            gap: '15px',
            alignItems: 'center',
            flexWrap: 'wrap' 
          }}>
            <div style={{ flex: 1, minWidth: '300px' }}>
              <div style={{ 
                position: 'relative',
                display: 'flex',
                alignItems: 'center'
              }}>
                <input
                  type="text"
                  placeholder="Search by location, property type, or keyword..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '14px 20px 14px 45px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '16px',
                    boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)',
                    transition: 'all 0.3s',
                    ':focus': {
                      borderColor: '#002f34',
                      outline: 'none',
                      boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
                    }
                  }}
                />
                <svg 
                  style={{
                    position: 'absolute',
                    left: '15px',
                    width: '20px',
                    height: '20px',
                    color: '#999'
                  }} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              style={{
                padding: '14px 20px',
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                fontSize: '16px',
                minWidth: '200px',
                backgroundColor: 'white',
                appearance: 'none',
                backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23002f34%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E")',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 15px center',
                backgroundSize: '12px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                ':focus': {
                  borderColor: '#002f34',
                  outline: 'none',
                  boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
                }
              }}
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </option>
              ))}
            </select>
            
            <button 
              style={{
                padding: '14px 25px',
                backgroundColor: '#002f34',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.3s',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                ':hover': {
                  backgroundColor: '#004950',
                  transform: 'translateY(-1px)'
                }
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 22L20 20M11.5 6C13.7091 6 15.5 7.79086 15.5 10M2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Search
            </button>
          </div>
        </div>
  
        {/* Results Section */}
        {loading ? (
          <div style={{ 
            textAlign: 'center', 
            padding: '60px 20px',
            backgroundColor: 'white',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}>
            <div style={{
              display: 'inline-block',
              width: '50px',
              height: '50px',
              border: '3px solid rgba(0,47,52,0.1)',
              borderTopColor: '#002f34',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              marginBottom: '20px'
            }}></div>
            <p style={{ 
              margin: 0,
              color: '#002f34',
              fontSize: '18px',
              fontWeight: '500'
            }}>
              Loading properties...
            </p>
          </div>
        ) : filteredProperties.length === 0 ? (
          <div style={{ 
            backgroundColor: 'white',
            padding: '60px 20px',
            borderRadius: '12px',
            textAlign: 'center',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}>
            <svg 
              style={{
                width: '80px',
                height: '80px',
                color: '#e0e0e0',
                marginBottom: '20px'
              }} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 style={{ 
              margin: '0 0 10px',
              color: '#002f34',
              fontSize: '22px',
              fontWeight: '600'
            }}>
              No properties found
            </h3>
            <p style={{ 
              margin: 0,
              color: '#666',
              fontSize: '16px',
              maxWidth: '500px',
              margin: '0 auto'
            }}>
              We couldn't find any properties matching your search criteria. Try adjusting your filters.
            </p>
          </div>
        ) : (
          <>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h3 style={{ 
                margin: 0,
                color: '#002f34',
                fontSize: '20px',
                fontWeight: '600'
              }}>
                {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
              </h3>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px'
              }}>
                <span style={{ 
                  color: '#666',
                  fontSize: '14px'
                }}>
                  Sort by:
                </span>
                <select
                  style={{
                    padding: '10px 15px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '6px',
                    fontSize: '14px',
                    backgroundColor: 'white',
                    cursor: 'pointer'
                  }}
                >
                  <option>Most Recent</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                </select>
              </div>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
              gap: '25px'
            }}>
              {filteredProperties.map(property => (
                <div 
                  key={`${property.sellerMobile}-${property.category}-${property.id}`} 
                  style={{
                    backgroundColor: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease',
                    border: '1px solid rgba(0,0,0,0.05)',
                    ':hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: '0 8px 25px rgba(0,0,0,0.1)'
                    }
                  }}
                >
                  {property.images?.[0] && (
                    <div style={{ 
                      position: 'relative',
                      height: '220px',
                      overflow: 'hidden',
                      cursor: 'pointer'
                    }}
                      onClick={() => handlePropertyClick(property)}
                    >
                      <img 
                        src={property.images[0]} 
                        alt={property.title}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          transition: 'transform 0.5s ease',
                          ':hover': {
                            transform: 'scale(1.05)'
                          }
                        }}
                      />
                      <div style={{
                        position: 'absolute',
                        top: '15px',
                        left: '15px',
                        backgroundColor: 'rgba(0,47,52,0.8)',
                        color: 'white',
                        padding: '5px 10px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'capitalize'
                      }}>
                        {property.category.replace('-', ' ')}
                      </div>
                    </div>
                  )}
                  <div style={{ padding: '20px' }}>
                    <div style={{ 
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                      marginBottom: '15px'
                    }}>
                      <h3 style={{ 
                        margin: 0,
                        color: '#002f34',
                        fontSize: '18px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        flex: 1
                      }}
                        onClick={() => handlePropertyClick(property)}
                      >
                        {property.title}
                      </h3>
                      <span style={{ 
                        color: '#002f34',
                        fontSize: '20px',
                        fontWeight: '700',
                        whiteSpace: 'nowrap',
                        marginLeft: '15px'
                      }}>
                        ₹{property.price?.toLocaleString('en-IN')}
                      </span>
                    </div>
                    
                    <div style={{ 
                      display: 'flex',
                      alignItems: 'center',
                      gap: '15px',
                      marginBottom: '15px'
                    }}>
                      <div style={{ 
                        display: 'flex',
                        alignItems: 'center',
                        gap: '5px',
                        color: '#666',
                        fontSize: '14px'
                      }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M17.657 16.657L13.414 20.9C13.039 21.2746 12.5306 21.4852 12.0005 21.4852C11.4704 21.4852 10.962 21.2746 10.587 20.9L6.343 16.657C5.22422 15.5382 4.46234 14.1127 4.15369 12.5609C3.84504 11.009 4.00349 9.40055 4.60901 7.93872C5.21452 6.47689 6.2399 5.22753 7.55548 4.34851C8.87107 3.4695 10.4178 3.00029 12 3.00029C13.5822 3.00029 15.1289 3.4695 16.4445 4.34851C17.7601 5.22753 18.7855 6.47689 19.391 7.93872C19.9965 9.40055 20.155 11.009 19.8463 12.5609C19.5377 14.1127 18.7758 15.5382 17.657 16.657Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                          <path d="M15 11C15 12.6569 13.6569 14 12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        {property.location}
                      </div>
                    </div>
                    
                    <p style={{ 
                      margin: '0 0 20px',
                      color: '#666',
                      fontSize: '14px',
                      lineHeight: '1.5',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}>
                      {property.description}
                    </p>
                    
                    <button
                      onClick={() => handlePropertyClick(property)}
                      style={{
                        width: '100%',
                        backgroundColor: 'transparent',
                        color: '#002f34',
                        border: '2px solid #002f34',
                        padding: '10px',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'all 0.3s',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '8px',
                        ':hover': {
                          backgroundColor: '#002f34',
                          color: 'white'
                        }
                      }}
                    >
                      View Full Details
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      
      {/* Add some global styles for animations */}
      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </>
  );
};

export default Home;





