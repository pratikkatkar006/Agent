
// import React, { useState, useEffect } from 'react';
// import { getDatabase, ref, onValue, update } from 'firebase/database';
// import { useNavigate } from 'react-router-dom';
// import { FiSearch, FiDownload, FiEye, FiCheck, FiX, FiDollarSign, FiUser, FiHome, FiClock, FiFilter } from 'react-icons/fi';
// import { RiExchangeLine } from 'react-icons/ri';

// const SuperAdminDashboard = () => {
//   const [offers, setOffers] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [statusFilter, setStatusFilter] = useState('all');
//   const navigate = useNavigate();

//   // Gradient colors for the UI
//   const primaryGradient = 'bg-gradient-to-r from-indigo-500 to-purple-600';
//   const cardGradient = 'bg-gradient-to-br from-white to-gray-50';
//   const sidebarGradient = 'bg-gradient-to-b from-gray-900 to-gray-800';

//   useEffect(() => {
//     const db = getDatabase();
//     const offersRef = ref(db, 'offers');
    
//     onValue(offersRef, (snapshot) => {
//       const offersData = snapshot.val();
//       if (offersData) {
//         const offersList = Object.entries(offersData).map(([id, offer]) => ({
//           id,
//           ...offer,
//           submittedAt: new Date(offer.submittedAt).toLocaleString(),
//           priceDifference: ((offer.offerAmount - offer.propertyPrice) / offer.propertyPrice * 100).toFixed(1)
//         }));
//         setOffers(offersList);
//       } else {
//         setOffers([]);
//       }
//       setLoading(false);
//     });

//     return () => onValue(offersRef, () => {});
//   }, []);

//   const handleStatusChange = (offerId, newStatus) => {
//     const db = getDatabase();
//     update(ref(db, `offers/${offerId}`), {
//       status: newStatus,
//       statusUpdatedAt: new Date().toISOString()
//     });
//   };

//   const filteredOffers = offers.filter(offer => {
//     const matchesSearch = 
//       offer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       offer.propertyTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       offer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       offer.phone.includes(searchTerm);
    
//     const matchesStatus = 
//       statusFilter === 'all' || offer.status === statusFilter;
    
//     return matchesSearch && matchesStatus;
//   });

//   const StatusPill = ({ status }) => {
//     const statusConfig = {
//       pending: { color: 'bg-amber-100 text-amber-800', icon: <FiClock className="mr-1" /> },
//       accepted: { color: 'bg-emerald-100 text-emerald-800', icon: <FiCheck className="mr-1" /> },
//       rejected: { color: 'bg-rose-100 text-rose-800', icon: <FiX className="mr-1" /> },
//       expired: { color: 'bg-gray-100 text-gray-800', icon: <FiClock className="mr-1" /> }
//     };
    
//     return (
//       <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${statusConfig[status]?.color || ''}`}>
//         {statusConfig[status]?.icon}
//         {status.charAt(0).toUpperCase() + status.slice(1)}
//       </span>
//     );
//   };

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-screen bg-gray-50">
//         <div className="flex flex-col items-center">
//           <div className={`h-16 w-16 ${primaryGradient} rounded-full animate-pulse`}></div>
//           <p className="mt-4 text-gray-600">Loading offers...</p>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="flex h-screen bg-gray-50 font-sans">
//       {/* Glass Morphism Sidebar */}
//       <div className={`w-72 ${sidebarGradient} text-white shadow-xl backdrop-blur-lg`}>
//         <div className="p-6 border-b border-gray-700">
//           <h1 className="text-2xl font-bold flex items-center">
//             <span className={`inline-block h-8 w-8 ${primaryGradient} rounded-lg mr-3`}></span>
//             EstatePro Admin
//           </h1>
//           <p className="text-gray-400 text-sm mt-1">Super Admin Dashboard</p>
//         </div>
        
//         <nav className="p-4">
//           <div className="space-y-2">
//             <div className={`${primaryGradient} p-3 rounded-lg flex items-center font-medium`}>
//               <FiHome className="mr-3" />
//               Dashboard
//             </div>
//             <div className="p-3 rounded-lg flex items-center text-gray-300 hover:bg-gray-700 transition cursor-pointer">
//               <FiUser className="mr-3" />
//               Users
//             </div>
//             <div className="p-3 rounded-lg flex items-center text-gray-300 hover:bg-gray-700 transition cursor-pointer">
//               <RiExchangeLine className="mr-3" />
//               Transactions
//             </div>
//             <div className="p-3 rounded-lg flex items-center text-gray-300 hover:bg-gray-700 transition cursor-pointer">
//               <FiDollarSign className="mr-3" />
//               Offers
//             </div>
//           </div>
          
//           <div className="mt-8 pt-4 border-t border-gray-700">
//             <div className="p-3 rounded-lg flex items-center text-gray-300 hover:bg-gray-700 transition cursor-pointer">
//               Settings
//             </div>
//             <div className="p-3 rounded-lg flex items-center text-gray-300 hover:bg-gray-700 transition cursor-pointer">
//               Logout
//             </div>
//           </div>
//         </nav>
//       </div>

//       {/* Main Content */}
//       <div className="flex-1 overflow-auto">
//         {/* Header */}
//         <header className={`${primaryGradient} text-white p-6 shadow-md`}>
//           <div className="flex justify-between items-center">
//             <h2 className="text-2xl font-bold">Offer Management</h2>
//             <div className="flex items-center space-x-4">
//               <div className="relative">
//                 <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300" />
//                 <input
//                   type="text"
//                   placeholder="Search offers..."
//                   className="pl-10 pr-4 py-2 bg-white bg-opacity-20 rounded-lg text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-300"
//                   value={searchTerm}
//                   onChange={(e) => setSearchTerm(e.target.value)}
//                 />
//               </div>
//               <button className="flex items-center px-4 py-2 bg-white bg-opacity-10 hover:bg-opacity-20 rounded-lg transition">
//                 <FiDownload className="mr-2" />
//                 Export
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* Dashboard Content */}
//         <main className="p-6">
//           {/* Stats Cards */}
//           <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
//             <div className={`${cardGradient} p-6 rounded-xl shadow-sm border border-gray-100`}>
//               <div className="flex justify-between items-start">
//                 <div>
//                   <p className="text-gray-500 text-sm">Total Offers</p>
//                   <h3 className="text-3xl font-bold mt-1 text-gray-800">{offers.length}</h3>
//                 </div>
//                 <div className={`p-3 ${primaryGradient} rounded-lg text-white`}>
//                   <FiDollarSign size={20} />
//                 </div>
//               </div>
//             </div>
            
//             <div className={`${cardGradient} p-6 rounded-xl shadow-sm border border-gray-100`}>
//               <div className="flex justify-between items-start">
//                 <div>
//                   <p className="text-gray-500 text-sm">Pending</p>
//                   <h3 className="text-3xl font-bold mt-1 text-amber-500">
//                     {offers.filter(o => o.status === 'pending').length}
//                   </h3>
//                 </div>
//                 <div className="p-3 bg-amber-100 rounded-lg text-amber-600">
//                   <FiClock size={20} />
//                 </div>
//               </div>
//             </div>
            
//             <div className={`${cardGradient} p-6 rounded-xl shadow-sm border border-gray-100`}>
//               <div className="flex justify-between items-start">
//                 <div>
//                   <p className="text-gray-500 text-sm">Accepted</p>
//                   <h3 className="text-3xl font-bold mt-1 text-emerald-500">
//                     {offers.filter(o => o.status === 'accepted').length}
//                   </h3>
//                 </div>
//                 <div className="p-3 bg-emerald-100 rounded-lg text-emerald-600">
//                   <FiCheck size={20} />
//                 </div>
//               </div>
//             </div>
            
//             <div className={`${cardGradient} p-6 rounded-xl shadow-sm border border-gray-100`}>
//               <div className="flex justify-between items-start">
//                 <div>
//                   <p className="text-gray-500 text-sm">Rejected</p>
//                   <h3 className="text-3xl font-bold mt-1 text-rose-500">
//                     {offers.filter(o => o.status === 'rejected').length}
//                   </h3>
//                 </div>
//                 <div className="p-3 bg-rose-100 rounded-lg text-rose-600">
//                   <FiX size={20} />
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Filters */}
//           <div className={`${cardGradient} p-5 rounded-xl shadow-sm border border-gray-100 mb-6`}>
//             <div className="flex items-center justify-between">
//               <h3 className="font-medium text-gray-700 flex items-center">
//                 <FiFilter className="mr-2" />
//                 Filter Offers
//               </h3>
//               <div className="flex space-x-4">
//                 <select
//                   className="px-4 py-2 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
//                   value={statusFilter}
//                   onChange={(e) => setStatusFilter(e.target.value)}
//                 >
//                   <option value="all">All Statuses</option>
//                   <option value="pending">Pending</option>
//                   <option value="accepted">Accepted</option>
//                   <option value="rejected">Rejected</option>
//                 </select>
//               </div>
//             </div>
//           </div>

//           {/* Offers Table */}
//           <div className={`${cardGradient} rounded-xl shadow-sm border border-gray-100 overflow-hidden`}>
//             <div className="overflow-x-auto">
//               <table className="min-w-full divide-y divide-gray-200">
//                 <thead className="bg-gray-50">
//                   <tr>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Property</th>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Buyer Details</th>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Offer Details</th>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
//                     <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
//                   </tr>
//                 </thead>
//                 <tbody className="bg-white divide-y divide-gray-200">
//                   {filteredOffers.length > 0 ? (
//                     filteredOffers.map((offer) => (
//                       <tr key={offer.id} className="hover:bg-gray-50 transition">
//                         <td className="px-6 py-5">
//                           <div className="flex items-center">
//                             <div className="flex-shrink-0 h-12 w-12 rounded-lg overflow-hidden border border-gray-200">
//                               <img 
//                                 className="h-full w-full object-cover"
//                                 src={offer.propertyImage || 'https://via.placeholder.com/150'} 
//                                 alt={offer.propertyTitle}
//                               />
//                             </div>
//                             <div className="ml-4">
//                               <div className="text-sm font-semibold text-gray-900">{offer.propertyTitle}</div>
//                               <div className="text-sm text-gray-500">₹{offer.propertyPrice?.toLocaleString('en-IN')}</div>
//                             </div>
//                           </div>
//                         </td>
//                         <td className="px-6 py-5">
//                           <div className="text-sm font-semibold text-gray-900">{offer.name}</div>
//                           <div className="text-sm text-gray-500">{offer.email}</div>
//                           <div className="text-sm text-gray-500">{offer.phone}</div>
//                         </td>
//                         <td className="px-6 py-5">
//                           <div className="flex items-center">
//                             <span className="text-lg font-bold text-gray-900">
//                               ₹{offer.offerAmount?.toLocaleString('en-IN')}
//                             </span>
//                             <span className={`ml-2 text-xs px-2 py-1 rounded-full ${
//                               offer.priceDifference >= 0 
//                                 ? 'bg-emerald-100 text-emerald-800' 
//                                 : 'bg-rose-100 text-rose-800'
//                             }`}>
//                               {offer.priceDifference >= 0 ? '+' : ''}{offer.priceDifference}%
//                             </span>
//                           </div>
//                           <div className="text-xs text-gray-500 mt-1">{offer.message?.substring(0, 50)}...</div>
//                         </td>
//                         <td className="px-6 py-5">
//                           <StatusPill status={offer.status} />
//                         </td>
//                         <td className="px-6 py-5 text-sm text-gray-500">
//                           {offer.submittedAt}
//                         </td>
//                         <td className="px-6 py-5 text-sm font-medium">
//                           <div className="flex space-x-3">
//                             <button 
//                               onClick={() => handleStatusChange(offer.id, 'accepted')}
//                               className={`p-2 rounded-lg ${offer.status === 'accepted' ? 'bg-emerald-100 text-emerald-600' : 'hover:bg-gray-100 text-gray-600'}`}
//                               disabled={offer.status === 'accepted'}
//                               title="Accept Offer"
//                             >
//                               <FiCheck size={18} />
//                             </button>
//                             <button 
//                               onClick={() => handleStatusChange(offer.id, 'rejected')}
//                               className={`p-2 rounded-lg ${offer.status === 'rejected' ? 'bg-rose-100 text-rose-600' : 'hover:bg-gray-100 text-gray-600'}`}
//                               disabled={offer.status === 'rejected'}
//                               title="Reject Offer"
//                             >
//                               <FiX size={18} />
//                             </button>
//                             <button 
//                               onClick={() => navigate(`/property/${offer.propertyCategory}/${offer.propertyId}`)}
//                               className="p-2 rounded-lg hover:bg-gray-100 text-gray-600"
//                               title="View Property"
//                             >
//                               <FiEye size={18} />
//                             </button>
//                           </div>
//                         </td>
//                       </tr>
//                     ))
//                   ) : (
//                     <tr>
//                       <td colSpan="6" className="px-6 py-8 text-center">
//                         <div className="flex flex-col items-center justify-center text-gray-500">
//                           <FiSearch size={48} className="mb-4 opacity-30" />
//                           <p className="text-lg">No offers found matching your criteria</p>
//                           <button 
//                             onClick={() => {
//                               setSearchTerm('');
//                               setStatusFilter('all');
//                             }}
//                             className="mt-4 px-4 py-2 text-sm text-purple-600 hover:text-purple-800"
//                           >
//                             Clear filters
//                           </button>
//                         </div>
//                       </td>
//                     </tr>
//                   )}
//                 </tbody>
//               </table>
//             </div>
//           </div>
//         </main>
//       </div>
//     </div>
//   );
// };

// export default SuperAdminDashboard;

















import React, { useState, useEffect } from 'react';
import { getDatabase, ref, onValue, update } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import { 
  FiUsers, FiSettings, FiLogOut, FiActivity, FiPieChart, 
  FiBarChart2, FiTrendingUp, FiShield, FiDatabase, 
  FiBell, FiMail, FiCalendar, FiClock, FiSearch, FiCheck, FiX, FiUser, FiDollarSign
} from 'react-icons/fi';
import { RiDashboardLine, RiExchangeDollarLine } from 'react-icons/ri';
import { BsGraphUp, BsHouseDoor ,BsLightningFill } from 'react-icons/bs';
import { BsFillLightningFill } from 'react-icons/bs';
import { TbChartArcs, TbHomeDollar } from 'react-icons/tb';





// GlassCard component defined at the top level
const GlassCard = ({ children, style }) => {
  const theme = {
    glass: 'rgba(255, 255, 255, 0.05)',
    glassBorder: 'rgba(255, 255, 255, 0.1)'
  };
  
  return (
    <div style={{
      background: theme.glass,
      backdropFilter: 'blur(12px)',
      borderRadius: '16px',
      border: `1px solid ${theme.glassBorder}`,
      boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
      padding: '20px',
      ...style
    }}>
      {children}
    </div>
  );
};

// StatusBadge component defined at the top level
const StatusBadge = ({ status, type = 'user' }) => {
  const theme = {
    primary: '#6366f1',
    secondary: '#8b5cf6',
    accent: '#ec4899',
    success: '#10b981',
    warning: '#f59e0b',
    danger: '#ef4444',
    dark: '#1e293b',
    light: '#f8fafc',
    muted: '#94a3b8'
  };

  const config = {
    user: {
      active: { color: theme.success, icon: '✓' },
      suspended: { color: theme.warning, icon: '⏸' },
      banned: { color: theme.danger, icon: '✗' },
      inactive: { color: theme.muted, icon: '○' }
    },
    offer: {
      pending: { color: theme.warning, icon: '🔄' },
      accepted: { color: theme.success, icon: '✓' },
      rejected: { color: theme.danger, icon: '✗' },
      countered: { color: theme.secondary, icon: '↔' }
    }
  };
  
  const { color, icon } = config[type][status] || { color: theme.muted, icon: '?' };

  return (
    <div style={{
      display: 'inline-flex',
      alignItems: 'center',
      padding: '4px 12px',
      borderRadius: '20px',
      backgroundColor: `${color}20`,
      color: color,
      fontSize: '12px',
      fontWeight: '500',
      border: `1px solid ${color}40`
    }}>
      <span style={{ marginRight: '6px' }}>{icon}</span>
      {status?.charAt(0).toUpperCase() + status?.slice(1)}
    </div>
  );
};

const SuperAdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('users');
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeToday: 0,
    premiumUsers: 0,
    newThisWeek: 0
  });
  const navigate = useNavigate();

  const [offers, setOffers] = useState([]);
  const [offerStatusFilter, setOfferStatusFilter] = useState('all');

  useEffect(() => {
    const db = getDatabase();
    const usersRef = ref(db, `delar/customers/`);
    
    onValue(usersRef, (snapshot) => {
      const usersData = snapshot.val();
      if (usersData) {
        const usersList = Object.entries(usersData).map(([id, user]) => ({
          id,
          ...user,
          lastActive: user.lastActive ? new Date(user.lastActive).toLocaleString() : 'Never',
          joinedAt: new Date(user.joinedAt).toLocaleString()
        }));
        
        setUsers(usersList);
        
        // Calculate stats
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - (24 * 60 * 60 * 1000));
        const oneWeekAgo = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
        
        setStats({
          totalUsers: usersList.length,
          activeToday: usersList.filter(u => u.lastActive && new Date(u.lastActive) > oneDayAgo).length,
          premiumUsers: usersList.filter(u => u.accountType === 'premium').length,
          newThisWeek: usersList.filter(u => new Date(u.joinedAt) > oneWeekAgo).length
        });
      } else {
        setUsers([]);
      }
      setLoading(false);
    });

    return () => onValue(usersRef, () => {});
  }, []);

  useEffect(() => {
    if (activeTab === 'offers') {
      const db = getDatabase();
      const offersRef = ref(db, 'delar/admin/offers');
      
      onValue(offersRef, (snapshot) => {
        const offersData = snapshot.val();
        if (offersData) {
          const offersList = Object.entries(offersData).map(([id, offer]) => ({
            id,
            ...offer,
            timestamp: offer.timestamp ? new Date(offer.timestamp).toLocaleString() : 'Unknown'
          }));
          setOffers(offersList);
        } else {
          setOffers([]);
        }
      });

      return () => onValue(offersRef, () => {});
    }
  }, [activeTab]);

  const updateUserStatus = (userId, newStatus) => {
    const db = getDatabase();
    update(ref(db, `users/${userId}`), {
      status: newStatus,
      lastUpdated: new Date().toISOString()
    });
  };

  

  const updateOfferStatus = (offerId, newStatus) => {
    const db = getDatabase();
    update(ref(db, `delar/admin/offers/${offerId}`), {
      status: newStatus,
      updatedAt: new Date().toISOString()
    });
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.uid?.includes(searchTerm);
    
    const matchesStatus = 
      statusFilter === 'all' || user.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const theme = {
    primary: '#6366f1',
    secondary: '#8b5cf6',
    accent: '#ec4899',
    success: '#10b981',
    warning: '#f59e0b',
    danger: '#ef4444',
    dark: '#1e293b',
    light: '#f8fafc',
    muted: '#94a3b8',
    glass: 'rgba(255, 255, 255, 0.05)',
    glassBorder: 'rgba(255, 255, 255, 0.1)',
    glassHighlight: 'rgba(255, 255, 255, 0.15)'
  };

  // Loading state with new design
  if (loading) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
        background: `linear-gradient(135deg, ${theme.dark} 0%, #0f172a 100%)`,
        color: theme.light
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '80px',
            height: '80px',
            borderRadius: '50%',
            background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 20px',
            animation: 'pulse 1.5s infinite'
          }}>
            <BsLightningFill style={{ color: 'white', fontSize: '32px' }} />
          </div>
          <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>Loading Dashboard</h2>
          <p style={{ color: theme.muted }}>Fetching the latest data...</p>
        </div>
      </div>
    );
  }


  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      background: `linear-gradient(135deg, ${theme.dark} 0%, #0f172a 100%)`,
      color: theme.light,
      fontFamily: "'Inter', sans-serif"
    }}>
      {/* Sidebar - Slim Design */}
      <div style={{
        width: '80px',
        background: 'rgba(15, 23, 42, 0.7)',
        borderRight: `1px solid ${theme.glassBorder}`,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '20px 0'
      }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '12px',
          background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: '30px'
        }}>
          <BsLightningFill style={{ color: 'white', fontSize: '20px' }} />
        </div>
        
        <nav style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '16px',
          flex: 1
        }}>
          {[
            { id: 'dashboard', icon: <RiDashboardLine size={20} /> },
            { id: 'users', icon: <FiUsers size={20} /> },
            { id: 'offers', icon: <TbHomeDollar size={20} /> },
            { id: 'analytics', icon: <BsGraphUp size={20} /> },
            { id: 'transactions', icon: <RiExchangeDollarLine size={20} /> },
            { id: 'settings', icon: <FiSettings size={20} /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                width: '44px',
                height: '44px',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s',
                ...(activeTab === tab.id ? {
                  background: theme.glassHighlight,
                  color: theme.primary
                } : {
                  color: theme.muted,
                  ':hover': {
                    background: theme.glass,
                    color: theme.light
                  }
                })
              }}
            >
              {tab.icon}
            </button>
          ))}
        </nav>
        
        <button style={{
          width: '44px',
          height: '44px',
          borderRadius: '12px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: theme.muted,
          transition: 'all 0.2s',
          ':hover': {
            background: theme.glass,
            color: theme.danger
          }
        }}>
          <FiLogOut size={20} />
        </button>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Top Bar */}
        <header style={{
          padding: '16px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: `1px solid ${theme.glassBorder}`
        }}>
          <h2 style={{
            fontSize: '20px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            {activeTab === 'dashboard' && <RiDashboardLine />}
            {activeTab === 'users' && <FiUsers />}
            {activeTab === 'offers' && <TbHomeDollar />}
            {activeTab === 'analytics' && <BsGraphUp />}
            {activeTab === 'transactions' && <RiExchangeDollarLine />}
            {activeTab === 'settings' && <FiSettings />}
            {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}
          </h2>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ position: 'relative' }}>
              <FiSearch style={{
                position: 'absolute',
                left: '12px',
                top: '50%',
                transform: 'translateY(-50%)',
                color: theme.muted
              }} />
              <input
                type="text"
                placeholder="Search..."
                style={{
                  padding: '8px 12px 8px 36px',
                  borderRadius: '12px',
                  background: theme.glass,
                  border: `1px solid ${theme.glassBorder}`,
                  color: theme.light,
                  outline: 'none',
                  minWidth: '240px',
                  '::placeholder': {
                    color: theme.muted
                  },
                  ':focus': {
                    borderColor: theme.primary,
                    boxShadow: `0 0 0 2px ${theme.primary}20`
                  }
                }}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <button style={{
              width: '40px',
              height: '40px',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
              background: theme.glass,
              border: `1px solid ${theme.glassBorder}`,
              color: theme.muted,
              transition: 'all 0.2s',
              ':hover': {
                background: theme.glassHighlight,
                color: theme.light
              }
            }}>
              <FiBell />
              <span style={{
                position: 'absolute',
                top: '6px',
                right: '6px',
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: theme.danger,
                border: `1px solid ${theme.dark}`
              }}></span>
            </button>
            
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '8px 12px',
              borderRadius: '12px',
              background: theme.glass,
              border: `1px solid ${theme.glassBorder}`,
              cursor: 'pointer',
              transition: 'all 0.2s',
              ':hover': {
                background: theme.glassHighlight
              }
            }}>
              <div style={{
                width: '32px',
                height: '32px',
                borderRadius: '8px',
                background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: '600',
                fontSize: '14px'
              }}>
                SA
              </div>
              <span style={{ fontSize: '14px', fontWeight: '500' }}>Super Admin</span>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main style={{ padding: '24px', flex: 1, overflow: 'auto' }}>
          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {/* Stats Cards */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
                gap: '16px'
              }}>
                {[
                  { title: 'Total Users', value: stats.totalUsers, change: '+12%', icon: <FiUsers />, color: theme.primary },
                  { title: 'Active Today', value: stats.activeToday, change: '+8%', icon: <FiActivity />, color: theme.success },
                  { title: 'Premium Users', value: stats.premiumUsers, change: '+24%', icon: <FiUser />, color: theme.secondary },
                  { title: 'New This Week', value: stats.newThisWeek, change: '+5%', icon: <FiPieChart />, color: theme.accent }
                ].map((stat, index) => (
                  <GlassCard key={index}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <div>
                        <p style={{ color: theme.muted, fontSize: '14px', marginBottom: '8px' }}>{stat.title}</p>
                        <h3 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '4px' }}>{stat.value}</h3>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                          <span style={{ 
                            color: stat.change.startsWith('+') ? theme.success : theme.danger,
                            fontSize: '14px'
                          }}>
                            {stat.change}
                          </span>
                          <span style={{ color: theme.muted, fontSize: '12px' }}>vs last period</span>
                        </div>
                      </div>
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '12px',
                        background: `${stat.color}20`,
                        border: `1px solid ${stat.color}30`,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: stat.color
                      }}>
                        {stat.icon}
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
              
              {/* Recent Activity */}
              <GlassCard style={{ marginTop: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
                  <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Recent Activity</h3>
                  <button style={{
                    background: 'transparent',
                    border: 'none',
                    color: theme.primary,
                    fontSize: '14px',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}>
                    View All
                  </button>
                </div>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {[1, 2, 3].map((item) => (
                    <div key={item} style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      paddingBottom: '16px',
                      borderBottom: `1px solid ${theme.glassBorder}`,
                      ':last-child': {
                        borderBottom: 'none',
                        paddingBottom: '0'
                      }
                    }}>
                      <div style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '12px',
                        background: theme.glassHighlight,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        <FiUser style={{ color: theme.muted }} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <p style={{ fontWeight: '500' }}>User #{item} performed an action</p>
                          <span style={{ color: theme.muted, fontSize: '12px' }}>{item}h ago</span>
                        </div>
                        <p style={{ color: theme.muted, fontSize: '14px', marginTop: '4px' }}>
                          Details about this activity would appear here
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>
          )}
          
          {/* Users Tab */}
          {activeTab === 'users' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: '600' }}>User Management</h3>
                  <p style={{ color: theme.muted, fontSize: '14px', marginTop: '4px' }}>
                    Manage all registered users and their permissions
                  </p>
                </div>
                
                <div style={{ display: 'flex', gap: '12px' }}>
                  <select
                    style={{
                      padding: '8px 12px',
                      borderRadius: '12px',
                      background: theme.glass,
                      border: `1px solid ${theme.glassBorder}`,
                      color: theme.light,
                      outline: 'none',
                      minWidth: '160px',
                      ':focus': {
                        borderColor: theme.primary
                      }
                    }}
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="all">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="banned">Banned</option>
                    <option value="inactive">Inactive</option>
                  </select>
                  
                  <button style={{
                    padding: '8px 16px',
                    borderRadius: '12px',
                    background: `linear-gradient(135deg, ${theme.primary} 0%, ${theme.secondary} 100%)`,
                    border: 'none',
                    color: 'white',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    ':hover': {
                      transform: 'translateY(-1px)',
                      boxShadow: `0 4px 12px ${theme.primary}30`
                    }
                  }}>
                    Add User
                  </button>
                </div>
              </div>
              
              {/* Users Table */}
              <GlassCard style={{ overflow: 'hidden' }}>
  <div style={{ overflowX: 'auto' }}>
    <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '0' }}>
      <thead>
        <tr style={{
          background: theme.glassHighlight,
          borderBottom: `1px solid ${theme.glassBorder}`
        }}>
          {['User', 'Mobile', 'Username', 'Address', 'Properties', 'Status', 'Last Active', 'Actions'].map((header) => (
            <th key={header} style={{
              padding: '12px 16px',
              textAlign: 'left',
              fontSize: '12px',
              fontWeight: '600',
              color: theme.muted,
              textTransform: 'uppercase',
              letterSpacing: '0.05em'
            }}>
              {header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {filteredUsers.length > 0 ? (
          filteredUsers.map((user) => (
            <tr key={user.id} style={{
              borderBottom: `1px solid ${theme.glassBorder}`,
              transition: 'all 0.2s',
              ':hover': {
                background: theme.glassHighlight
              },
              ':last-child': {
                borderBottom: 'none'
              }
            }}>
              {/* User Cell */}
              <td style={{ padding: '16px', minWidth: '200px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '12px',
                    background: theme.glassHighlight,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden'
                  }}>
                    <FiUser style={{ color: theme.muted }} />
                  </div>
                  <div>
                    <div style={{ fontWeight: '500' }}>{user.username || 'Unnamed User'}</div>
                    <div style={{ color: theme.muted, fontSize: '14px' }}>Registered: {user.joinedAt}</div>
                  </div>
                </div>
              </td>

              {/* Mobile Number */}
              <td style={{ padding: '16px', color: theme.light }}>
                {user.mobile}
              </td>

              {/* Username */}
              <td style={{ padding: '16px' }}>
                {user.username || 'N/A'}
              </td>

              {/* Address */}
              <td style={{ padding: '16px', color: theme.muted }}>
                {user.address || 'No address provided'}
              </td>

              {/* Properties */}
              <td style={{ padding: '16px', maxWidth: '200px' }}>
                <div style={{ 
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '4px',
                  color: theme.muted,
                  fontSize: '14px'
                }}>
                  {user.properties ? (
                    Object.entries(user.properties).map(([key, value]) => (
                      <div key={key}>
                        <span style={{ color: theme.light }}>{key}:</span> {value}
                      </div>
                    ))
                  ) : (
                    'No properties listed'
                  )}
                </div>
              </td>

              {/* Status */}
              <td style={{ padding: '16px' }}>
                <StatusBadge status={user.status || 'inactive'} type="user" />
              </td>

              {/* Last Active */}
              <td style={{ padding: '16px', color: theme.muted, fontSize: '14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <FiClock size={14} />
                  {user.lastActive || 'Never'}
                </div>
              </td>
                            <td style={{ padding: '16px' }}>
                              <div style={{ display: 'flex', gap: '8px' }}>
                                <button 
                                  onClick={() => updateUserStatus(user.id, 'active')}
                                  style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    background: user.status === 'active' ? `${theme.success}20` : 'transparent',
                                    border: user.status === 'active' ? `1px solid ${theme.success}30` : `1px solid ${theme.glassBorder}`,
                                    color: user.status === 'active' ? theme.success : theme.muted,
                                    cursor: user.status === 'active' ? 'default' : 'pointer',
                                    transition: 'all 0.2s',
                                    ':hover': {
                                      background: user.status !== 'active' ? theme.glassHighlight : undefined,
                                      color: user.status !== 'active' ? theme.light : undefined
                                    }
                                  }}
                                  disabled={user.status === 'active'}
                                  title="Activate"
                                >
                                  <FiCheck size={16} />
                                </button>
                                <button 
                                  onClick={() => updateUserStatus(user.id, 'suspended')}
                                  style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    background: user.status === 'suspended' ? `${theme.warning}20` : 'transparent',
                                    border: user.status === 'suspended' ? `1px solid ${theme.warning}30` : `1px solid ${theme.glassBorder}`,
                                    color: user.status === 'suspended' ? theme.warning : theme.muted,
                                    cursor: user.status === 'suspended' ? 'default' : 'pointer',
                                    transition: 'all 0.2s',
                                    ':hover': {
                                      background: user.status !== 'suspended' ? theme.glassHighlight : undefined,
                                      color: user.status !== 'suspended' ? theme.light : undefined
                                    }
                                  }}
                                  disabled={user.status === 'suspended'}
                                  title="Suspend"
                                >
                                  <FiClock size={16} />
                                </button>
                                <button 
                                  onClick={() => updateUserStatus(user.id, 'banned')}
                                  style={{
                                    width: '32px',
                                    height: '32px',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    background: user.status === 'banned' ? `${theme.danger}20` : 'transparent',
                                    border: user.status === 'banned' ? `1px solid ${theme.danger}30` : `1px solid ${theme.glassBorder}`,
                                    color: user.status === 'banned' ? theme.danger : theme.muted,
                                    cursor: user.status === 'banned' ? 'default' : 'pointer',
                                    transition: 'all 0.2s',
                                    ':hover': {
                                      background: user.status !== 'banned' ? theme.glassHighlight : undefined,
                                      color: user.status !== 'banned' ? theme.light : undefined
                                    }
                                  }}
                                  disabled={user.status === 'banned'}
                                  title="Ban"
                                >
                                  <FiX size={16} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="5" style={{ padding: '40px', textAlign: 'center' }}>
                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
                              <FiSearch size={48} style={{ color: theme.muted, opacity: 0.5 }} />
                              <p style={{ fontSize: '16px', color: theme.light }}>No users found matching your criteria</p>
                              <button 
                                onClick={() => {
                                  setSearchTerm('');
                                  setStatusFilter('all');
                                }}
                                style={{
                                  padding: '8px 16px',
                                  borderRadius: '8px',
                                  background: theme.glassHighlight,
                                  border: `1px solid ${theme.glassBorder}`,
                                  color: theme.primary,
                                  fontSize: '14px',
                                  cursor: 'pointer',
                                  transition: 'all 0.2s',
                                  ':hover': {
                                    background: theme.glass
                                  }
                                }}
                              >
                                Clear filters
                              </button>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            </div>
          )}
          
          {/* Property Offers Tab */}
          {activeTab === 'offers' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h3 style={{ fontSize: '18px', fontWeight: '600' }}>Property Offers</h3>
                  <p style={{ color: theme.muted, fontSize: '14px', marginTop: '4px' }}>
                    Manage all property offers submitted by buyers
                  </p>
                </div>
                
                <select
                  style={{
                    padding: '8px 12px',
                    borderRadius: '12px',
                    background: theme.glass,
                    border: `1px solid ${theme.glassBorder}`,
                    color: theme.light,
                    outline: 'none',
                    minWidth: '160px',
                    ':focus': {
                      borderColor: theme.primary
                    }
                  }}
                  value={offerStatusFilter}
                  onChange={(e) => setOfferStatusFilter(e.target.value)}
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending</option>
                  <option value="accepted">Accepted</option>
                  <option value="rejected">Rejected</option>
                  <option value="countered">Countered</option>
                </select>
              </div>
              
              {/* Offers Grid */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))',
                gap: '16px'
              }}>
                {offers.length > 0 ? (
                  offers
                    .filter(offer => offerStatusFilter === 'all' || offer.status === offerStatusFilter)
                    .map((offer) => (
                      <GlassCard key={offer.id}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                          <div>
                            <h3 style={{ 
                              fontSize: '16px', 
                              fontWeight: '600',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px'
                            }}>
                              <BsHouseDoor style={{ color: theme.primary }} />
                              {offer.propertyTitle}
                            </h3>
                            <p style={{ color: theme.muted, fontSize: '14px', marginTop: '4px' }}>
                              {offer.propertyCategory} • ₹{offer.propertyPrice?.toLocaleString('en-IN')}
                            </p>
                          </div>
                          <StatusBadge status={offer.status || 'pending'} type="offer" />
                        </div>
                        
                        <div style={{ marginBottom: '16px' }}>
                          <h4 style={{ fontSize: '14px', fontWeight: '500', marginBottom: '8px' }}>Buyer Details</h4>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <FiUser size={14} style={{ color: theme.muted }} />
                              <span>{offer.name}</span>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <FiMail size={14} style={{ color: theme.muted }} />
                              <span>{offer.email}</span>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <FiCalendar size={14} style={{ color: theme.muted }} />
                              <span>{offer.timestamp}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div style={{ 
                          display: 'flex', 
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          marginBottom: offer.message ? '16px' : '0'
                        }}>
                          <div>
                            <h4 style={{ fontSize: '14px', fontWeight: '500', marginBottom: '4px' }}>Offer Amount</h4>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                              <FiDollarSign style={{ color: theme.warning }} />
                              <span style={{ fontSize: '18px', fontWeight: '600' }}>
                                ₹{offer.offerAmount?.toLocaleString('en-IN')}
                              </span>
                              <span style={{
                                fontSize: '12px',
                                color: offer.offerAmount >= offer.propertyPrice ? theme.success : theme.warning
                              }}>
                                ({offer.offerAmount >= offer.propertyPrice ? 'Above' : 'Below'} asking price)
                              </span>
                            </div>
                          </div>
                          
                          <div style={{ display: 'flex', gap: '8px' }}>
                            <button 
                              onClick={() => updateOfferStatus(offer.id, 'accepted')}
                              style={{
                                width: '32px',
                                height: '32px',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                background: offer.status === 'accepted' ? `${theme.success}20` : 'transparent',
                                border: offer.status === 'accepted' ? `1px solid ${theme.success}30` : `1px solid ${theme.glassBorder}`,
                                color: offer.status === 'accepted' ? theme.success : theme.muted,
                                cursor: offer.status === 'accepted' ? 'default' : 'pointer',
                                transition: 'all 0.2s',
                                ':hover': {
                                  background: offer.status !== 'accepted' ? theme.glassHighlight : undefined,
                                  color: offer.status !== 'accepted' ? theme.light : undefined
                                }
                              }}
                              disabled={offer.status === 'accepted'}
                              title="Accept Offer"
                            >
                              <FiCheck size={16} />
                            </button>
                            <button 
                              onClick={() => updateOfferStatus(offer.id, 'rejected')}
                              style={{
                                width: '32px',
                                height: '32px',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                background: offer.status === 'rejected' ? `${theme.danger}20` : 'transparent',
                                border: offer.status === 'rejected' ? `1px solid ${theme.danger}30` : `1px solid ${theme.glassBorder}`,
                                color: offer.status === 'rejected' ? theme.danger : theme.muted,
                                cursor: offer.status === 'rejected' ? 'default' : 'pointer',
                                transition: 'all 0.2s',
                                ':hover': {
                                  background: offer.status !== 'rejected' ? theme.glassHighlight : undefined,
                                  color: offer.status !== 'rejected' ? theme.light : undefined
                                }
                              }}
                              disabled={offer.status === 'rejected'}
                              title="Reject Offer"
                            >
                              <FiX size={16} />
                            </button>
                            <button 
                              onClick={() => updateOfferStatus(offer.id, 'countered')}
                              style={{
                                width: '32px',
                                height: '32px',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                background: offer.status === 'countered' ? `${theme.secondary}20` : 'transparent',
                                border: offer.status === 'countered' ? `1px solid ${theme.secondary}30` : `1px solid ${theme.glassBorder}`,
                                color: offer.status === 'countered' ? theme.secondary : theme.muted,
                                cursor: offer.status === 'countered' ? 'default' : 'pointer',
                                transition: 'all 0.2s',
                                ':hover': {
                                  background: offer.status !== 'countered' ? theme.glassHighlight : undefined,
                                  color: offer.status !== 'countered' ? theme.light : undefined
                                }
                              }}
                              disabled={offer.status === 'countered'}
                              title="Counter Offer"
                            >
                              <FiMail size={16} />
                            </button>
                          </div>
                        </div>
                        
                        {offer.message && (
                          <div style={{ 
                            marginTop: '16px',
                            paddingTop: '16px',
                            borderTop: `1px solid ${theme.glassBorder}`
                          }}>
                            <h4 style={{ fontSize: '14px', fontWeight: '500', marginBottom: '8px' }}>Buyer's Message</h4>
                            <p style={{ color: theme.muted, fontSize: '14px' }}>{offer.message}</p>
                          </div>
                        )}
                      </GlassCard>
                    ))
                ) : (
                  <div style={{
                    gridColumn: '1 / -1',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    padding: '40px',
                    textAlign: 'center'
                  }}>
                    <FiMail size={48} style={{ color: theme.muted, opacity: 0.5 }} />
                    <p style={{ fontSize: '16px', color: theme.light, marginTop: '12px' }}>No property offers found</p>
                    <button 
                      onClick={() => setOfferStatusFilter('all')}
                      style={{
                        marginTop: '16px',
                        padding: '8px 16px',
                        borderRadius: '8px',
                        background: theme.glassHighlight,
                        border: `1px solid ${theme.glassBorder}`,
                        color: theme.primary,
                        fontSize: '14px',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        ':hover': {
                          background: theme.glass
                        }
                      }}
                    >
                      Reset filters
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default SuperAdminDashboard;