// import React, { useState, useEffect, useRef } from 'react';
// import { useNavigate } from 'react-router-dom';
// import Navbar from './Navbar';
// import Footer from './Footer';

// const HomePage = () => {
//   const navigate = useNavigate();
//   const [searchQuery, setSearchQuery] = useState('');
//   const [selectedCategory, setSelectedCategory] = useState('all');
//   const [listings, setListings] = useState([]);
//   const [isLoading, setIsLoading] = useState(true);
//   const [location, setLocation] = useState('All India');
//   const [showAddForm, setShowAddForm] = useState(false);
//   const [newProduct, setNewProduct] = useState({
//     title: '',
//     price: '',
//     description: '',
//     category: 'mobile',
//     location: 'Mumbai',
//     images: [],
//     previewImages: []
//   });
//   const fileInputRef = useRef(null);

//   const categories = [
//     { id: 'all', name: 'All', icon: '📋', color: '#4e79a7' },
//     { id: 'mobile', name: 'Mobiles', icon: '📱', color: '#f28e2b' },
//     { id: 'cars', name: 'Cars', icon: '🚗', color: '#e15759' },
//     { id: 'property', name: 'Property', icon: '🏠', color: '#76b7b2' },
//     { id: 'electronics', name: 'Electronics', icon: '💻', color: '#59a14f' },
//     { id: 'bikes', name: 'Bikes', icon: '🏍️', color: '#edc948' },
//     { id: 'furniture', name: 'Furniture', icon: '🛋️', color: '#b07aa1' },
//     { id: 'jobs', name: 'Jobs', icon: '💼', color: '#ff9da7' }
//   ];

//   const locations = [
//     'All India',
//     'Mumbai',
//     'Delhi',
//     'Bangalore',
//     'Hyderabad',
//     'Chennai',
//     'Pune',
//     'Kolkata'
//   ];

//   useEffect(() => {
//     const fetchListings = async () => {
//       setIsLoading(true);
//       setTimeout(() => {
//         setListings([
//           // Your listings data here
//         ]);
//         setIsLoading(false);
//       }, 1000);
//     };

//     fetchListings();
//   }, []);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setNewProduct({
//       ...newProduct,
//       [name]: value
//     });
//   };

//   const handleAddProduct = (e) => {
//     e.preventDefault();
//     const product = {
//       ...newProduct,
//       id: Date.now(),
//       date: 'Just now',
//       featured: false,
//       images: newProduct.previewImages 
//     };
    
//     setListings([product, ...listings]);
//     setNewProduct({
//       title: '',
//       price: '',
//       description: '',
//       category: 'mobile',
//       location: 'Mumbai',
//       images: [],
//       previewImages: []
//     });
//     setShowAddForm(false);
//   };

//   const handleImageUpload = (e) => {
//     const files = Array.from(e.target.files);
//     const previews = files.map(file => URL.createObjectURL(file));
    
//     setNewProduct({
//       ...newProduct,
//       images: [...newProduct.images, ...files],
//       previewImages: [...newProduct.previewImages, ...previews]
//     });
//   };

//   const removeImage = (index) => {
//     const newImages = [...newProduct.images];
//     const newPreviews = [...newProduct.previewImages];
    
//     newImages.splice(index, 1);
//     newPreviews.splice(index, 1);
    
//     setNewProduct({
//       ...newProduct,
//       images: newImages,
//       previewImages: newPreviews
//     });
//   };

//   const filteredListings = listings.filter(listing => {
//     const matchesSearch = listing.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
//                          listing.description.toLowerCase().includes(searchQuery.toLowerCase());
//     const matchesCategory = selectedCategory === 'all' || listing.category === selectedCategory;
//     const matchesLocation = location === 'All India' || listing.location === location;
    
//     return matchesSearch && matchesCategory && matchesLocation;
//   });

//   const featuredListings = listings.filter(listing => listing.featured);

//   const handleListingClick = (id) => {
//     navigate(`/listing/${id}`);
//   };

//   return (
//     <div style={{
//       backgroundColor: '#f8f9fa',
//       minHeight: '100vh',
//       fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
//     }}>
//       <Navbar setShowAddForm={setShowAddForm} />
      
//       {/* Location Filter */}
//       <div style={{
//         backgroundColor: 'white',
//         padding: '15px 0',
//         boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
//       }}>
//         <div style={{
//           maxWidth: '1200px',
//           margin: '0 auto',
//           padding: '0 20px',
//           display: 'flex',
//           alignItems: 'center',
//           flexWrap: 'wrap',
//           gap: '10px'
//         }}>
//           <span style={{ 
//             marginRight: '10px', 
//             fontWeight: '600',
//             color: '#002f34'
//           }}>📍 Location:</span>
//           {locations.map(loc => (
//             <button
//               key={loc}
//               onClick={() => setLocation(loc)}
//               style={{
//                 padding: '8px 16px',
//                 borderRadius: '20px',
//                 border: location === loc ? 'none' : '1px solid #e0e0e0',
//                 backgroundColor: location === loc ? '#002f34' : 'white',
//                 color: location === loc ? 'white' : '#002f34',
//                 cursor: 'pointer',
//                 fontWeight: '500',
//                 fontSize: '14px',
//                 transition: 'all 0.2s ease'
//               }}
//             >
//               {loc}
//             </button>
//           ))}
//         </div>
//       </div>

//       {/* Add Product Modal */}
//       {showAddForm && (
//         <div style={{
//           position: 'fixed',
//           top: 0,
//           left: 0,
//           right: 0,
//           bottom: 0,
//           backgroundColor: 'rgba(0,0,0,0.5)',
//           display: 'flex',
//           alignItems: 'center',
//           justifyContent: 'center',
//           zIndex: 1000
//         }}>
//           {/* Modal content */}
//         </div>
//       )}

//       {/* Main Content */}
//       <main style={{
//         maxWidth: '1200px',
//         margin: '0 auto',
//         padding: '30px 20px'
//       }}>
//         {/* Categories */}
//         <section style={{ marginBottom: '40px' }}>
//           <h2 style={{
//             color: '#002f34',
//             marginBottom: '20px',
//             fontSize: '24px',
//             fontWeight: '700'
//           }}>Browse Categories</h2>
//           <div style={{
//             display: 'grid',
//             gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
//             gap: '15px'
//           }}>
//             {categories.map(category => (
//               <button
//                 key={category.id}
//                 onClick={() => setSelectedCategory(category.id)}
//                 style={{
//                   backgroundColor: selectedCategory === category.id ? category.color : 'white',
//                   border: selectedCategory === category.id ? 'none' : '1px solid #e0e0e0',
//                   borderRadius: '12px',
//                   padding: '20px 10px',
//                   cursor: 'pointer',
//                   display: 'flex',
//                   flexDirection: 'column',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
//                   transition: 'all 0.3s ease',
//                   ':hover': {
//                     transform: 'translateY(-5px)',
//                     boxShadow: '0 8px 16px rgba(0,0,0,0.1)'
//                   }
//                 }}
//               >
//                 <span style={{ 
//                   fontSize: '32px', 
//                   marginBottom: '12px',
//                   color: selectedCategory === category.id ? 'white' : category.color
//                 }}>
//                   {category.icon}
//                 </span>
//                 <span style={{
//                   fontSize: '16px',
//                   fontWeight: '600',
//                   color: selectedCategory === category.id ? 'white' : '#002f34'
//                 }}>
//                   {category.name}
//                 </span>
//               </button>
//             ))}
//           </div>
//         </section>

//         {/* Featured Listings */}
//         {featuredListings.length > 0 && (
//           <section style={{ marginBottom: '40px' }}>
//             <div style={{
//               display: 'flex',
//               justifyContent: 'space-between',
//               alignItems: 'center',
//               marginBottom: '20px'
//             }}>
//               <h2 style={{
//                 color: '#002f34',
//                 fontSize: '24px',
//                 fontWeight: '700',
//                 margin: 0
//               }}>Featured Listings</h2>
//               <button style={{
//                 backgroundColor: 'transparent',
//                 border: 'none',
//                 color: '#23e5db',
//                 cursor: 'pointer',
//                 fontWeight: '600',
//                 fontSize: '16px',
//                 display: 'flex',
//                 alignItems: 'center'
//               }}>
//                 View all
//                 <span style={{ marginLeft: '8px', fontSize: '20px' }}>→</span>
//               </button>
//             </div>
//             <div style={{
//               display: 'grid',
//               gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//               gap: '25px'
//             }}>
//               {featuredListings.map(listing => (
//                 <div
//                   key={listing.id}
//                   onClick={() => handleListingClick(listing.id)}
//                   style={{
//                     backgroundColor: 'white',
//                     borderRadius: '16px',
//                     overflow: 'hidden',
//                     boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
//                     cursor: 'pointer',
//                     transition: 'all 0.3s ease',
//                     ':hover': {
//                       transform: 'translateY(-5px)',
//                       boxShadow: '0 8px 24px rgba(0,0,0,0.12)'
//                     }
//                   }}
//                 >
//                   {/* Listing card content */}
//                 </div>
//               ))}
//             </div>
//           </section>
//         )}

//         {/* All Listings */}
//         <section>
//           <div style={{
//             display: 'flex',
//             justifyContent: 'space-between',
//             alignItems: 'center',
//             marginBottom: '20px'
//           }}>
//             <h2 style={{
//               color: '#002f34',
//               fontSize: '24px',
//               fontWeight: '700',
//               margin: 0
//             }}>
//               {selectedCategory === 'all' ? 'All Listings' : 
//                categories.find(c => c.id === selectedCategory)?.name + ' Listings'}
//             </h2>
//             <div style={{ 
//               color: '#666',
//               fontWeight: '500'
//             }}>
//               {filteredListings.length} {filteredListings.length === 1 ? 'item' : 'items'} found
//             </div>
//           </div>

//           {isLoading ? (
//             <div style={{
//               display: 'flex',
//               justifyContent: 'center',
//               alignItems: 'center',
//               height: '300px'
//             }}>
//               <div style={{
//                 width: '50px',
//                 height: '50px',
//                 border: '5px solid #f3f3f3',
//                 borderTop: '5px solid #23e5db',
//                 borderRadius: '50%',
//                 animation: 'spin 1s linear infinite'
//               }} />
//             </div>
//           ) : filteredListings.length === 0 ? (
//             <div style={{
//               backgroundColor: 'white',
//               borderRadius: '16px',
//               padding: '60px 40px',
//               textAlign: 'center',
//               boxShadow: '0 4px 12px rgba(0,0,0,0.05)'
//             }}>
//               <div style={{ 
//                 fontSize: '80px', 
//                 marginBottom: '20px',
//                 color: '#e0e0e0'
//               }}>🔍</div>
//               <h3 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '10px',
//                 fontSize: '24px',
//                 fontWeight: '700'
//               }}>No listings found</h3>
//               <p style={{ 
//                 color: '#666',
//                 fontSize: '16px',
//                 maxWidth: '500px',
//                 margin: '0 auto'
//               }}>
//                 Try adjusting your search or filter to find what you're looking for.
//               </p>
//               <button 
//                 onClick={() => {
//                   setSearchQuery('');
//                   setSelectedCategory('all');
//                   setLocation('All India');
//                 }}
//                 style={{
//                   marginTop: '20px',
//                   padding: '12px 24px',
//                   backgroundColor: '#23e5db',
//                   color: '#002f34',
//                   border: 'none',
//                   borderRadius: '8px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s ease',
//                   ':hover': {
//                     transform: 'translateY(-2px)',
//                     boxShadow: '0 4px 12px rgba(35, 229, 219, 0.3)'
//                   }
//                 }}
//               >
//                 Reset Filters
//               </button>
//             </div>
//           ) : (
//             <div style={{
//               display: 'grid',
//               gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
//               gap: '20px'
//             }}>
//               {filteredListings.map(listing => (
//                 <div
//                   key={listing.id}
//                   onClick={() => handleListingClick(listing.id)}
//                   style={{
//                     backgroundColor: 'white',
//                     borderRadius: '12px',
//                     overflow: 'hidden',
//                     boxShadow: '0 4px 8px rgba(0,0,0,0.05)',
//                     cursor: 'pointer',
//                     transition: 'all 0.3s ease',
//                     ':hover': {
//                       transform: 'translateY(-5px)',
//                       boxShadow: '0 8px 16px rgba(0,0,0,0.1)'
//                     }
//                   }}
//                 >
//                   {/* Listing card content */}
//                 </div>
//               ))}
//             </div>
//           )}
//         </section>
//       </main>

//       <Footer />
//     </div>
//   );
// };

// export default HomePage;







import React, { useState, useEffect } from 'react';
import { getDatabase, ref, onValue } from 'firebase/database';
import Navbar from './Navbar';

const Home = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const db = getDatabase();
    const propertiesRef = ref(db, 'delar/customers');
    
    onValue(propertiesRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        // Flatten all properties from all users
        const allProperties = Object.values(data).flatMap(user => {
          if (!user.properties) return [];
          return Object.entries(user.properties).flatMap(([category, props]) => 
            Object.entries(props).map(([id, property]) => ({
              id,
              category,
              sellerMobile: user.mobile,
              ...property
            }))
          );
        });
        setProperties(allProperties);
      } else {
        setProperties([]);
      }
      setLoading(false);
    });

    return () => onValue(propertiesRef, () => {});
  }, []);

  // Filter properties based on search and category
  const filteredProperties = properties.filter(property => {
    const matchesSearch = property.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         property.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || property.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Get unique categories for filter
  const categories = ['all', ...new Set(properties.map(p => p.category))];

  // return (
  //   <>
  //   <Navbar />
  //   <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      
  //     <div style={{ 
  //       marginBottom: '30px',
  //       backgroundColor: 'white',
  //       padding: '20px',
  //       borderRadius: '8px',
  //       boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  //     }}>
  //       <div style={{ display: 'flex', marginBottom: '15px' }}>
  //         <input
  //           type="text"
  //           placeholder="Search properties..."
  //           value={searchTerm}
  //           onChange={(e) => setSearchTerm(e.target.value)}
  //           style={{
  //             flex: 1,
  //             padding: '12px',
  //             border: '1px solid #ddd',
  //             borderRadius: '4px',
  //             fontSize: '16px',
  //             marginRight: '10px'
  //           }}
  //         />
  //         <select
  //           value={selectedCategory}
  //           onChange={(e) => setSelectedCategory(e.target.value)}
  //           style={{
  //             padding: '12px',
  //             border: '1px solid #ddd',
  //             borderRadius: '4px',
  //             fontSize: '16px',
  //             minWidth: '150px'
  //           }}
  //         >
  //           {categories.map(category => (
  //             <option key={category} value={category}>
  //               {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
  //             </option>
  //           ))}
  //         </select>
  //       </div>
  //     </div>

  //     {loading ? (
  //       <div style={{ textAlign: 'center', padding: '40px' }}>
  //         <p>Loading properties...</p>
  //       </div>
  //     ) : filteredProperties.length === 0 ? (
  //       <div style={{ 
  //         backgroundColor: '#f5f5f5',
  //         padding: '40px',
  //         borderRadius: '8px',
  //         textAlign: 'center'
  //       }}>
  //         <p>No properties found matching your criteria.</p>
  //       </div>
  //     ) : (
  //       <div style={{
  //         display: 'grid',
  //         gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
  //         gap: '20px'
  //       }}>
  //         {filteredProperties.map(property => (
  //           <div key={`${property.sellerMobile}-${property.category}-${property.id}`} 
  //             style={{
  //               backgroundColor: 'white',
  //               borderRadius: '8px',
  //               boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  //               overflow: 'hidden',
  //               transition: 'transform 0.2s',
  //               ':hover': {
  //                 transform: 'translateY(-5px)'
  //               }
  //             }}>
  //             {property.images?.[0] && (
  //               <img 
  //                 src={property.images[0]} 
  //                 alt={property.title}
  //                 style={{
  //                   width: '100%',
  //                   height: '200px',
  //                   objectFit: 'cover',
  //                   cursor: 'pointer'
  //                 }}
  //                 onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
  //               />
  //             )}
  //             <div style={{ padding: '15px' }}>
  //               <h3 style={{ 
  //                 margin: '0 0 10px', 
  //                 color: '#002f34',
  //                 cursor: 'pointer'
  //               }}
  //                 onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
  //               >
  //                 {property.title}
  //               </h3>
  //               <p style={{ 
  //                 margin: '0 0 5px', 
  //                 color: '#666',
  //                 textTransform: 'capitalize'
  //               }}>
  //                 {property.category}
  //               </p>
  //               <p style={{ 
  //                 margin: '0 0 10px', 
  //                 fontWeight: 'bold', 
  //                 color: '#002f34',
  //                 fontSize: '18px'
  //               }}>
  //                 ₹{property.price?.toLocaleString('en-IN')}
  //               </p>
  //               <p style={{ 
  //                 margin: '0 0 10px', 
  //                 color: '#666',
  //                 display: '-webkit-box',
  //                 WebkitLineClamp: 2,
  //                 WebkitBoxOrient: 'vertical',
  //                 overflow: 'hidden'
  //               }}>
  //                 {property.description}
  //               </p>
  //               <div style={{ 
  //                 display: 'flex', 
  //                 justifyContent: 'space-between',
  //                 alignItems: 'center'
  //               }}>
  //                 <span style={{ color: '#666', fontSize: '14px' }}>
  //                   {property.location}
  //                 </span>
  //                 <button
  //                   onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
  //                   style={{
  //                     backgroundColor: '#002f34',
  //                     color: 'white',
  //                     border: 'none',
  //                     padding: '8px 15px',
  //                     borderRadius: '4px',
  //                     cursor: 'pointer',
  //                     fontWeight: '600'
  //                   }}
  //                 >
  //                   View Details
  //                 </button>
  //               </div>
  //             </div>
  //           </div>
  //         ))}
  //       </div>
  //     )}
  //   </div>
  //   </>
  // );



  return (
    <>
      <Navbar />
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '20px 30px' }}>
        {/* Search and Filter Section */}
        <div style={{ 
          marginBottom: '40px',
          backgroundColor: 'white',
          padding: '25px 30px',
          borderRadius: '12px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
          border: '1px solid rgba(0,0,0,0.05)'
        }}>
          <h2 style={{ 
            margin: '0 0 20px',
            color: '#002f34',
            fontSize: '24px',
            fontWeight: '600'
          }}>
            Discover Your Perfect Property
          </h2>
          <div style={{ 
            display: 'flex', 
            gap: '15px',
            alignItems: 'center',
            flexWrap: 'wrap' 
          }}>
            <div style={{ flex: 1, minWidth: '300px' }}>
              <div style={{ 
                position: 'relative',
                display: 'flex',
                alignItems: 'center'
              }}>
                <input
                  type="text"
                  placeholder="Search by location, property type, or keyword..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '14px 20px 14px 45px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '16px',
                    boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)',
                    transition: 'all 0.3s',
                    ':focus': {
                      borderColor: '#002f34',
                      outline: 'none',
                      boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
                    }
                  }}
                />
                <svg 
                  style={{
                    position: 'absolute',
                    left: '15px',
                    width: '20px',
                    height: '20px',
                    color: '#999'
                  }} 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              style={{
                padding: '14px 20px',
                border: '1px solid #e0e0e0',
                borderRadius: '8px',
                fontSize: '16px',
                minWidth: '200px',
                backgroundColor: 'white',
                appearance: 'none',
                backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23002f34%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E")',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 15px center',
                backgroundSize: '12px',
                cursor: 'pointer',
                transition: 'all 0.3s',
                ':focus': {
                  borderColor: '#002f34',
                  outline: 'none',
                  boxShadow: '0 0 0 3px rgba(0,47,52,0.1)'
                }
              }}
            >
              {categories.map(category => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </option>
              ))}
            </select>
            
            <button 
              style={{
                padding: '14px 25px',
                backgroundColor: '#002f34',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.3s',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                ':hover': {
                  backgroundColor: '#004950',
                  transform: 'translateY(-1px)'
                }
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M22 22L20 20M11.5 6C13.7091 6 15.5 7.79086 15.5 10M2 10C2 14.4183 5.58172 18 10 18C14.4183 18 18 14.4183 18 10C18 5.58172 14.4183 2 10 2C5.58172 2 2 5.58172 2 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              Search
            </button>
          </div>
        </div>
  
        {/* Results Section */}
        {loading ? (
          <div style={{ 
            textAlign: 'center', 
            padding: '60px 20px',
            backgroundColor: 'white',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}>
            <div style={{
              display: 'inline-block',
              width: '50px',
              height: '50px',
              border: '3px solid rgba(0,47,52,0.1)',
              borderTopColor: '#002f34',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              marginBottom: '20px'
            }}></div>
            <p style={{ 
              margin: 0,
              color: '#002f34',
              fontSize: '18px',
              fontWeight: '500'
            }}>
              Loading properties...
            </p>
          </div>
        ) : filteredProperties.length === 0 ? (
          <div style={{ 
            backgroundColor: 'white',
            padding: '60px 20px',
            borderRadius: '12px',
            textAlign: 'center',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}>
            <svg 
              style={{
                width: '80px',
                height: '80px',
                color: '#e0e0e0',
                marginBottom: '20px'
              }} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 style={{ 
              margin: '0 0 10px',
              color: '#002f34',
              fontSize: '22px',
              fontWeight: '600'
            }}>
              No properties found
            </h3>
            <p style={{ 
              margin: 0,
              color: '#666',
              fontSize: '16px',
              maxWidth: '500px',
              margin: '0 auto'
            }}>
              We couldn't find any properties matching your search criteria. Try adjusting your filters.
            </p>
          </div>
        ) : (
          <>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '25px'
            }}>
              <h3 style={{ 
                margin: 0,
                color: '#002f34',
                fontSize: '20px',
                fontWeight: '600'
              }}>
                {filteredProperties.length} {filteredProperties.length === 1 ? 'Property' : 'Properties'} Found
              </h3>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px'
              }}>
                <span style={{ 
                  color: '#666',
                  fontSize: '14px'
                }}>
                  Sort by:
                </span>
                <select
                  style={{
                    padding: '10px 15px',
                    border: '1px solid #e0e0e0',
                    borderRadius: '6px',
                    fontSize: '14px',
                    backgroundColor: 'white',
                    cursor: 'pointer'
                  }}
                >
                  <option>Most Recent</option>
                  <option>Price: Low to High</option>
                  <option>Price: High to Low</option>
                </select>
              </div>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
              gap: '25px'
            }}>
              {filteredProperties.map(property => (
                <div 
                  key={`${property.sellerMobile}-${property.category}-${property.id}`} 
                  style={{
                    backgroundColor: 'white',
                    borderRadius: '12px',
                    boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease',
                    border: '1px solid rgba(0,0,0,0.05)',
                    ':hover': {
                      transform: 'translateY(-5px)',
                      boxShadow: '0 8px 25px rgba(0,0,0,0.1)'
                    }
                  }}
                >
                  {property.images?.[0] && (
                    <div style={{ 
                      position: 'relative',
                      height: '220px',
                      overflow: 'hidden',
                      cursor: 'pointer'
                    }}
                      onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
                    >
                      <img 
                        src={property.images[0]} 
                        alt={property.title}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          transition: 'transform 0.5s ease',
                          ':hover': {
                            transform: 'scale(1.05)'
                          }
                        }}
                      />
                      <div style={{
                        position: 'absolute',
                        top: '15px',
                        left: '15px',
                        backgroundColor: 'rgba(0,47,52,0.8)',
                        color: 'white',
                        padding: '5px 10px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'capitalize'
                      }}>
                        {property.category.replace('-', ' ')}
                      </div>
                    </div>
                  )}
                  <div style={{ padding: '20px' }}>
                    <div style={{ 
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'flex-start',
                      marginBottom: '15px'
                    }}>
                      <h3 style={{ 
                        margin: 0,
                        color: '#002f34',
                        fontSize: '18px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        flex: 1
                      }}
                        onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
                      >
                        {property.title}
                      </h3>
                      <span style={{ 
                        color: '#002f34',
                        fontSize: '20px',
                        fontWeight: '700',
                        whiteSpace: 'nowrap',
                        marginLeft: '15px'
                      }}>
                        ₹{property.price?.toLocaleString('en-IN')}
                      </span>
                    </div>
                    
                    <div style={{ 
                      display: 'flex',
                      alignItems: 'center',
                      gap: '15px',
                      marginBottom: '15px'
                    }}>
                      <div style={{ 
                        display: 'flex',
                        alignItems: 'center',
                        gap: '5px',
                        color: '#666',
                        fontSize: '14px'
                      }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M17.657 16.657L13.414 20.9C13.039 21.2746 12.5306 21.4852 12.0005 21.4852C11.4704 21.4852 10.962 21.2746 10.587 20.9L6.343 16.657C5.22422 15.5382 4.46234 14.1127 4.15369 12.5609C3.84504 11.009 4.00349 9.40055 4.60901 7.93872C5.21452 6.47689 6.2399 5.22753 7.55548 4.34851C8.87107 3.4695 10.4178 3.00029 12 3.00029C13.5822 3.00029 15.1289 3.4695 16.4445 4.34851C17.7601 5.22753 18.7855 6.47689 19.391 7.93872C19.9965 9.40055 20.155 11.009 19.8463 12.5609C19.5377 14.1127 18.7758 15.5382 17.657 16.657Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                          <path d="M15 11C15 12.6569 13.6569 14 12 14C10.3431 14 9 12.6569 9 11C9 9.34315 10.3431 8 12 8C13.6569 8 15 9.34315 15 11Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                        {property.location}
                      </div>
                    </div>
                    
                    <p style={{ 
                      margin: '0 0 20px',
                      color: '#666',
                      fontSize: '14px',
                      lineHeight: '1.5',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical',
                      overflow: 'hidden'
                    }}>
                      {property.description}
                    </p>
                    
                    <button
                      onClick={() => window.location.href = `/property/${property.category}/${property.id}`}
                      style={{
                        width: '100%',
                        backgroundColor: 'transparent',
                        color: '#002f34',
                        border: '2px solid #002f34',
                        padding: '10px',
                        borderRadius: '8px',
                        fontSize: '16px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        transition: 'all 0.3s',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '8px',
                        ':hover': {
                          backgroundColor: '#002f34',
                          color: 'white'
                        }
                      }}
                    >
                      View Full Details
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
      
      {/* Add some global styles for animations */}
      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </>
  );
};

export default Home;