// import React, { useState, useEffect } from 'react';


// import { useNavigate } from 'react-router-dom';
// import { useAuth } from '../AuthContext';
// import { ref, get } from 'firebase/database';
// import { database } from '../firebase';
// import { Line, Pie } from 'react-chartjs-2';
// import { Chart, registerables } from 'chart.js';
// import 'react-datepicker/dist/react-datepicker.css';
// import { FiMenu, FiBell, FiSearch, FiUser, FiLogOut } from 'react-icons/fi';

// Chart.register(...registerables);

// const AdminDashboard = () => {
//   const { user, logout } = useAuth();
//   const navigate = useNavigate();
//   const [sidebarOpen, setSidebarOpen] = useState(true);
//   const [activeTab, setActiveTab] = useState('dashboard');
//   const [searchQuery, setSearchQuery] = useState('');
//   const [users, setUsers] = useState([]);
//   const [listings, setListings] = useState([]);
//   const [stats, setStats] = useState({
//     totalUsers: 0,
//     activeListings: 0,
//     pendingApproval: 0,
//     totalRevenue: 0
//   });

//   // Demo data for charts
//   const trafficData = {
//     labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
//     datasets: [{
//       label: 'Website Traffic',
//       data: [65, 59, 80, 81, 56, 55],
//       borderColor: '#23e5db',
//       tension: 0.4
//     }]
//   };

//   const categoryData = {
//     labels: ['Electronics', 'Vehicles', 'Property', 'Services'],
//     datasets: [{
//       data: [30, 25, 20, 25],
//       backgroundColor: ['#23e5db', '#002f34', '#ffce32', '#ff5a5f']
//     }]
//   };

//   useEffect(() => {
//     if (!user || !user.isAdmin) {
//       navigate('/dashboard');
//       return;
//     }

//     const fetchData = async () => {
//       try {
//         // Fetch users
//         const usersRef = ref(database, 'dealer/customers');
//         const usersSnapshot = await get(usersRef);
//         const usersData = usersSnapshot.exists() 
//           ? Object.entries(usersSnapshot.val()).map(([id, data]) => ({ id, ...data }))
//           : [];
//         setUsers(usersData);

//         // Fetch listings
//         const listingsRef = ref(database, 'dealer/listings');
//         const listingsSnapshot = await get(listingsRef);
//         const listingsData = listingsSnapshot.exists()
//           ? Object.entries(listingsSnapshot.val()).map(([id, data]) => ({ id, ...data }))
//           : [];
//         setListings(listingsData);

//         // Calculate stats
//         setStats({
//           totalUsers: usersData.length,
//           activeListings: listingsData.filter(l => l.status === 'active').length,
//           pendingApproval: listingsData.filter(l => l.status === 'pending').length,
//           totalRevenue: listingsData.reduce((sum, l) => sum + (l.price || 0), 0)
//         });
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//     fetchData();
//   }, [user, navigate]);

//   const filteredListings = listings.filter(listing =>
//     listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     listing.category.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   const renderMainContent = () => {
//     switch(activeTab) {
//       case 'dashboard':
//         return (
//           <div style={styles.dashboardContent}>
//             {/* Stats Cards */}
//             <div style={styles.statsGrid}>
//               <div style={styles.statCard}>
//                 <h3>Total Users</h3>
//                 <p>{stats.totalUsers}</p>
//                 <div style={styles.statTrend}>+12% from last month</div>
//               </div>
//               <div style={styles.statCard}>
//                 <h3>Active Listings</h3>
//                 <p>{stats.activeListings}</p>
//                 <div style={styles.statTrend}>+8% from last week</div>
//               </div>
//               <div style={styles.statCard}>
//                 <h3>Pending Approval</h3>
//                 <p>{stats.pendingApproval}</p>
//                 <div style={{ ...styles.statTrend, color: '#ff5a5f' }}>3 urgent requests</div>
//               </div>
//               <div style={styles.statCard}>
//                 <h3>Total Revenue</h3>
//                 <p>${stats.totalRevenue.toLocaleString()}</p>
//                 <div style={styles.statTrend}>+15% from last month</div>
//               </div>
//             </div>

//             {/* Charts */}
//             <div style={styles.chartsContainer}>
//               <div style={styles.chartCard}>
//                 <h3>Website Traffic</h3>
//                 <Line data={trafficData} options={{ responsive: true }} />
//               </div>
//               <div style={styles.chartCard}>
//                 <h3>Category Distribution</h3>
//                 <Pie data={categoryData} options={{ responsive: true }} />
//               </div>
//             </div>

//             {/* Recent Listings */}
//             <div style={styles.sectionCard}>
//               <div style={styles.sectionHeader}>
//                 <h3>Recent Listings</h3>
//                 <input
//                   type="text"
//                   placeholder="Search listings..."
//                   style={styles.searchInput}
//                   value={searchQuery}
//                   onChange={(e) => setSearchQuery(e.target.value)}
//                 />
//               </div>
//               <table style={styles.dataTable}>
//                 <thead>
//                   <tr>
//                     <th>Title</th>
//                     <th>Category</th>
//                     <th>Price</th>
//                     <th>Status</th>
//                     <th>Actions</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {filteredListings.map(listing => (
//                     <tr key={listing.id}>
//                       <td>{listing.title}</td>
//                       <td>{listing.category}</td>
//                       <td>${listing.price}</td>
//                       <td>
//                         <span style={{
//                           ...styles.statusBadge,
//                           backgroundColor: listing.status === 'active' ? '#d4edda' : '#fff3cd',
//                           color: listing.status === 'active' ? '#155724' : '#856404'
//                         }}>
//                           {listing.status}
//                         </span>
//                       </td>
//                       <td>
//                         <button style={styles.actionButton}>View</button>
//                         <button style={styles.actionButton}>Edit</button>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           </div>
//         );

//       case 'users':
//         return (
//           <div style={styles.sectionCard}>
//             <h3>User Management</h3>
//             <table style={styles.dataTable}>
//               <thead>
//                 <tr>
//                   <th>Name</th>
//                   <th>Email</th>
//                   <th>Phone</th>
//                   <th>Joined</th>
//                   <th>Actions</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {users.map(user => (
//                   <tr key={user.id}>
//                     <td>{user.username}</td>
//                     <td>{user.email}</td>
//                     <td>{user.mobile}</td>
//                     <td>{new Date(user.createdAt).toLocaleDateString()}</td>
//                     <td>
//                       <button style={styles.actionButton}>View</button>
//                       <button style={styles.actionButton}>Edit</button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         );

//       default:
//         return <div style={styles.sectionCard}>Select a category</div>;
//     }
//   };

//   return (
//     <div style={styles.container}>
//       {/* Sidebar */}
//       <div style={{
//         ...styles.sidebar,
//         width: sidebarOpen ? '250px' : '80px'
//       }}>
//         <div style={styles.sidebarHeader}>
//           <h2 style={{ display: sidebarOpen ? 'block' : 'none' }}>OLX Admin</h2>
//           <button 
//             style={styles.toggleButton}
//             onClick={() => setSidebarOpen(!sidebarOpen)}
//           >
//             {sidebarOpen ? '◀' : '▶'}
//           </button>
//         </div>

//         <nav style={styles.nav}>
//           {[
//             { id: 'dashboard', label: 'Dashboard', icon: '📊' },
//             { id: 'users', label: 'Users', icon: '👥' },
//             { id: 'listings', label: 'Listings', icon: '🏷️' },
//             { id: 'analytics', label: 'Analytics', icon: '📈' }
//           ].map(item => (
//             <button
//               key={item.id}
//               style={{
//                 ...styles.navItem,
//                 backgroundColor: activeTab === item.id ? '#23e5db' : 'transparent',
//                 color: activeTab === item.id ? '#002f34' : 'white'
//               }}
//               onClick={() => setActiveTab(item.id)}
//             >
//               <span style={styles.navIcon}>{item.icon}</span>
//               {sidebarOpen && item.label}
//             </button>
//           ))}
//         </nav>
//       </div>

//       {/* Main Content */}
//       <div style={styles.mainContent}>
//         {/* Header */}
//         <header style={styles.header}>
//           <div style={styles.searchBar}>
//             <FiSearch style={styles.searchIcon} />
//             <input
//               type="text"
//               placeholder="Search..."
//               style={styles.searchInput}
//             />
//           </div>
          
//           <div style={styles.headerControls}>
//             <button style={styles.notificationButton}>
//               <FiBell size={20} />
//               <span style={styles.notificationBadge}>3</span>
//             </button>
            
//             <div style={styles.userProfile}>
//               <div style={styles.avatar}>{user?.username?.[0]}</div>
//               <div style={styles.userInfo}>
//                 <span>{user?.username}</span>
//                 <small>Administrator</small>
//               </div>
//               <button 
//                 style={styles.logoutButton}
//                 onClick={() => {
//                   logout();
//                   navigate('/');
//                 }}
//               >
//                 <FiLogOut size={18} />
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* Main Content Area */}
//         <main style={styles.main}>
//           {renderMainContent()}
//         </main>
//       </div>
//     </div>
//   );
// };

// const styles = {
//   container: {
//     display: 'flex',
//     minHeight: '100vh',
//     backgroundColor: '#f5f7fa',
//     fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif"
//   },
//   sidebar: {
//     backgroundColor: '#002f34',
//     color: 'white',
//     transition: 'width 0.3s ease',
//     position: 'sticky',
//     top: 0,
//     height: '100vh'
//   },
//   sidebarHeader: {
//     padding: '20px',
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     borderBottom: '1px solid #00444a'
//   },
//   toggleButton: {
//     background: '#23e5db',
//     border: 'none',
//     borderRadius: '50%',
//     width: '30px',
//     height: '30px',
//     cursor: 'pointer',
//     color: '#002f34',
//     fontWeight: 'bold'
//   },
//   nav: {
//     padding: '20px 0'
//   },
//   navItem: {
//     width: '100%',
//     padding: '15px 20px',
//     border: 'none',
//     cursor: 'pointer',
//     display: 'flex',
//     alignItems: 'center',
//     gap: '10px',
//     transition: 'background 0.3s ease'
//   },
//   navIcon: {
//     fontSize: '20px'
//   },
//   mainContent: {
//     flex: 1,
//     minWidth: 0
//   },
//   header: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     padding: '20px',
//     backgroundColor: 'white',
//     boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
//   },
//   searchBar: {
//     position: 'relative',
//     flex: 1,
//     maxWidth: '500px'
//   },
//   searchIcon: {
//     position: 'absolute',
//     left: '10px',
//     top: '50%',
//     transform: 'translateY(-50%)',
//     color: '#666'
//   },
//   searchInput: {
//     width: '100%',
//     padding: '10px 15px 10px 35px',
//     border: '1px solid #ddd',
//     borderRadius: '5px',
//     fontSize: '14px'
//   },
//   headerControls: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: '20px'
//   },
//   notificationButton: {
//     background: 'none',
//     border: 'none',
//     cursor: 'pointer',
//     position: 'relative'
//   },
//   notificationBadge: {
//     position: 'absolute',
//     top: '-5px',
//     right: '-5px',
//     background: '#ff5a5f',
//     color: 'white',
//     borderRadius: '50%',
//     width: '18px',
//     height: '18px',
//     fontSize: '12px',
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'center'
//   },
//   userProfile: {
//     display: 'flex',
//     alignItems: 'center',
//     gap: '10px'
//   },
//   avatar: {
//     width: '40px',
//     height: '40px',
//     borderRadius: '50%',
//     background: '#23e5db',
//     color: '#002f34',
//     display: 'flex',
//     alignItems: 'center',
//     justifyContent: 'center',
//     fontWeight: 'bold'
//   },
//   userInfo: {
//     display: 'flex',
//     flexDirection: 'column'
//   },
//   logoutButton: {
//     background: 'none',
//     border: 'none',
//     cursor: 'pointer',
//     color: '#002f34'
//   },
//   main: {
//     padding: '20px'
//   },
//   dashboardContent: {
//     display: 'flex',
//     flexDirection: 'column',
//     gap: '20px'
//   },
//   statsGrid: {
//     display: 'grid',
//     gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
//     gap: '20px'
//   },
//   statCard: {
//     background: 'white',
//     padding: '20px',
//     borderRadius: '10px',
//     boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
//   },
//   statTrend: {
//     color: '#23e5db',
//     fontSize: '12px',
//     marginTop: '5px'
//   },
//   chartsContainer: {
//     display: 'grid',
//     gridTemplateColumns: '2fr 1fr',
//     gap: '20px'
//   },
//   chartCard: {
//     background: 'white',
//     padding: '20px',
//     borderRadius: '10px',
//     boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
//   },
//   sectionCard: {
//     background: 'white',
//     padding: '20px',
//     borderRadius: '10px',
//     boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
//   },
//   sectionHeader: {
//     display: 'flex',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     marginBottom: '20px'
//   },
//   dataTable: {
//     width: '100%',
//     borderCollapse: 'collapse',
//     marginTop: '10px',
//     '& th, & td': {
//       padding: '12px',
//       textAlign: 'left',
//       borderBottom: '1px solid #eee'
//     },
//     '& th': {
//       backgroundColor: '#f8f9fa'
//     }
//   },
//   statusBadge: {
//     padding: '5px 10px',
//     borderRadius: '20px',
//     fontSize: '12px'
//   },
//   actionButton: {
//     background: 'none',
//     border: '1px solid #ddd',
//     padding: '5px 10px',
//     borderRadius: '5px',
//     cursor: 'pointer',
//     marginRight: '5px',
//     '&:hover': {
//       background: '#f8f9fa'
//     }
//   }
// };

// export default AdminDashboard;

























import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { getDatabase, ref, onValue, remove, update } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import { 
  FiHome, 
  FiShoppingBag, 
  FiPlusCircle, 
  FiUser, 
  FiLogOut,
  FiEdit, 
  FiTrash2,
  FiEye,
  FiEyeOff,
  FiUsers,
  FiMessageSquare
} from 'react-icons/fi';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('posts');
  const [userPosts, setUserPosts] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [interestedClients, setInterestedClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Fetch user data
  useEffect(() => {
    if (!user?.mobile) return;

    const db = getDatabase();
    
    const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
    const unsubscribePosts = onValue(postsRef, (snapshot) => {
      const postsData = snapshot.val();
      if (postsData) {
        const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
          Object.entries(properties).map(([id, post]) => ({
            id,
            category,
            ...post,
            status: post.status || 'active'
          }))
        );
        setUserPosts(postsArray);
      } else {
        setUserPosts([]);
      }
      setLoading(false);
    });

    const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
    const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
      const purchasesData = snapshot.val();
      setPurchases(purchasesData ? Object.values(purchasesData) : []);
    });

    // Fetch interested clients data if user is premium
    if (user.accountType === 'premium') {
      const interestedClientsRef = ref(db, `delar/customers/${user.mobile}/interestedClients`);
      const unsubscribeInterestedClients = onValue(interestedClientsRef, (snapshot) => {
        const clientsData = snapshot.val();
        if (clientsData) {
          const clientsArray = Object.entries(clientsData).map(([id, client]) => ({
            id,
            ...client
          }));
          setInterestedClients(clientsArray);
        } else {
          setInterestedClients([]);
        }
      });
      
      return () => {
        unsubscribePosts();
        unsubscribePurchases();
        unsubscribeInterestedClients();
      };
    }

    return () => {
      unsubscribePosts();
      unsubscribePurchases();
    };
  }, [user?.mobile, user?.accountType]);

  // Fixed edit property function
  const handleEditProperty = (postId, category) => {
    const propertyToEdit = userPosts.find(
      post => post.id === postId && post.category === category
    );
    
    if (propertyToEdit) {
      navigate('/sell', { 
        state: { 
          property: propertyToEdit,
          category: category,
          id: postId
        } 
      });
    } else {
      console.error('Property not found for editing');
      alert('Property not found. It may have been deleted.');
    }
  };

  // Delete property with confirmation
  const handleDeleteProperty = (postId, category) => {
    confirmAlert({
      title: 'Confirm Delete',
      message: 'Are you sure you want to delete this property?',
      buttons: [
        {
          label: 'Delete',
          className: 'confirm-delete-btn',
          onClick: () => deleteProperty(postId, category)
        },
        {
          label: 'Cancel',
          onClick: () => {}
        }
      ],
      closeOnEscape: true,
      closeOnClickOutside: true,
    });
  };

  // Actual delete function
  const deleteProperty = async (postId, category) => {
    try {
      const db = getDatabase();
      const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
      await remove(propertyRef);
      
      // Update local state
      setUserPosts(prevPosts => 
        prevPosts.filter(post => !(post.id === postId && post.category === category))
      );
    } catch (error) {
      console.error('Error deleting property:', error);
      alert('Failed to delete property. Please try again.');
    }
  };

  // Toggle property status
  const togglePropertyStatus = async (postId, category) => {
    try {
      const db = getDatabase();
      const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
      const currentPost = userPosts.find(post => post.id === postId && post.category === category);
      const newStatus = currentPost?.status === 'active' ? 'inactive' : 'active';
      
      await update(propertyRef, { status: newStatus });
      
      setUserPosts(prevPosts => 
        prevPosts.map(post => 
          post.id === postId && post.category === category
            ? { ...post, status: newStatus }
            : post
        )
      );
    } catch (error) {
      console.error('Error updating property status:', error);
      alert('Failed to update property status.');
    }
  };

  return (
    <div style={{
      display: 'flex',
      minHeight: '100vh',
      backgroundColor: '#f5f7fa'
    }}>
      {/* Sidebar */}
      <div style={{
        width: '250px',
        backgroundColor: '#002f34',
        color: 'white',
        padding: '20px 0',
        position: 'fixed',
        height: '100vh',
        display: mobileMenuOpen ? 'block' : 'none',
        '@media (min-width: 768px)': {
          display: 'block',
          position: 'relative'
        }
      }}>
        <div style={{ padding: '0 20px', marginBottom: '40px' }}>
          <h2 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <FiUser size={24} /> {user?.name || 'User'}
          </h2>
          <p style={{ color: '#a0aec0', fontSize: '14px' }}>{user?.mobile}</p>
          {user?.accountType === 'premium' && (
            <span style={{
              backgroundColor: '#23e5db',
              color: '#002f34',
              padding: '4px 8px',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: 'bold',
              marginTop: '5px',
              display: 'inline-block'
            }}>
              PREMIUM USER
            </span>
          )}
        </div>
        
        <nav>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
            <li>
              <button 
                onClick={() => setActiveTab('posts')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: activeTab === 'posts' ? '#23e5db' : 'transparent',
                  color: activeTab === 'posts' ? '#002f34' : 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s'
                }}
              >
                <FiHome /> My Listings
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('purchases')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: activeTab === 'purchases' ? '#23e5db' : 'transparent',
                  color: activeTab === 'purchases' ? '#002f34' : 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s'
                }}
              >
                <FiShoppingBag /> My Purchases
              </button>
            </li>
            {user?.accountType === 'premium' && (
              <li>
                <button 
                  onClick={() => setActiveTab('clients')}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    padding: '12px 20px',
                    backgroundColor: activeTab === 'clients' ? '#23e5db' : 'transparent',
                    color: activeTab === 'clients' ? '#002f34' : 'white',
                    border: 'none',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    cursor: 'pointer',
                    fontWeight: '600',
                    fontSize: '16px',
                    transition: 'all 0.2s'
                  }}
                >
                  <FiUsers /> Interested Clients
                </button>
              </li>
            )}
            <li>
              <button 
                onClick={() => navigate('/sell')}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: 'transparent',
                  color: 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <FiPlusCircle /> Post New Property
              </button>
            </li>
            <li style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
              <button 
                onClick={logout}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 20px',
                  backgroundColor: 'transparent',
                  color: 'white',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  cursor: 'pointer',
                  fontWeight: '600',
                  fontSize: '16px',
                  transition: 'all 0.2s',
                  ':hover': {
                    backgroundColor: 'rgba(255,255,255,0.1)'
                  }
                }}
              >
                <FiLogOut /> Logout
              </button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div style={{
        flex: 1,
        marginLeft: '0',
        '@media (min-width: 768px)': {
          marginLeft: '250px'
        }
      }}>
        {/* Mobile Header */}
        <div style={{
          backgroundColor: '#002f34',
          color: 'white',
          padding: '15px 20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          '@media (min-width: 768px)': {
            display: 'none'
          }
        }}>
          <h2 style={{ margin: 0 }}>Dashboard</h2>
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              color: 'white',
              fontSize: '24px',
              cursor: 'pointer'
            }}
          >
            ☰
          </button>
        </div>

        {/* Content */}
        <div style={{
          padding: '30px',
          maxWidth: '1200px',
          margin: '0 auto'
        }}>
          <h1 style={{ 
            color: '#002f34', 
            marginBottom: '30px',
            display: 'none',
            '@media (min-width: 768px)': {
              display: 'block'
            }
          }}>
            {activeTab === 'posts' ? 'My Property Listings' : 
             activeTab === 'purchases' ? 'My Purchases' : 
             activeTab === 'clients' ? 'Interested Clients' : 'Dashboard'}
          </h1>
          
          {loading ? (
            <div style={{ 
              textAlign: 'center', 
              padding: '40px',
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
            }}>
              <p>Loading your data...</p>
            </div>
          ) : activeTab === 'posts' ? (
            <div>
              {userPosts.length === 0 ? (
                <div style={{
                  backgroundColor: 'white',
                  padding: '30px',
                  borderRadius: '8px',
                  textAlign: 'center',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
                }}>
                  <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Properties Listed</h3>
                  <p style={{ color: '#666', marginBottom: '20px' }}>You haven't posted any properties yet.</p>
                  <button
                    onClick={() => navigate('/sell')}
                    style={{
                      backgroundColor: '#002f34',
                      color: 'white',
                      border: 'none',
                      padding: '12px 25px',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: '600',
                      fontSize: '16px',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.2s',
                      ':hover': {
                        backgroundColor: '#004950'
                      }
                    }}
                  >
                    <FiPlusCircle /> Post a Property
                  </button>
                </div>
              ) : (
                <div>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '20px'
                  }}>
                    <h2 style={{ color: '#002f34', margin: 0 }}>
                      My Properties ({userPosts.length})
                    </h2>
                    <button
                      onClick={() => navigate('/sell')}
                      style={{
                        backgroundColor: '#002f34',
                        color: 'white',
                        border: 'none',
                        padding: '10px 20px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '14px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px',
                        transition: 'all 0.2s',
                        ':hover': {
                          backgroundColor: '#004950'
                        }
                      }}
                    >
                      <FiPlusCircle size={16} /> Add New
                    </button>
                  </div>
                  
                  <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                    gap: '20px'
                  }}>
                    {userPosts.map((post) => (
                      <div key={`${post.category}-${post.id}`} style={{
                        backgroundColor: 'white',
                        borderRadius: '8px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        overflow: 'hidden',
                        transition: 'transform 0.2s',
                        opacity: post.status === 'inactive' ? 0.7 : 1,
                        ':hover': {
                          transform: 'translateY(-5px)'
                        }
                      }}>
                        {post.images?.[0] && (
                          <div style={{ position: 'relative' }}>
                            <img 
                              src={post.images[0]} 
                              alt={post.title}
                              style={{
                                width: '100%',
                                height: '200px',
                                objectFit: 'cover',
                                borderBottom: '1px solid #eee'
                              }}
                            />
                            {post.status === 'inactive' && (
                              <div style={{
                                position: 'absolute',
                                top: '10px',
                                right: '10px',
                                backgroundColor: 'rgba(0,0,0,0.7)',
                                color: 'white',
                                padding: '5px 10px',
                                borderRadius: '4px',
                                fontSize: '12px',
                                fontWeight: 'bold'
                              }}>
                                Inactive
                              </div>
                            )}
                          </div>
                        )}
                        <div style={{ padding: '15px' }}>
                          <h3 style={{ 
                            margin: '0 0 10px', 
                            color: '#002f34',
                            fontSize: '18px',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis'
                          }}>
                            {post.title}
                          </h3>
                          <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            marginBottom: '10px'
                          }}>
                            <span style={{
                              backgroundColor: '#e6f7f7',
                              color: '#002f34',
                              padding: '4px 8px',
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: '600'
                            }}>
                              {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
                            </span>
                            <p style={{ 
                              margin: 0, 
                              fontWeight: 'bold', 
                              color: '#002f34',
                              fontSize: '18px'
                            }}>
                              ₹{post.price?.toLocaleString('en-IN')}
                            </p>
                          </div>
                          <div style={{ 
                            display: 'flex', 
                            justifyContent: 'space-between',
                            gap: '10px',
                            marginTop: '15px'
                          }}>
                            <button
                              onClick={() => togglePropertyStatus(post.id, post.category)}
                              style={{
                                padding: '8px 12px',
                                backgroundColor: post.status === 'inactive' ? '#4CAF50' : '#f44336',
                                color: 'white',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontWeight: '600',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}
                            >
                              {post.status === 'inactive' ? <FiEye size={14} /> : <FiEyeOff size={14} />}
                              {post.status === 'inactive' ? 'Activate' : 'Deactivate'}
                            </button>
                            
                            <div style={{ display: 'flex', gap: '10px' }}>
                            <button
    onClick={() => handleEditProperty(post.id, post.category)}
    style={{
      padding: '8px 12px',
      backgroundColor: '#2196F3',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontWeight: '600',
      fontSize: '14px',
      display: 'flex',
      alignItems: 'center',
      gap: '5px'
    }}
  >
    <FiEdit size={14} /> Edit
  </button>
                              
                              <button
                                onClick={() => handleDeleteProperty(post.id, post.category)}
                                style={{
                                  padding: '8px 12px',
                                  backgroundColor: '#ff5252',
                                  color: 'white',
                                  border: 'none',
                                  borderRadius: '4px',
                                  cursor: 'pointer',
                                  fontWeight: '600',
                                  fontSize: '14px',
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '5px'
                                }}
                              >
                                <FiTrash2 size={14} /> Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) :activeTab === 'clients' ? (
            <div>
              <h2 style={{ 
                color: '#002f34', 
                marginBottom: '20px' 
              }}>
                Interested Clients ({interestedClients.length})
              </h2>
              
              {interestedClients.length === 0 ? (
                <div style={{
                  backgroundColor: 'white',
                  padding: '30px',
                  borderRadius: '8px',
                  textAlign: 'center',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
                }}>
                  <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Interested Clients Yet</h3>
                  <p style={{ color: '#666' }}>You'll see interested clients here when they contact you about your properties.</p>
                </div>
              ) : (
                <div style={{
                  backgroundColor: 'white',
                  borderRadius: '8px',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                  overflow: 'hidden'
                }}>
                  <table style={{
                    width: '100%',
                    borderCollapse: 'collapse'
                  }}>
                    <thead>
                      <tr style={{
                        backgroundColor: '#f8f9fa',
                        borderBottom: '1px solid #eee'
                      }}>
                        <th style={{
                          padding: '15px',
                          textAlign: 'left',
                          color: '#002f34'
                        }}>Property</th>
                        <th style={{
                          padding: '15px',
                          textAlign: 'left',
                          color: '#002f34'
                        }}>Client</th>
                        <th style={{
                          padding: '15px',
                          textAlign: 'left',
                          color: '#002f34'
                        }}>Contact</th>
                        <th style={{
                          padding: '15px',
                          textAlign: 'left',
                          color: '#002f34'
                        }}>Message</th>
                        <th style={{
                          padding: '15px',
                          textAlign: 'left',
                          color: '#002f34'
                        }}>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {interestedClients.map((client, index) => (
                        <tr key={index} style={{
                          borderBottom: '1px solid #eee',
                          ':last-child': {
                            borderBottom: 'none'
                          }
                        }}>
                          <td style={{
                            padding: '15px',
                            color: '#002f34',
                            fontWeight: '500'
                          }}>
                            {client.propertyTitle}
                          </td>
                          <td style={{
                            padding: '15px',
                            color: '#002f34'
                          }}>
                            {client.name}
                          </td>
                          <td style={{
                            padding: '15px',
                            color: '#002f34'
                          }}>
                            <div style={{ marginBottom: '5px' }}>{client.mobile}</div>
                            <div style={{ color: '#666', fontSize: '14px' }}>{client.email}</div>
                          </td>
                          <td style={{
                            padding: '15px',
                            color: '#666'
                          }}>
                            {client.message || 'No message'}
                          </td>
                          <td style={{
                            padding: '15px',
                            color: '#666'
                          }}>
                            {new Date(client.timestamp).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : null}

        </div>
      </div>
    </div>
  );
};

export default Dashboard;





// // import React, { useState, useEffect } from 'react';
// // import { useAuth } from '../AuthContext';
// // import { getDatabase, ref, onValue, remove, update } from 'firebase/database';
// // import { useNavigate } from 'react-router-dom';
// // import { 
// //   FiHome, 
// //   FiShoppingBag, 
// //   FiPlusCircle, 
// //   FiUser, 
// //   FiLogOut,
// //   FiEdit, 
// //   FiTrash2,
// //   FiEye,
// //   FiEyeOff,
// //   FiUsers,
// //   FiMessageSquare
// // } from 'react-icons/fi';
// // import { confirmAlert } from 'react-confirm-alert';
// // import 'react-confirm-alert/src/react-confirm-alert.css';

// // const Dashboard = () => {
//   const { user, logout } = useAuth();
//   const navigate = useNavigate();
//   const [activeTab, setActiveTab] = useState('posts');
//   const [userPosts, setUserPosts] = useState([]);
//   const [purchases, setPurchases] = useState([]);
//   const [interestedClients, setInterestedClients] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

//   // Fetch user data
//   useEffect(() => {
//     if (!user?.mobile) return;

//     const db = getDatabase();
    
//     const postsRef = ref(db, `delar/customers/${user.mobile}/properties`);
//     const unsubscribePosts = onValue(postsRef, (snapshot) => {
//       const postsData = snapshot.val();
//       if (postsData) {
//         const postsArray = Object.entries(postsData).flatMap(([category, properties]) => 
//           Object.entries(properties).map(([id, post]) => ({
//             id,
//             category,
//             ...post,
//             status: post.status || 'active'
//           }))
//         );
//         setUserPosts(postsArray);
//       } else {
//         setUserPosts([]);
//       }
//       setLoading(false);
//     });

//     const purchasesRef = ref(db, `delar/customers/${user.mobile}/purchases`);
//     const unsubscribePurchases = onValue(purchasesRef, (snapshot) => {
//       const purchasesData = snapshot.val();
//       setPurchases(purchasesData ? Object.values(purchasesData) : []);
//     });

//     // Fetch interested clients data if user is premium
//     if (user.accountType === 'premium') {
//       const interestedClientsRef = ref(db, `delar/customers/${user.mobile}/interestedClients`);
//       const unsubscribeInterestedClients = onValue(interestedClientsRef, (snapshot) => {
//         const clientsData = snapshot.val();
//         if (clientsData) {
//           const clientsArray = Object.entries(clientsData).map(([id, client]) => ({
//             id,
//             ...client
//           }));
//           setInterestedClients(clientsArray);
//         } else {
//           setInterestedClients([]);
//         }
//       });
      
//       return () => {
//         unsubscribePosts();
//         unsubscribePurchases();
//         unsubscribeInterestedClients();
//       };
//     }

//     return () => {
//       unsubscribePosts();
//       unsubscribePurchases();
//     };
//   }, [user?.mobile, user?.accountType]);

//   const handleEditProperty = (postId, category) => {
//     const propertyToEdit = userPosts.find(
//       post => post.id === postId && post.category === category
//     );
    
//     if (propertyToEdit) {
//       navigate('/sell', { 
//         state: { 
//           property: propertyToEdit,
//           category: category,
//           id: postId
//         } 
//       });
//     } else {
//       console.error('Property not found for editing');
//       alert('Property not found. It may have been deleted.');
//     }
//   };

//   const handleDeleteProperty = (postId, category) => {
//     confirmAlert({
//       title: 'Confirm Delete',
//       message: 'Are you sure you want to delete this property?',
//       buttons: [
//         {
//           label: 'Delete',
//           className: 'confirm-delete-btn',
//           onClick: () => deleteProperty(postId, category)
//         },
//         {
//           label: 'Cancel',
//           onClick: () => {}
//         }
//       ],
//       closeOnEscape: true,
//       closeOnClickOutside: true,
//     });
//   };

//   const deleteProperty = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       await remove(propertyRef);
      
//       setUserPosts(prevPosts => 
//         prevPosts.filter(post => !(post.id === postId && post.category === category))
//       );
//     } catch (error) {
//       console.error('Error deleting property:', error);
//       alert('Failed to delete property. Please try again.');
//     }
//   };

//   const togglePropertyStatus = async (postId, category) => {
//     try {
//       const db = getDatabase();
//       const propertyRef = ref(db, `delar/customers/${user.mobile}/properties/${category}/${postId}`);
      
//       const currentPost = userPosts.find(post => post.id === postId && post.category === category);
//       const newStatus = currentPost?.status === 'active' ? 'inactive' : 'active';
      
//       await update(propertyRef, { status: newStatus });
      
//       setUserPosts(prevPosts => 
//         prevPosts.map(post => 
//           post.id === postId && post.category === category
//             ? { ...post, status: newStatus }
//             : post
//         )
//       );
//     } catch (error) {
//       console.error('Error updating property status:', error);
//       alert('Failed to update property status.');
//     }
//   };

//   return (
//     <div style={{
//       display: 'flex',
//       minHeight: '100vh',
//       backgroundColor: '#f5f7fa'
//     }}>
//       {/* Sidebar */}
//       <div style={{
//         width: '250px',
//         backgroundColor: '#002f34',
//         color: 'white',
//         padding: '20px 0',
//         position: 'fixed',
//         height: '100vh',
//         display: mobileMenuOpen ? 'block' : 'none',
//         '@media (min-width: 768px)': {
//           display: 'block',
//           position: 'relative'
//         }
//       }}>
//         <div style={{ padding: '0 20px', marginBottom: '40px' }}>
//           <h2 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '10px' }}>
//             <FiUser size={24} /> {user?.name || 'User'}
//           </h2>
//           <p style={{ color: '#a0aec0', fontSize: '14px' }}>{user?.mobile}</p>
//           {user?.accountType === 'premium' && (
//             <span style={{
//               backgroundColor: '#23e5db',
//               color: '#002f34',
//               padding: '4px 8px',
//               borderRadius: '4px',
//               fontSize: '12px',
//               fontWeight: 'bold',
//               marginTop: '5px',
//               display: 'inline-block'
//             }}>
//               PREMIUM USER
//             </span>
//           )}
//         </div>
        
//         <nav>
//           <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('posts')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'posts' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'posts' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiHome /> My Listings
//               </button>
//             </li>
//             <li>
//               <button 
//                 onClick={() => setActiveTab('purchases')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: activeTab === 'purchases' ? '#23e5db' : 'transparent',
//                   color: activeTab === 'purchases' ? '#002f34' : 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s'
//                 }}
//               >
//                 <FiShoppingBag /> My Purchases
//               </button>
//             </li>
//             {user?.accountType === 'premium' && (
//               <li>
//                 <button 
//                   onClick={() => setActiveTab('clients')}
//                   style={{
//                     width: '100%',
//                     textAlign: 'left',
//                     padding: '12px 20px',
//                     backgroundColor: activeTab === 'clients' ? '#23e5db' : 'transparent',
//                     color: activeTab === 'clients' ? '#002f34' : 'white',
//                     border: 'none',
//                     display: 'flex',
//                     alignItems: 'center',
//                     gap: '10px',
//                     cursor: 'pointer',
//                     fontWeight: '600',
//                     fontSize: '16px',
//                     transition: 'all 0.2s'
//                   }}
//                 >
//                   <FiUsers /> Interested Clients
//                 </button>
//               </li>
//             )}
//             <li>
//               <button 
//                 onClick={() => navigate('/sell')}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiPlusCircle /> Post New Property
//               </button>
//             </li>
//             <li style={{ marginTop: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
//               <button 
//                 onClick={logout}
//                 style={{
//                   width: '100%',
//                   textAlign: 'left',
//                   padding: '12px 20px',
//                   backgroundColor: 'transparent',
//                   color: 'white',
//                   border: 'none',
//                   display: 'flex',
//                   alignItems: 'center',
//                   gap: '10px',
//                   cursor: 'pointer',
//                   fontWeight: '600',
//                   fontSize: '16px',
//                   transition: 'all 0.2s',
//                   ':hover': {
//                     backgroundColor: 'rgba(255,255,255,0.1)'
//                   }
//                 }}
//               >
//                 <FiLogOut /> Logout
//               </button>
//             </li>
//           </ul>
//         </nav>
//       </div>

//       {/* Main Content */}
//       <div style={{
//         flex: 1,
//         marginLeft: '0',
//         '@media (min-width: 768px)': {
//           marginLeft: '250px'
//         }
//       }}>
//         {/* Mobile Header */}
//         <div style={{
//           backgroundColor: '#002f34',
//           color: 'white',
//           padding: '15px 20px',
//           display: 'flex',
//           justifyContent: 'space-between',
//           alignItems: 'center',
//           '@media (min-width: 768px)': {
//             display: 'none'
//           }
//         }}>
//           <h2 style={{ margin: 0 }}>Dashboard</h2>
//           <button 
//             onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
//             style={{
//               backgroundColor: 'transparent',
//               border: 'none',
//               color: 'white',
//               fontSize: '24px',
//               cursor: 'pointer'
//             }}
//           >
//             ☰
//           </button>
//         </div>

//         {/* Content */}
//         <div style={{
//           padding: '30px',
//           maxWidth: '1200px',
//           margin: '0 auto'
//         }}>
//           <h1 style={{ 
//             color: '#002f34', 
//             marginBottom: '30px',
//             display: 'none',
//             '@media (min-width: 768px)': {
//               display: 'block'
//             }
//           }}>
//             {activeTab === 'posts' ? 'My Property Listings' : 
//              activeTab === 'purchases' ? 'My Purchases' : 
//              activeTab === 'clients' ? 'Interested Clients' : 'Dashboard'}
//           </h1>
          
//           {loading ? (
//             <div style={{ 
//               textAlign: 'center', 
//               padding: '40px',
//               backgroundColor: 'white',
//               borderRadius: '8px',
//               boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//             }}>
//               <p>Loading your data...</p>
//             </div>
//           ) : activeTab === 'posts' ? (
//             <div>
//               {userPosts.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Properties Listed</h3>
//                   <p style={{ color: '#666', marginBottom: '20px' }}>You haven't posted any properties yet.</p>
//                   <button
//                     onClick={() => navigate('/sell')}
//                     style={{
//                       backgroundColor: '#002f34',
//                       color: 'white',
//                       border: 'none',
//                       padding: '12px 25px',
//                       borderRadius: '4px',
//                       cursor: 'pointer',
//                       fontWeight: '600',
//                       fontSize: '16px',
//                       display: 'inline-flex',
//                       alignItems: 'center',
//                       gap: '8px',
//                       transition: 'all 0.2s',
//                       ':hover': {
//                         backgroundColor: '#004950'
//                       }
//                     }}
//                   >
//                     <FiPlusCircle /> Post a Property
//                   </button>
//                 </div>
//               ) : (
//                 <div>
//                   <div style={{
//                     display: 'flex',
//                     justifyContent: 'space-between',
//                     alignItems: 'center',
//                     marginBottom: '20px'
//                   }}>
//                     <h2 style={{ color: '#002f34', margin: 0 }}>
//                       My Properties ({userPosts.length})
//                     </h2>
//                     <button
//                       onClick={() => navigate('/sell')}
//                       style={{
//                         backgroundColor: '#002f34',
//                         color: 'white',
//                         border: 'none',
//                         padding: '10px 20px',
//                         borderRadius: '4px',
//                         cursor: 'pointer',
//                         fontWeight: '600',
//                         fontSize: '14px',
//                         display: 'flex',
//                         alignItems: 'center',
//                         gap: '8px',
//                         transition: 'all 0.2s',
//                         ':hover': {
//                           backgroundColor: '#004950'
//                         }
//                       }}
//                     >
//                       <FiPlusCircle size={16} /> Add New
//                     </button>
//                   </div>
                  
//                   <div style={{
//                     display: 'grid',
//                     gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
//                     gap: '20px'
//                   }}>
//                     {userPosts.map((post) => (
//                       <div key={`${post.category}-${post.id}`} style={{
//                         backgroundColor: 'white',
//                         borderRadius: '8px',
//                         boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
//                         overflow: 'hidden',
//                         transition: 'transform 0.2s',
//                         opacity: post.status === 'inactive' ? 0.7 : 1,
//                         ':hover': {
//                           transform: 'translateY(-5px)'
//                         }
//                       }}>
//                         {post.images?.[0] && (
//                           <div style={{ position: 'relative' }}>
//                             <img 
//                               src={post.images[0]} 
//                               alt={post.title}
//                               style={{
//                                 width: '100%',
//                                 height: '200px',
//                                 objectFit: 'cover',
//                                 borderBottom: '1px solid #eee'
//                               }}
//                             />
//                             {post.status === 'inactive' && (
//                               <div style={{
//                                 position: 'absolute',
//                                 top: '10px',
//                                 right: '10px',
//                                 backgroundColor: 'rgba(0,0,0,0.7)',
//                                 color: 'white',
//                                 padding: '5px 10px',
//                                 borderRadius: '4px',
//                                 fontSize: '12px',
//                                 fontWeight: 'bold'
//                               }}>
//                                 Inactive
//                               </div>
//                             )}
//                           </div>
//                         )}
//                         <div style={{ padding: '15px' }}>
//                           <h3 style={{ 
//                             margin: '0 0 10px', 
//                             color: '#002f34',
//                             fontSize: '18px',
//                             whiteSpace: 'nowrap',
//                             overflow: 'hidden',
//                             textOverflow: 'ellipsis'
//                           }}>
//                             {post.title}
//                           </h3>
//                           <div style={{
//                             display: 'flex',
//                             justifyContent: 'space-between',
//                             marginBottom: '10px'
//                           }}>
//                             <span style={{
//                               backgroundColor: '#e6f7f7',
//                               color: '#002f34',
//                               padding: '4px 8px',
//                               borderRadius: '4px',
//                               fontSize: '12px',
//                               fontWeight: '600'
//                             }}>
//                               {post.category.charAt(0).toUpperCase() + post.category.slice(1)}
//                             </span>
//                             <p style={{ 
//                               margin: 0, 
//                               fontWeight: 'bold', 
//                               color: '#002f34',
//                               fontSize: '18px'
//                             }}>
//                               ₹{post.price?.toLocaleString('en-IN')}
//                             </p>
//                           </div>
//                           <div style={{ 
//                             display: 'flex', 
//                             justifyContent: 'space-between',
//                             gap: '10px',
//                             marginTop: '15px'
//                           }}>
//                             <button
//                               onClick={() => togglePropertyStatus(post.id, post.category)}
//                               style={{
//                                 padding: '8px 12px',
//                                 backgroundColor: post.status === 'inactive' ? '#4CAF50' : '#f44336',
//                                 color: 'white',
//                                 border: 'none',
//                                 borderRadius: '4px',
//                                 cursor: 'pointer',
//                                 fontWeight: '600',
//                                 fontSize: '14px',
//                                 display: 'flex',
//                                 alignItems: 'center',
//                                 gap: '5px'
//                               }}
//                             >
//                               {post.status === 'inactive' ? <FiEye size={14} /> : <FiEyeOff size={14} />}
//                               {post.status === 'inactive' ? 'Activate' : 'Deactivate'}
//                             </button>
                            
//                             <div style={{ display: 'flex', gap: '10px' }}>
//                               <button
//                                 onClick={() => handleEditProperty(post.id, post.category)}
//                                 style={{
//                                   padding: '8px 12px',
//                                   backgroundColor: '#2196F3',
//                                   color: 'white',
//                                   border: 'none',
//                                   borderRadius: '4px',
//                                   cursor: 'pointer',
//                                   fontWeight: '600',
//                                   fontSize: '14px',
//                                   display: 'flex',
//                                   alignItems: 'center',
//                                   gap: '5px'
//                                 }}
//                               >
//                                 <FiEdit size={14} /> Edit
//                               </button>
                              
//                               <button
//                                 onClick={() => handleDeleteProperty(post.id, post.category)}
//                                 style={{
//                                   padding: '8px 12px',
//                                   backgroundColor: '#ff5252',
//                                   color: 'white',
//                                   border: 'none',
//                                   borderRadius: '4px',
//                                   cursor: 'pointer',
//                                   fontWeight: '600',
//                                   fontSize: '14px',
//                                   display: 'flex',
//                                   alignItems: 'center',
//                                   gap: '5px'
//                                 }}
//                               >
//                                 <FiTrash2 size={14} /> Delete
//                               </button>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>
//           ) : activeTab === 'purchases' ? (
//             <div>
//               <h2 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '20px' 
//               }}>
//                 My Purchases ({purchases.length})
//               </h2>
//               {purchases.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Purchases Yet</h3>
//                   <p style={{ color: '#666' }}>You haven't made any purchases yet.</p>
//                 </div>
//               ) : (
//                 <div style={{
//                   backgroundColor: 'white',
//                   borderRadius: '8px',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
//                   overflow: 'hidden'
//                 }}>
//                   <table style={{
//                     width: '100%',
//                     borderCollapse: 'collapse'
//                   }}>
//                     <thead>
//                       <tr style={{
//                         backgroundColor: '#f8f9fa',
//                         borderBottom: '1px solid #eee'
//                       }}>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Property</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Date</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Amount</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Status</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Action</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {purchases.map((purchase, index) => (
//                         <tr key={index} style={{
//                           borderBottom: '1px solid #eee',
//                           ':last-child': {
//                             borderBottom: 'none'
//                           }
//                         }}>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: '500'
//                           }}>
//                             {purchase.propertyTitle}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {new Date(purchase.date).toLocaleDateString()}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: 'bold'
//                           }}>
//                             ₹{purchase.amount?.toLocaleString('en-IN')}
//                           </td>
//                           <td style={{
//                             padding: '15px'
//                           }}>
//                             <span style={{
//                               backgroundColor: purchase.status === 'Completed' ? '#e6f7f7' : '#fff8e1',
//                               color: purchase.status === 'Completed' ? '#002f34' : '#ff8f00',
//                               padding: '6px 12px',
//                               borderRadius: '20px',
//                               fontSize: '14px',
//                               fontWeight: '600'
//                             }}>
//                               {purchase.status || 'Completed'}
//                             </span>
//                           </td>
//                           <td style={{
//                             padding: '15px'
//                           }}>
//                             <button
//                               onClick={() => navigate(`/property/${purchase.propertyId}`)}
//                               style={{
//                                 backgroundColor: '#002f34',
//                                 color: 'white',
//                                 border: 'none',
//                                 padding: '8px 15px',
//                                 borderRadius: '4px',
//                                 cursor: 'pointer',
//                                 fontWeight: '600',
//                                 fontSize: '14px',
//                                 transition: 'all 0.2s',
//                                 ':hover': {
//                                   backgroundColor: '#004950'
//                                 }
//                               }}
//                             >
//                               View
//                             </button>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//               )}
//             </div>
//           ) : activeTab === 'clients' ? (
//             <div>
//               <h2 style={{ 
//                 color: '#002f34', 
//                 marginBottom: '20px' 
//               }}>
//                 Interested Clients ({interestedClients.length})
//               </h2>
              
//               {interestedClients.length === 0 ? (
//                 <div style={{
//                   backgroundColor: 'white',
//                   padding: '30px',
//                   borderRadius: '8px',
//                   textAlign: 'center',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)'
//                 }}>
//                   <h3 style={{ color: '#002f34', marginBottom: '15px' }}>No Interested Clients Yet</h3>
//                   <p style={{ color: '#666' }}>You'll see interested clients here when they contact you about your properties.</p>
//                 </div>
//               ) : (
//                 <div style={{
//                   backgroundColor: 'white',
//                   borderRadius: '8px',
//                   boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
//                   overflow: 'hidden'
//                 }}>
//                   <table style={{
//                     width: '100%',
//                     borderCollapse: 'collapse'
//                   }}>
//                     <thead>
//                       <tr style={{
//                         backgroundColor: '#f8f9fa',
//                         borderBottom: '1px solid #eee'
//                       }}>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Property</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Client</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Contact</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Message</th>
//                         <th style={{
//                           padding: '15px',
//                           textAlign: 'left',
//                           color: '#002f34'
//                         }}>Date</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {interestedClients.map((client, index) => (
//                         <tr key={index} style={{
//                           borderBottom: '1px solid #eee',
//                           ':last-child': {
//                             borderBottom: 'none'
//                           }
//                         }}>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34',
//                             fontWeight: '500'
//                           }}>
//                             {client.propertyTitle}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             {client.name}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#002f34'
//                           }}>
//                             <div style={{ marginBottom: '5px' }}>{client.mobile}</div>
//                             <div style={{ color: '#666', fontSize: '14px' }}>{client.email}</div>
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {client.message || 'No message'}
//                           </td>
//                           <td style={{
//                             padding: '15px',
//                             color: '#666'
//                           }}>
//                             {new Date(client.timestamp).toLocaleDateString()}
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </table>
//                 </div>
//               )}
//             </div>
//           ) : null}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;